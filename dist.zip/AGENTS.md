# Agent Instructions — Automat Faceless

## Current assignment boundary

This package is a roadmap and documentation baseline. No new extension implementation has been started. When implementing later, work only on the subphase explicitly requested by the user. User instructions override this file.

## Read first

1. README.md and PROJECT_STATUS.md.
2. PROJECT.md and REQUIREMENTS.md.
3. The requested phase card under phases/.
4. Only the relevant sections of DESIGN.md, INPUT_FORMAT.md, ARCHITECTURE.md, DATA_MODEL.md and TESTING.md.

Do not read the entire historical repository on every task.

## Required working method

- Implement one subphase at a time and stop at its stated acceptance boundary.
- Start from the exact files listed in the phase task. Search with rg scoped to those files/directories.
- Expand file scope only for a necessary dependency, explain why, and preserve unrelated work. Do not request permission for routine implementation choices already covered by the task.
- Inspect the working tree and applicable local AGENTS instructions before edits.
- Keep legacy reference code, credentials, pending operations, and browser storage separate.
- Reuse a legacy helper only after checking its actual assumptions. Do not copy the old dashboard/worker wholesale.
- Deliver the feature and its appropriate checks; do not replace requested work with a plan.
- At the end update PROJECT_STATUS.md and the relevant decision/evidence note, then stop.
- Do not spawn sub-agents unless the user or an applicable instruction explicitly requests delegation.

## Product rules that must not drift

- Both image and video prompts are large JSON, transmitted losslessly.
- One full JSON body is one prompt. Internal arrays/numbers/quoted strings are not batch separators.
- Use stable shot IDs to pair images and video prompts; never match by gallery position, filename ordering, or the latest selected asset.
- User sets provider settings manually. The extension records confirmation and declared tracking metadata.
- Flow image model choices are Nano Banana Pro and Nano Banana 2.1 as user-provided labels.
- Flow video model is the user-provided Omni 1.1 Flash label.
- No automatic action-duration + 2s policy.
- Exactly one video destination per batch: Flow or Vids.
- Vids scene insertion stays manual in this scope.
- Existing OAuth/helper and local splitter are reuse candidates, not missing features.

## Reliability rules

- Bind every mutation to the intended tab/project and current item/attempt.
- Persist dispatch intent before Generate input.
- Zero Generate events before successful preparation/preflight. At most one activation on the normal successful attempt.
- Preserve returned delivery evidence. An unknown result does not authorize replay.
- A response timer may show waiting; it must not imply cancellation or enable duplicate submission.
- Persist item completion before starting the next item.
- Pause stops future jobs; it does not claim to cancel an active provider job.
- Worker restart reconciles an existing attempt or asks for review; it does not repeat it.
- Logs use fixed stage/reason identifiers and bounded lengths/times. Do not log raw JSON or credentials.

## Live actions and authorization

This documentation task authorizes no browser login, generation, downloads, provider mutation, deployment, or storage migration.

During a later implementation task, obey that task's stated live-action authorization. If a controlled live test is explicitly authorized, carry it out within its bounds without asking again for each necessary reversible step. If live actions are excluded or runtime access is absent, complete the offline work and mark the live gate NOT_RUN; never call the milestone live-verified.

Never suggest repeatedly clicking a silent action. Inspect loaded build/handler evidence first.

## Checks

- Run focused meaningful tests for parser, queue, identity, dispatch and media logic.
- Typecheck, lint, build, and diff check when applicable to changed app code.
- For low-impact visual-only changes, use visual inspection/build checks; do not add tests that mirror CSS implementation.
- Broad regression runs are appropriate at integration gates or after shared-contract changes, not as busywork after every tiny adjustment.
- Record actual test output. Do not copy legacy pass counts into a new result.

## Reporting

State what changed, why, what was checked, and what remains unverified. Distinguish source review, mocks, real browser action, browser download completion, and decoded-media verification.

Do not create a new settlement/recovery system as an unrelated fix. Keep the normal workflow simple and investigate demonstrated failures only.
