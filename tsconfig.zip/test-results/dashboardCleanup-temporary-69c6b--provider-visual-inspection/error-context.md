# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: dashboardCleanup.spec.ts >> temporary Downloads and Videos provider visual inspection
- Location: tests\browser\dashboardCleanup.spec.ts:213:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Video · c2989a6e' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('heading', { name: 'Video · c2989a6e' }) with timeout 5000ms
  - waiting for getByRole('heading', { name: 'Video · c2989a6e' })

```

```yaml
- main:
  - complementary:
    - link "Automat Faceless home":
      - /url: "#workspace"
      - strong: Automat
      - text: FACELESS STUDIO
    - paragraph: WORKSPACE
    - navigation "Workspace":
      - button "01 Images"
      - button "02 References"
      - button "03 Videos"
      - button "04 Downloads"
    - region "Connections":
      - heading "Connections" [level=2]
      - paragraph: Select the intended open project. This panel verifies the connection; guarded image actions are under Legacy tools.
      - button "Find open projects" [disabled]
      - paragraph: Local preview · Chrome tab and provider APIs are unavailable here.
      - text: Flow
      - strong: Not connected
      - text: Already-open Flow project
      - combobox "Already-open Flow project":
        - option "Choose Flow project…" [selected]
      - button "Connect" [disabled]
      - group: Connection details
      - text: Vids
      - strong: Not connected
      - text: Already-open Vids project
      - combobox "Already-open Vids project":
        - option "Choose Vids project…" [selected]
      - button "Connect" [disabled]
      - group: Connection details
  - text: Studio
  - strong: Downloads
  - button "Switch to dark theme": Dark
  - paragraph: CREATIVE WORKSPACE
  - heading "Downloads" [level=1]
  - paragraph: Check available generated results and downloads.
  - region "Downloads workspace":
    - group "Choose a download provider":
      - text: Choose a download provider
      - radio "Selected provider Flow Downloads Download imported clips from their exact verified Flow detail route." [checked]
      - text: Selected provider Flow Downloads Download imported clips from their exact verified Flow detail route.
      - radio "Provider Vids Downloads Vids download tools are not available in this build yet."
      - text: Provider Vids Downloads Vids download tools are not available in this build yet.
    - region "Flow Downloads":
      - alert: Flow download status is unavailable. Reconnect the extension before starting another attempt.
      - region "Imported Flow clips":
        - heading "Flow Downloads" [level=2]
        - text: Imported clip count unavailable
        - button "Import open clip"
        - button "Refresh list"
        - paragraph: Import the clip open in the verified Flow tab, then open it or request its 1080p download. Status reflects only the current attempt; previous downloads are not tracked here.
        - alert: Imported Flow clips could not be read from local storage.
        - paragraph: Imported Flow clips could not be loaded.
  - group: Advanced details Technical preview information
```

# Test source

```ts
  155 |   const dismissSuccess = page.getByRole("button", {
  156 |     name: "Dismiss success notification",
  157 |   });
  158 |   if (await dismissSuccess.count()) {
  159 |     await dismissSuccess.click();
  160 |     await expect(page.locator('[data-toast-kind="success"]')).toHaveCount(0);
  161 |   }
  162 |   await page.screenshot({
  163 |     path: `${screenshotDir}/desktop-light.png`,
  164 |     fullPage: true,
  165 |   });
  166 |   await page.getByRole("button", { name: "Switch to dark theme" }).click();
  167 |   await page.screenshot({
  168 |     path: `${screenshotDir}/desktop-dark.png`,
  169 |     fullPage: true,
  170 |   });
  171 | 
  172 |   await page.setViewportSize({ width: 1280, height: 520 });
  173 |   const sidebar = page.locator('[class*="sidebar"]');
  174 |   const sidebarMetrics = await sidebar.evaluate((element) => ({
  175 |     height: (element as HTMLElement).clientHeight,
  176 |     scrollHeight: (element as HTMLElement).scrollHeight,
  177 |     overflowY: getComputedStyle(element).overflowY,
  178 |   }));
  179 |   expect(sidebarMetrics.overflowY).toBe("auto");
  180 |   expect(sidebarMetrics.scrollHeight).toBeGreaterThan(sidebarMetrics.height);
  181 |   await page.locator("#selected-vids-tab").focus();
  182 |   const vidsBounds = await page.locator("#selected-vids-tab").boundingBox();
  183 |   const sidebarBounds = await sidebar.boundingBox();
  184 |   expect(vidsBounds).not.toBeNull();
  185 |   expect(sidebarBounds).not.toBeNull();
  186 |   expect(vidsBounds!.y).toBeGreaterThanOrEqual(sidebarBounds!.y);
  187 |   expect(vidsBounds!.y + vidsBounds!.height).toBeLessThanOrEqual(
  188 |     sidebarBounds!.y + sidebarBounds!.height,
  189 |   );
  190 |   await page.screenshot({ path: `${screenshotDir}/short-laptop.png` });
  191 |   await page.setViewportSize({ width: 390, height: 844 });
  192 |   const mobileWidths = await page.evaluate(() => ({
  193 |     viewport: document.documentElement.clientWidth,
  194 |     page: document.documentElement.scrollWidth,
  195 |   }));
  196 |   expect(mobileWidths.page).toBeLessThanOrEqual(mobileWidths.viewport);
  197 |   const mobileToolbarButtons = await inputToolbar
  198 |     .locator("[class*=sourceToolbarButtons] button:visible")
  199 |     .all();
  200 |   const mobileButtonBounds = await Promise.all(
  201 |     mobileToolbarButtons.map((button) => button.boundingBox()),
  202 |   );
  203 |   expect(mobileButtonBounds).toHaveLength(2);
  204 |   expect(mobileButtonBounds[0]).not.toBeNull();
  205 |   expect(mobileButtonBounds[1]).not.toBeNull();
  206 |   expect(mobileButtonBounds[0]!.y).toBe(mobileButtonBounds[1]!.y);
  207 |   await page.screenshot({
  208 |     path: `${screenshotDir}/narrow-mobile.png`,
  209 |     fullPage: true,
  210 |   });
  211 | });
  212 | 
  213 | test("temporary Downloads and Videos provider visual inspection", async ({ page }) => {
  214 |   const rows = [{
  215 |     id: "local-fixture-row",
  216 |     projectId: "000936e1-dc7a-4421-988b-d4c66a804aed",
  217 |     clipId: "c2989a6e-7cae-4cbf-84f2-51a44ddfd1fa",
  218 |     title: "Google Flow - AI Creative Studio",
  219 |     detailUrl: "https://flow.google.com/project/000936e1-dc7a-4421-988b-d4c66a804aed/edit/c2989a6e-7cae-4cbf-84f2-51a44ddfd1fa",
  220 |     routeVerified: true,
  221 |     thumbnail: { available: false },
  222 |   }];
  223 |   await page.addInitScript((fixtureRows) => {
  224 |     Object.defineProperty(window, "chrome", {
  225 |       configurable: true,
  226 |       value: {
  227 |         runtime: {
  228 |           sendMessage: async (request: { requestId: string; protocolVersion: number; buildId: string; type: string }) => ({
  229 |             requestId: request.requestId,
  230 |             protocolVersion: request.protocolVersion,
  231 |             buildId: request.buildId,
  232 |             ok: true,
  233 |             data: request.type === "flow.clipImport.list"
  234 |               ? fixtureRows
  235 |               : request.type === "flow.downloadDiagnostic.get"
  236 |                 ? { status: "idle" }
  237 |                 : null,
  238 |           }),
  239 |         },
  240 |       },
  241 |     });
  242 |   }, rows);
  243 |   await page.setViewportSize({ width: 1440, height: 900 });
  244 |   await page.goto("http://127.0.0.1:5173/", { waitUntil: "networkidle" });
  245 |   await page.getByRole("button", { name: "Downloads" }).click();
  246 |   await expect(page.getByRole("heading", { name: "Downloads", level: 1 })).toBeVisible();
  247 |   const downloads = page.locator("[class*=providerChoices]");
  248 |   const downloadCards = downloads.locator("label");
  249 |   await expect(downloadCards).toHaveCount(2);
  250 |   const desktopCards = await Promise.all([0, 1].map(async (i) => downloadCards.nth(i).boundingBox()));
  251 |   expect(desktopCards[0]).not.toBeNull();
  252 |   expect(desktopCards[1]).not.toBeNull();
  253 |   expect(Math.abs(desktopCards[0]!.y - desktopCards[1]!.y)).toBeLessThanOrEqual(2);
  254 |   await expect(page.getByRole("heading", { name: "Flow Downloads", level: 2 })).toBeVisible();
> 255 |   await expect(page.getByRole("heading", { name: "Video · c2989a6e" })).toBeVisible();
      |                                                                         ^ Error: expect(locator).toBeVisible() failed
  256 |   await expect(page.getByText("Not started")).toBeVisible();
  257 |   await expect(page.getByRole("button", { name: "Download 1080p" })).toBeVisible();
  258 |   await page.screenshot({ path: "C:/Users/ASUS/AppData/Local/Temp/automat-downloads-desktop.png", fullPage: true });
  259 |   await page.setViewportSize({ width: 390, height: 844 });
  260 |   const mobileCards = await Promise.all([0, 1].map(async (i) => downloadCards.nth(i).boundingBox()));
  261 |   expect(mobileCards[0]).not.toBeNull();
  262 |   expect(mobileCards[1]).not.toBeNull();
  263 |   expect(mobileCards[1]!.y).toBeGreaterThan(mobileCards[0]!.y);
  264 |   expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(390);
  265 |   await page.screenshot({ path: "C:/Users/ASUS/AppData/Local/Temp/automat-downloads-mobile.png", fullPage: true });
  266 |   await page.locator('[name="download-provider"][value="Vids"]').check();
  267 |   await expect(page.getByRole("heading", { name: "Vids Downloads", level: 2 })).toBeVisible();
  268 |   await expect(page.getByRole("heading", { name: "Unavailable" })).toBeVisible();
  269 | 
  270 |   await page.getByRole("button", { name: "Videos" }).click();
  271 |   await page.setViewportSize({ width: 1440, height: 900 });
  272 |   const videoCards = page.locator("[class*=destinationOptions] label");
  273 |   await expect(videoCards).toHaveCount(2);
  274 |   const videoDesktop = await Promise.all([0, 1].map(async (i) => videoCards.nth(i).boundingBox()));
  275 |   expect(Math.abs(videoDesktop[0]!.y - videoDesktop[1]!.y)).toBeLessThanOrEqual(2);
  276 |   await page.screenshot({ path: "C:/Users/ASUS/AppData/Local/Temp/automat-videos-desktop.png", fullPage: true });
  277 |   await page.setViewportSize({ width: 390, height: 844 });
  278 |   const videoMobile = await Promise.all([0, 1].map(async (i) => videoCards.nth(i).boundingBox()));
  279 |   expect(videoMobile[1]!.y).toBeGreaterThan(videoMobile[0]!.y);
  280 |   expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(390);
  281 |   await page.screenshot({ path: "C:/Users/ASUS/AppData/Local/Temp/automat-videos-mobile.png", fullPage: true });
  282 | });
  283 | 
```