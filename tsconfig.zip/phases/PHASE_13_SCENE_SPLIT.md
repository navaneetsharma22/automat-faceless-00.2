# P13 — Individual scene files through the native FFmpeg companion
Status: NOT_STARTED in the fresh implementation.

**Outcome:** The combined Vids MP4 becomes separately named scene videos using measured, explicit cut boundaries.

**Prerequisites:** P12, P08.

**Requirements:** R23, R25, C10, C11.
## Required context
- [Agent instructions](../AGENTS.md)
- [Current status](../PROJECT_STATUS.md)
- [DATA_MODEL.md](../DATA_MODEL.md)
- [LEGACY_REUSE.md](../LEGACY_REUSE.md)
- [ACCEPTANCE_CRITERIA.md](../ACCEPTANCE_CRITERIA.md)
- [TESTING.md](../TESTING.md)

## One-by-one subphases
The file lists below are planned paths in the new project. They are the initial editing scope, not a claim that source already exists. A necessary dependency edit may be added with an explanation; preserve unrelated work.

### P13.1 — Define the scene manifest and actual-boundary provenance
Evidence mode: **offline**.
Start in these files:

- src/domain/media/sceneManifest.ts
- src/app/features/downloads/SceneManifest.tsx
- tests/unit/sceneManifest.test.ts

Acceptance: Map actual edited timeline order to measured source-frame start/end times. Different scene lengths/gaps are explicit; never infer all cuts from count or prompt duration.

### P13.2 — Adapt the existing local splitter without changing its boundary contract
Evidence mode: **offline**.
Start in these files:

- tools/local-mp4-splitter/split-combined-mp4.mjs
- tools/local-mp4-splitter/Run-Local-Vids-Split.ps1
- tools/local-mp4-splitter/Run-Local-Vids-Split.cmd
- tests/unit/localSplitter.test.ts

Acceptance: Retain input MP4; refuse overwrite; validate boundaries; re-encode explicit cuts and verify video frames/duration/audio with ffprobe.

### P13.3 — Provide a clear export-to-companion workflow
Evidence mode: **offline**.
Start in these files:

- src/app/features/downloads/SplitHandoff.tsx
- src/domain/media/sceneManifest.ts
- tools/local-mp4-splitter/README.md
- tests/integration/splitHandoff.test.ts

Acceptance: Export the reviewed manifest and show the source/output selection steps. Do not pretend the extension can run local FFmpeg without a separately installed bridge.

### P13.4 — Verify two clips and a representative multi-scene combined file
Evidence mode: **local-media**.
Start in these files:

- docs/evidence/scene-split-media.md
- PROJECT_STATUS.md

Acceptance: Check real boundary frames, expected output count/names, per-clip durations/audio, retained source and no neighbouring content at sampled cuts. Report the local media evidence honestly.

## Phase gate
G-SPLIT passes. Existing historical two-clip evidence is reused as background, not substituted for this file's verification.

## Notes
- The default companion is user-launched; native messaging/automatic scene detection are outside v1.
- A combined file being 100 seconds does not prove ten exact ten-second scenes.
- If actual boundary evidence is missing, do not produce guessed clips.

## Ready-to-copy first task

~~~text
Implement only P13.1 from phases/PHASE_13_SCENE_SPLIT.md.
Read AGENTS.md and PROJECT_STATUS.md first, then the context named in this card.
Start with this subphase's file list. Preserve unrelated work and legacy data.
Complete its acceptance checks. Live actions are excluded unless the user separately
includes a specific controlled live test in this task.
Do not start the next subphase. Update PROJECT_STATUS.md and report actual evidence.
~~~

## Completion report

State changed files and resulting behaviour, focused checks with actual output, relevant live/local-media evidence, remaining gaps and the next eligible subphase. Update PROJECT_STATUS.md, then stop. A required live gate remains NOT_RUN if no authorized runtime was available.

## Current task boundary

This card is a future work specification. Its presence does not authorize running live provider actions now. Follow the actual user task's authorization. Start only the requested subphase, not every row in this card.
