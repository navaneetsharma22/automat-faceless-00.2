# P12 — Vids manual timeline and authorized whole-MP4 download
Status: NOT_STARTED in the fresh implementation.

**Outcome:** After the user prepares the timeline, reuse the hosted OAuth/Drive route to download the correct full MP4.

**Prerequisites:** P10, P02.

**Requirements:** R20, R21, R22, R24, C10, C11.
## Required context
- [Agent instructions](../AGENTS.md)
- [Current status](../PROJECT_STATUS.md)
- [LEGACY_REUSE.md](../LEGACY_REUSE.md)
- [ARCHITECTURE.md](../ARCHITECTURE.md)
- [DATA_MODEL.md](../DATA_MODEL.md)
- [TESTING.md](../TESTING.md)

## One-by-one subphases
The file lists below are planned paths in the new project. They are the initial editing scope, not a claim that source already exists. A necessary dependency edit may be added with an explanation; preserve unrelated work.

### P12.1 — Adapt the existing helper configuration and OAuth identity
Evidence mode: **offline**.
Start in these files:

- external/vids-helper/app.js
- external/vids-helper/logic.js
- external/vids-helper/index.html
- public/manifest.json
- src/shared/schemas.ts
- tests/unit/hostedHelper.test.ts

Acceptance: Preserve GIS/Picker/Drive separation; deliberate extension-ID/origin configuration; API key/token remain private and are not in downloadable source. Do not redeploy during a code-only task.

### P12.2 — Add the manual timeline-ready handoff
Evidence mode: **offline**.
Start in these files:

- src/app/features/downloads/VidsTimelineReady.tsx
- src/domain/media/combinedExport.ts
- tests/unit/vidsTimelineReady.test.ts

Acceptance: User inserts the desired scenes manually, checks actual order/saved state and declares the exact document ready. No automatic insertion/deletion or assumed ten-second layout.

### P12.3 — Prepare MP4 and connect the bounded extension download handoff
Evidence mode: **offline**.
Start in these files:

- external/vids-helper/app.js
- external/vids-helper/logic.js
- src/background/handlers/vidsDownload.ts
- src/background/downloadManager.ts
- tests/integration/vidsDriveDownload.test.ts

Acceptance: Use files.download with video/mp4 and operation polling; exact document/canDownload/authorized helper binding. Missing response does not launch a second operation. Keep browser complete distinct from playback.

### P12.4 — Verify the actual combined Vids download
Evidence mode: **live-auth-and-download**.
Start in these files:

- docs/evidence/vids-drive-download.md
- PROJECT_STATUS.md

Acceptance: Exact intended document produces a playable/probed combined MP4 with the user's manually inserted scenes. Record actual timeline/media length and transport identity.

## Phase gate
G-VIDS-DOWNLOAD passes through the adapted configured helper. The full timeline MP4 is not claimed to be an isolated clip.

## Notes
- OAuth/Picker consent may require the user; this does not make authentication a missing feature.
- Hosted helper and Chrome Identity accounts/file grants are separate.
- No generation is repeated because the export/download transport fails.

## Ready-to-copy first task

~~~text
Implement only P12.1 from phases/PHASE_12_VIDS_DRIVE_DOWNLOAD.md.
Read AGENTS.md and PROJECT_STATUS.md first, then the context named in this card.
Start with this subphase's file list. Preserve unrelated work and legacy data.
Complete its acceptance checks. Live actions are excluded unless the user separately
includes a specific controlled live test in this task.
Do not start the next subphase. Update PROJECT_STATUS.md and report actual evidence.
~~~

## Completion report

State changed files and resulting behaviour, focused checks with actual output, relevant live/local-media evidence, remaining gaps and the next eligible subphase. Update PROJECT_STATUS.md, then stop. A required live gate remains NOT_RUN if no authorized runtime was available.

## Current task boundary

This card is a future work specification. Its presence does not authorize running live provider actions now. Follow the actual user task's authorization. Start only the requested subphase, not every row in this card.
