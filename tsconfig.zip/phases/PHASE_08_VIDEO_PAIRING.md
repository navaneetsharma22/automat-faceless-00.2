# P08 — Large video JSON import, pairing and destination choice
Status: P08.1, P08.2, and P08.3 OFFLINE_VERIFIED. AC14–AC17 pass offline. Phase 08 local preparation scope is COMPLETE. Live provider execution (P09/P10) remains NOT_RUN.

**Outcome:** All selected images and full video JSON bodies are reviewed as correct pairs before execution.

**Prerequisites:** P03, P07.

**Requirements:** R12, R13, R14, R16, R17, R18, C01, C03, C14.
## Required context
- [Agent instructions](../AGENTS.md)
- [Current status](../PROJECT_STATUS.md)
- [INPUT_FORMAT.md](../INPUT_FORMAT.md)
- [DATA_MODEL.md](../DATA_MODEL.md)
- [DESIGN.md](../DESIGN.md)

## One-by-one subphases
The file lists below are planned paths in the new project. They are the initial editing scope, not a claim that source already exists. A necessary dependency edit may be added with an explanation; preserve unrelated work.

### P08.1 — Use the common importer for long video JSON
Evidence mode: **offline**.
Start in these files:

- src/app/features/video-batch/ImportPanel.tsx
- src/domain/batches/importBatch.ts
- tests/integration/videoJsonImport.test.ts

Acceptance: Camera/colour/direction/Premiere/text/After Effects/duration content is retained verbatim and never treated as extension commands.

P08.1 review (1 November 2026): existing shared importer, preview session, import UI, repository and saved-source export satisfy this boundary. Video remains arbitrary JSON and keeps source-span bodies; no video-specific schema or duration interpretation was added. Focused regressions are in `tests/integration/promptPreservation.test.ts` and `tests/integration/importPreview.test.ts` because the task-named `tests/integration/videoJsonImport.test.ts` does not exist. See [prompt preservation evidence](../docs/evidence/prompt-preservation.md).

### P08.2 — Build stable pairing validation and preview
Evidence mode: **offline**.
Start in these files:

- src/domain/batches/pairShots.ts
- src/app/features/video-batch/PairingTable.tsx
- tests/unit/pairShots.test.ts

Acceptance: Join explicit shot IDs. Missing/duplicate/orphan items are visible. Reorder/filter/reselection never shifts remaining images onto the wrong prompts.

P08.2 review (1 November 2026): implemented pure deterministic validator `validateAndPairVideoShots` in `src/domain/batches/pairShots.ts` joining on `(workspaceId, selectedImageSourceBatchId, canonicalShotId)`. Structured validation reports missing Shot IDs, duplicate canonical Shot IDs, missing references, wrong workspace/source bindings, invalid media metadata, and stale assignments. Unused references in the selected image source remain informational and nonblocking. `PairingTable` in `src/app/features/video-batch/` renders explicit image source selection, summary bar, thumbnail loading through P07 local media path, expandable raw video JSON disclosures, and links to References workspace. Focused unit and integration regressions pass in `tests/unit/pairShots.test.ts` (13/13), `tests/integration/videoPairing.test.ts` (5/5), and `tests/unit/pairingTablePresentation.test.tsx` (5/5). See [video pairing evidence](../docs/evidence/video-pairing.md).

### P08.3 — Add exclusive provider routing and manual settings confirmation
Evidence mode: **offline**.
Start in these files:

- src/app/features/video-batch/Destination.tsx
- src/app/components/SettingsConfirmation.tsx
- src/domain/batches/types.ts
- tests/integration/videoBatchPreparation.test.ts

Acceptance: Exactly one Flow/Vids destination is snapshotted. User-selected duration is not offset or changed; confirmation names that platform. Invalid pairings cannot start.

P08.3 review (1 November 2026): implemented exclusive destination selection (Flow or Vids), connected target verification requirement, user-declared tracking duration (seconds), and manual confirmation wording *"I manually selected and checked the settings in Flow/Vids for this batch."* Confirmation resets automatically on any destination, target, duration, draft, or reference assignment version change. "Prepare video batch" action independently validates authoritative state and commits an immutable prepared snapshot atomically to `preparedVideoBatches`, pinning reference media records to `pinnedReferenceMedia` so subsequent reference changes in P07 leave the prepared snapshot and its thumbnails/byte readbacks intact. Tested extensively with 13/13 integration tests in `tests/integration/videoBatchPreparation.test.ts` and 7/7 UI unit tests in `tests/unit/destinationPresentation.test.tsx`. See [video pairing evidence](../docs/evidence/video-pairing.md).

## Phase gate
AC14–AC17 pass offline and the user can review the complete intended pairs and destination. Phase 08 local preparation scope is COMPLETE. Live provider execution (P09/P10) remains NOT_RUN.

## Notes
- Do not introduce a third destination.
- There is no Adobe automation integration: effect directions remain prompt data.
- Provider generation comes only in P09/P10.

## Ready-to-copy first task

~~~text
Implement only P08.1 from phases/PHASE_08_VIDEO_PAIRING.md.
Read AGENTS.md and PROJECT_STATUS.md first, then the context named in this card.
Start with this subphase's file list. Preserve unrelated work and legacy data.
Complete its acceptance checks. Live actions are excluded unless the user separately
includes a specific controlled live test in this task.
Do not start the next subphase. Update PROJECT_STATUS.md and report actual evidence.
~~~

## Completion report

State changed files and resulting behaviour, focused checks with actual output, relevant live/local-media evidence, remaining gaps and the next eligible subphase. Update PROJECT_STATUS.md, then stop. A required live gate remains NOT_RUN if no authorized runtime was available.

## Current task boundary

This card is a future work specification. Its presence does not authorize running live provider actions now. Follow the actual user task's authorization. Start only the requested subphase, not every row in this card.
