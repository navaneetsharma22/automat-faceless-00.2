# P01 — Premium design system and dashboard shell
Status: **DONE — UI/design scope.** P01.1, P01.2, and P01.3 are implemented; design approval is USER_APPROVED. The user's narrow-window, editor keyboard/focus, toast, and reduced-motion confirmations are recorded as USER_REPORTED_PASS in [UI review evidence](../docs/evidence/ui-review.md). These confirmations are not independent browser observations or automated checks. Provider functionality and later phases remain outside this completion.

**Outcome:** A readable, consistent light/dark workspace before provider workflow complexity is added.

**Prerequisites:** P00.1 for design foundations; P02.1 before compiling/verifying P01.2 and P01.3 UI tasks.

**Requirements:** R01, R02, R03, R09, R17, C07, C08, C14.
## Required context
- [Agent instructions](../AGENTS.md)
- [Current status](../PROJECT_STATUS.md)
- [DESIGN.md](../DESIGN.md)
- [PROJECT.md](../PROJECT.md)
- [REQUIREMENTS.md](../REQUIREMENTS.md)

## One-by-one subphases
The file lists below are planned paths in the new project. They are the initial editing scope, not a claim that source already exists. A necessary dependency edit may be added with an explanation; preserve unrelated work.

### P01.1 — Create semantic theme tokens and typography/spacing foundations
Evidence mode: **offline**.
Start in these files:

- `src/app/styles/tokens.css`
- `src/app/styles/globals.css`
- `DESIGN.md`

Acceptance: Semantic theme roles, typography, spacing, geometry, shadows, layering and subtle/reduced motion resolve under the root `data-theme` in light and dark. Text/accent contrast is checked. DESIGN.md specifies accessible toast behaviour for the later P01.2 components. No unnecessary unit tests for CSS numbers.

### P01.2 — Build the shared control set
Evidence mode: **offline + local rendered preview**.
Start in these files:

- src/app/components/Button.tsx
- src/app/components/Field.tsx
- src/app/components/Select.tsx
- src/app/components/JsonEditor.tsx
- src/app/components/Notice.tsx
- src/app/components/SettingsConfirmation.tsx
- src/app/components/Toast.tsx
- src/app/components/ToastHost.tsx
- src/app/components/toastManager.ts
- src/app/components/controls.test.tsx
- src/app/components/toastManager.test.ts

Acceptance: Buttons, fields, select, exact-string JSON editor, inline notice, and controlled manual settings confirmation use shared tokens and accessible states. Toast and ToastHost provide four variants, polite/assertive announcement rules, a bounded newest-first stack, deduplication, dismissal, auto-dismiss, hover/focus pause, and timer cleanup. The labeled component preview demonstrates both themes without simulating provider activity. Focused behavior tests and typecheck/lint/format/build pass.

### P01.3 — Compose the main screen shell and request visual review
Evidence mode: **visual**.
Start in these files:

- src/app/App.tsx
- src/app/components/Navigation.tsx
- src/app/components/ConnectionStatus.tsx
- src/app/components/ProgressPanel.tsx
- docs/evidence/ui-review.md

Acceptance: User reviews both themes, a long JSON view, reference cards, pairing errors and a narrow viewport. Record actual feedback; do not claim approval from a screenshot generator.

Implementation evidence: Dashboard shell and labeled workspace demonstrations are implemented. Final visual approval was confirmed by the user; the user's reported passes and the separate automated evidence are recorded in [UI review evidence](../docs/evidence/ui-review.md).

## Phase gate
**Phase 01 gate: DONE within the UI/design scope.** P01.1 token and motion foundations, P01.2 shared components, and P01.3 dashboard composition are implemented. User visual approval is recorded as USER_APPROVED, with the specific reported interaction/accessibility passes distinguished from independent and automated evidence. Provider buttons remain disabled placeholders with clear reasons until their later phases. P00.2 representative prompt evidence remains pending; Phase 02 and later remain NOT_STARTED.

## Notes
- Use the user-selected dark-theme neon lime `#9BEC00` for the primary accent and focus ring; use `#B4FF35` for hover. Keep it restrained to focus, selected controls, and small accents.
- The primary dashboard is a full extension tab; a compact launcher is enough for v1.
- Do not fill the main screen with legacy Inspect/settlement/debug panels.

## Ready-to-copy first task

~~~text
Implement only P01.1 from phases/PHASE_01_DESIGN.md.
Read AGENTS.md and PROJECT_STATUS.md first, then the context named in this card.
Start with this subphase's file list. Preserve unrelated work and legacy data.
Complete its acceptance checks. Live actions are excluded unless the user separately
includes a specific controlled live test in this task.
Do not start the next subphase. Update PROJECT_STATUS.md and report actual evidence.
~~~

## Completion report

State changed files and resulting behaviour, focused checks with actual output, relevant live/local-media evidence, remaining gaps and the next eligible subphase. Update PROJECT_STATUS.md, then stop. A required live gate remains NOT_RUN if no authorized runtime was available.

## Current task boundary

This card is a future work specification. Its presence does not authorize running live provider actions now. Follow the actual user task's authorization. Start only the requested subphase, not every row in this card.
