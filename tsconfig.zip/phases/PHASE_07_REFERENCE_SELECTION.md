# P07 — Manual Flow selection and stable reference capture
Status: P07.1, P07.2 and P07.3 acceptance for Phase 07 scope COMPLETE. Synthetic selection/capture/reorder tests pass; user-reported live picker/save evidence is recorded separately. Direct Flow click/right-click alternatives remain unverified. P08 video pairing remains out of scope.

**Outcome:** The user's chosen Flow images appear under correct shot IDs and remain usable after reload.

**Prerequisites:** P03, P06.

**Requirements:** R10, R11, R13, C03.
## Required context
- [Agent instructions](../AGENTS.md)
- [Current status](../PROJECT_STATUS.md)
- [DATA_MODEL.md](../DATA_MODEL.md)
- [DESIGN.md](../DESIGN.md)
- [LEGACY_REUSE.md](../LEGACY_REUSE.md)

## One-by-one subphases
The file lists below are planned paths in the new project. They are the initial editing scope, not a claim that source already exists. A necessary dependency edit may be added with an explanation; preserve unrelated work.

### P07.1 — Adapt explicit gallery selection into shot-labelled sessions
Evidence mode: **offline**.
Start in these files:

- src/platforms/flow/references.ts
- src/app/features/references/ReferenceSelection.tsx
- tests/unit/referenceSelection.test.ts

Acceptance: The user selects the desired card in Flow for an explicit shot; no favourite inferred by card order, gallery position or generation completion.

### P07.2 — Capture usable reference data and provenance
Evidence mode: **offline**.
Start in these files:

- src/platforms/flow/references.ts
- src/domain/media/references.ts
- src/storage/repositories.ts
- tests/integration/referenceCapture.test.ts

Acceptance: Store usable image bytes/metadata and stable identity, not an unusable cross-context blob URL alone. Retain existing completed captures if another capture fails.

### P07.3 — Review, reselect and persist shot assignments
Evidence mode: **live-read-only**.
Start in these files:

- src/app/features/references/ReferenceGrid.tsx
- src/domain/media/references.ts
- tests/integration/referenceAssignments.test.ts
- docs/evidence/reference-capture.md

Acceptance: Selections stay with the correct shot after reorder/reselection/reload; the actual selected image is visibly checked.

### Phase 07 acceptance review — 1 November 2026

| Acceptance item | Evidence and disposition |
| --- | --- |
| R10 — user explicitly chooses the intended Flow image | The extension-owned References picker is the supported selection path. User-reported live evidence confirms previews loaded and the user chose and saved the stated images for Shots 34 and 35. The older direct Flow click and right-click alternatives are unverified and are not used as acceptance evidence. |
| P07.1 — no gallery-order or generation-completion inference | Existing candidate identity/session tests bind an explicit candidate to its requested Shot. Picker choice requires a successfully loaded preview and explicit `Choose for Shot <ID>` action. |
| P07.2 — usable image bytes and stable provenance | Existing synthetic capture tests verify decoded image bytes, SHA-256, metadata and real IndexedDB persistence. User-reported live image persistence is not byte/hash verification. |
| P07.3 — Shot assignment survives reselect, save, reload and display reorder | The focused UI test checks distinct per-Shot media IDs, hashes and loaded thumbnail URLs; it saves a Shot 35 replacement, then remounts in order 36/34/35 and checks all three associations. A separate Playwright fixture uses real IndexedDB and production repository APIs, saves distinct decoded PNGs for stable Shot IDs 34/35/36, closes/reopens the database, replaces only Shot 35 with different bytes, reopens again, and verifies identity/hash/bytes for order 36/34/35. The saved source text is unchanged. User-reported live evidence confirms Shot 34 forest and Shot 35 Jaguar remained displayed after dashboard refresh; reselect/cancel preserved the saved image. |
| “Actual selected image is visibly checked” | The References review displays the saved image thumbnail under the exact Shot ID, with its saved media identity and SHA-256. The UI regression verifies each thumbnail is associated with its own Shot after reorder and replacement. No additional confirmation behavior was introduced. |
| R13 / C03 contribution within P07 | P07 binds the saved image to the source batch, exact prompt hash and stable Shot ID. The P08 video-pair execution/attempt/provider-result portion remains future-phase scope and is not claimed complete here. |

Decision: **G-REFERENCE passes for the existing Phase 07 acceptance boundary.** User-reported live evidence is not an installed-build verification or an automated test. No package was built for this test/documentation-only review. P06 behavior and P08 scope were not changed.

## Phase gate
G-REFERENCE passes. Diagnostic slots have been replaced/adapted into explicit product shot identity.

## Notes
- One selected reference per shot is the proposed v1 default.
- Reselecting does not alter the snapshot of an already executing video batch.

## Ready-to-copy first task

~~~text
Implement only P07.1 from phases/PHASE_07_REFERENCE_SELECTION.md.
Read AGENTS.md and PROJECT_STATUS.md first, then the context named in this card.
Start with this subphase's file list. Preserve unrelated work and legacy data.
Complete its acceptance checks. Live actions are excluded unless the user separately
includes a specific controlled live test in this task.
Do not start the next subphase. Update PROJECT_STATUS.md and report actual evidence.
~~~

## Completion report

State changed files and resulting behaviour, focused checks with actual output, relevant live/local-media evidence, remaining gaps and the next eligible subphase. Update PROJECT_STATUS.md, then stop. A required live gate remains NOT_RUN if no authorized runtime was available.

## Current task boundary

This card is a future work specification. Its presence does not authorize running live provider actions now. Follow the actual user task's authorization. Start only the requested subphase, not every row in this card.
