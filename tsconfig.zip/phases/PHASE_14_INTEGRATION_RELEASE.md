# P14 — Full workflow verification, packaging and handoff
Status: NOT_STARTED in the fresh implementation.

**Outcome:** A packaged, understandable extension completes the agreed workflow with documented limits.

**Prerequisites:** P01, P06, P07, P08, P09, P10, P11, P12, P13.

**Requirements:** R01, R04, R07, R13, R18, R19, R20, R23, C08, C11.
## Required context
- [Agent instructions](../AGENTS.md)
- [Current status](../PROJECT_STATUS.md)
- [ACCEPTANCE_CRITERIA.md](../ACCEPTANCE_CRITERIA.md)
- [TESTING.md](../TESTING.md)
- [DESIGN.md](../DESIGN.md)
- [PROJECT_STATUS.md](../PROJECT_STATUS.md)

## One-by-one subphases
The file lists below are planned paths in the new project. They are the initial editing scope, not a claim that source already exists. A necessary dependency edit may be added with an explanation; preserve unrelated work.

### P14.1 — Run integrated workflow and reliability regressions
Evidence mode: **integration-and-authorized-live**.
Start in these files:

- tests/integration/fullWorkflow.test.ts
- tests/browser/workflow.spec.ts
- docs/evidence/integration-matrix.md

Acceptance: Both destinations pass in separate runs: long image JSON -> selection -> long video JSON -> correct files. Include pause/restart, delayed response, missing pair, generation error and download interruption without replay.

### P14.2 — Package the fresh extension and companion instructions
Evidence mode: **offline**.
Start in these files:

- public/manifest.json
- package.json
- README.md
- docs/USER_GUIDE.md
- docs/INSTALL.md
- docs/RELEASE_CHECKLIST.md
- PROJECT_STATUS.md

Acceptance: Reproducible build/identity/configuration instructions; no secrets or legacy state bundled; clear helper/FFmpeg prerequisites and download limits.

### P14.3 — Complete user visual review and release evidence ledger
Evidence mode: **visual-and-live**.
Start in these files:

- docs/evidence/ui-review.md
- docs/evidence/integration-matrix.md
- PROJECT_STATUS.md

Acceptance: Record actual user feedback for both themes and end-to-end operation. Mark only passed capabilities live/media verified; unresolved gates remain explicit.

## Phase gate
G-INTEGRATED and applicable AC01–AC30 pass. This is release readiness, not an automatic publish/store submission.

## Notes
- Publishing the helper, deploying anything or submitting to a store requires its own user request; packaging is authorized within the phase.
- Do not claim the whole app complete if Flow download or either video destination is still blocked.

## Ready-to-copy first task

~~~text
Implement only P14.1 from phases/PHASE_14_INTEGRATION_RELEASE.md.
Read AGENTS.md and PROJECT_STATUS.md first, then the context named in this card.
Start with this subphase's file list. Preserve unrelated work and legacy data.
Complete its acceptance checks. Live actions are excluded unless the user separately
includes a specific controlled live test in this task.
Do not start the next subphase. Update PROJECT_STATUS.md and report actual evidence.
~~~

## Completion report

State changed files and resulting behaviour, focused checks with actual output, relevant live/local-media evidence, remaining gaps and the next eligible subphase. Update PROJECT_STATUS.md, then stop. A required live gate remains NOT_RUN if no authorized runtime was available.

## Current task boundary

This card is a future work specification. Its presence does not authorize running live provider actions now. Follow the actual user task's authorization. Start only the requested subphase, not every row in this card.
