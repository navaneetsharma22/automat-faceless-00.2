# P05 — Attributable image completion
Status: P05.1/P05.2/P05.3 structural observer and revised count-heuristic mode are OFFLINE_VERIFIED. Revised live count-mode acceptance is NOT_RUN. Strict provider identity, causal attempt attribution, and terminal success/error acceptance remain unsupported/deferred; Phase 05 remains INCOMPLETE.

The authorized P06 requirements change makes timed sequential submission independent of P05 completion observation. P05's original automatic attribution/terminal acceptance is still incomplete and **deferred for the timed workflow**, not completed or waived. Count-mode observation and recovery remain separate and do not run for timed queues. No G-IMAGE gate is passed by timed queue storage or dispatch scheduling.

**Outcome:** The extension records either strict provider-attributed completion when its evidence contract is verified, or the explicitly separate count-matched heuristic described below. A heuristic match is not provider success or causal attribution.

**Prerequisites:** P04.

**Requirements:** R07, C03, C05, C11.
## Required context
- [Agent instructions](../AGENTS.md)
- [Current status](../PROJECT_STATUS.md)
- [ARCHITECTURE.md](../ARCHITECTURE.md)
- [DATA_MODEL.md](../DATA_MODEL.md)
- [TESTING.md](../TESTING.md)

## One-by-one subphases
The file lists below are planned paths in the new project. They are the initial editing scope, not a claim that source already exists. A necessary dependency edit may be added with an explanation; preserve unrelated work.

### P05.1 — Capture a current-attempt result baseline
Evidence mode: **offline**.
Start in these files:

- src/platforms/flow/observer.ts
- src/platforms/flow/images.ts
- src/domain/jobs/results.ts
- tests/unit/flowResultAttribution.test.ts

Acceptance: Old cards, lazy-loaded assets, duplicate media and another project are not silently attached to the current attempt.

P05.1 evidence (29 October 2026): the P04 baseline observation is retained and bound to a validated per-attempt result baseline before durable `dispatch-intent`. The selected-workspace empty marker is complete only for the observed UI scope. The labelled gallery profile records its count as incomplete inventory and does not claim the count is a set of result identities. Baseline/profile and workspace/batch/item/source hash/snapshot/attempt/project/tab/frame/loader/build/protocol bindings are revalidated before activation. Stable provider result/asset/group-variant identifiers are modeled conservatively; time/order/media URL/DOM identity alone never attribute a result. Missing identities and incomplete inventories remain ambiguous or excluded. At the P05.1 stage the settings confirmation had no validated variant count, so those baselines stored `variantDeclaration: absent`; P05.2 now captures a user declaration for new attempts.

No live populated Flow result identity, card ownership marker, or lifecycle marker is established by this offline work. Synthetic identity shapes test the contract only and do not claim provider compatibility. P05.1 adds no terminal result handling, completion UI, queue behavior, or lock release. Historical attempts without `resultBaseline` remain schema-compatible; no database migration is introduced.

### P05.2 — Implement terminal/partial/error observation
Evidence mode: **offline**. Status: **OFFLINE_VERIFIED**; production Flow lifecycle support remains **UNSUPPORTED / NOT LIVE_VERIFIED**.
Start in these files:

- src/platforms/flow/observer.ts
- src/background/handlers/observations.ts
- src/domain/jobs/results.ts
- tests/integration/flowObservation.test.ts

Acceptance: Complete only with attributable terminal outputs for the declared variant count; partial work remains pending; ambiguity/error/lost observer has a clear outcome.

P05.2 evidence (29 October 2026): new Generate requests require an integer variant count (1–100) supplied by the user and recorded with that request's explicit manual Flow settings confirmation. The count is copied into the attempt and immutable result baseline before `dispatch-intent`; older attempts keep the field absent and remain unknown for completion. Observation messages are accepted only for the active attempt session from its bound extension tab/frame/document after fresh selection, project, source snapshot/hash and document checks. Result identities and terminal markers are validated, deduplicated by stable logical identity, and reduced to `processing`, `complete`, `partial_error`, `failed`, or explicit `unknown`. Completion requires the exact declared count of distinct attributed successes. Persistence is atomic in the attempt record with receipt-based duplicate handling and readback. Timeout, event loss, binding change, missing declaration, conflicting identity, incomplete baseline, and event/reconciliation bounds do not imply success or provider failure. Restart recovery is read-only and never calls Generate.

These checks use synthetic integration fixtures only. The production worker leaves Flow lifecycle observation unsupported; there is no production event producer or verified populated-result selector/identity/terminal-marker contract. Fixture IDs and markers establish no live compatibility. No new Dexie migration was needed because fields are optional additions to existing attempt rows. No terminal evidence was added to historical attempts, and no lock release, retry, queue advancement, download, or favourite-selection behavior is included. Focused integration verification: `flowObservation.test.ts`, `flowGenerateBoundaries.test.ts`, and `flowResultAttribution.test.ts` — 44 tests PASS. Normal checks and package build evidence are recorded in `PROJECT_STATUS.md` after execution.

### P05.3 — Verify the actual current Flow result lifecycle
Evidence mode: **offline preparation plus separately authorized live-generation acceptance**.
Evidence collection: user-supplied static tile reports and one bounded lifecycle capture are recorded in `docs/evidence/flow-completion.md`; the capture is not bound to a durable attempt. A production Chrome structural observer is implemented behind the worker arm seam and fixture-verified. It binds to the exact tab/document/project and durable attempt/session/build/protocol/source baseline, captures listeners before its baseline and acknowledgement, emits ordered tile-scoped structural observations, and resumes read-only after worker restart. These reports are deliberately reduced to unknown outcomes; they do not implement provider terminal rules. Live-generation acceptance: **NOT_STARTED**. It still requires evidence for `data-media-id` semantics, logical output/variant mapping, and authoritative provider terminal success/error markers correlated to a guarded attempt. Historical screenshots and synthetic fixtures do not satisfy this gate.
Readback status: arm receipt and bounded structural snapshots are now durably retained and available through the one-shot read-only dashboard inspector in `tools/diagnostics/flow-observation-readonly.js`. The readiness connection gate now consumes a worker-persisted binding from the same strict handshake used by the Connections panel; current package build ID is `automat-faceless-0.1.0-mvtjcau6`. The prior package IDs predate the readiness connection-gate correction. The checklist and exact export fields are recorded in `docs/evidence/flow-completion.md`.
Start in these files:

- docs/evidence/flow-completion.md
- PROJECT_STATUS.md

Revised count-mode acceptance (authorized scope change): New empty project mode captures an observed empty UI scope; existing project mode records a user-attested starting image count and an incomplete rendered-candidate baseline. Each attempt freezes the manually declared variant count. The separate durable count decision can match only distinct, visible, correctly tile-owned, complete image candidates with positive natural dimensions observed after the persisted dispatch boundary, after excluding arm-baseline and previously matched candidate hashes. Repeated hashes are deduplicated. Baseline tile reuse, virtualized existing inventory, relevant loading/error signals, extra candidates, gaps, truncation, binding changes, loss, timeout, or readback failure pauses/blocks the count decision. Image load, elapsed time, marker disappearance, and total counts alone do not match. Count-matched remains heuristic and never upgrades provider outcome.

The original strict acceptance remains deferred: establish provider result identity and logical output/variant mapping, causal attempt/source attribution, and authoritative terminal success/error evidence with a controlled live attempt. Count-mode live acceptance is **NOT_RUN**. Synthetic fixtures prove code behavior only.

P05 count mode does not schedule or automatically dispatch a next prompt. A later P06 consumer is out of scope. The existing source lock and uncertain attempts remain unchanged; using new item/batch IDs for intentional source reuse is a separate future policy decision.

## Phase gate
G-IMAGE-ONE remains **INCOMPLETE / NOT VERIFIED**. Exact input and one-dispatch evidence exist in P04 records, but current-attempt terminal-result attribution still requires the P05.3 live identity/lifecycle gate. Synthetic fixtures and historical screenshots do not pass this gate.

## Notes
- Manual favourite selection is not required to mark image generation finished.
- A live attribution limitation is a bounded blocker to queue scale, not a reason to guess ownership.

## Ready-to-copy first task

~~~text
Implement only P05.1 from phases/PHASE_05_FLOW_COMPLETION.md.
Read AGENTS.md and PROJECT_STATUS.md first, then the context named in this card.
Start with this subphase's file list. Preserve unrelated work and legacy data.
Complete its acceptance checks. Live actions are excluded unless the user separately
includes a specific controlled live test in this task.
Do not start the next subphase. Update PROJECT_STATUS.md and report actual evidence.
~~~

## Completion report

State changed files and resulting behaviour, focused checks with actual output, relevant live/local-media evidence, remaining gaps and the next eligible subphase. Update PROJECT_STATUS.md, then stop. A required live gate remains NOT_RUN if no authorized runtime was available.

## Current task boundary

This card is a future work specification. Its presence does not authorize running live provider actions now. Follow the actual user task's authorization. Start only the requested subphase, not every row in this card.
