# P10 — Vids image-to-video generation
Status: NOT_STARTED in the fresh implementation.

**Outcome:** Matched images and long video JSON generate attributable Vids results while timeline insertion remains manual.

**Prerequisites:** P08.

**Requirements:** R12, R16, R18, R21, C04, C05.
## Required context
- [Agent instructions](../AGENTS.md)
- [Current status](../PROJECT_STATUS.md)
- [ARCHITECTURE.md](../ARCHITECTURE.md)
- [DATA_MODEL.md](../DATA_MODEL.md)
- [TESTING.md](../TESTING.md)
- [LEGACY_REUSE.md](../LEGACY_REUSE.md)

## One-by-one subphases
The file lists below are planned paths in the new project. They are the initial editing scope, not a claim that source already exists. A necessary dependency edit may be added with an explanation; preserve unrelated work.

### P10.1 — Resolve the AI composer and attach the intended reference
Evidence mode: **offline**.
Start in these files:

- src/platforms/vids/composer.ts
- src/platforms/vids/references.ts
- tests/unit/vidsVideoReference.test.ts

Acceptance: Bind the actual target document and selected reference; no first-file/input fallback. Existing reference preparation is adapted with its assumptions checked.

### P10.2 — Enter full video JSON and dispatch once
Evidence mode: **offline**.
Start in these files:

- src/platforms/vids/video.ts
- src/background/handlers/vidsVideo.ts
- tests/integration/vidsVideoGenerate.test.ts

Acceptance: Full JSON entry/readback and current reference preflight precede a durable single Generate attempt; preserve input uncertainty and manual settings.

### P10.3 — Isolated persisted Vids timed-submission queue
Status: **IMPLEMENTED / OFFLINE_VERIFIED**. Evidence mode: **offline**.

The Vids queue has its own domain record, IndexedDB table (schema v14), message routes, worker handler/alarm prefix, and Vids prepared-batch controls. It reuses the Vids P10.1 attachment and P10.2 prompt/readback/one-shot Generate handlers. Existing Sent operations are adopted only from exact prepared pair, target/document, prompt/reference hashes, and durable single-activation receipts. Sent never means generated/completed.

Minimum dispatch gap is 50 seconds from the prior durable receipt. Generate readiness starts after the next pair is prepared and has a separate 60-second deadline. Readiness checks use the alarm scheduler; timers in the UI only display persisted timestamps. Pause/Stop prevent later intent claims; resume retains the cooldown/readiness deadline; startup reconciles an exact dispatch receipt and blocks uncertain delivery without replay. Repository transactions reject per-Shot claims while the Vids queue owns the batch. Flow and Images schedulers/timing are unchanged.

Between items, a scoped Vids Animate transition removes the previous reference only after its File or same-document preview-blob SHA-256, MIME/size/dimensions, exact previous prompt body/hash, and durable preceding dispatch operation all match. Conflicting content is preserved. If the verified Animate panel is collapsed, the worker may click its unique scoped Expand control and must rebind and inspect the composer again before any cleanup mutation. Missing or ambiguous controls pause the queue. No arbitrary Clear control is used.

The UI shows durable sent-receipt progress, current/next Shot, Pending/Attaching/Entering prompt/Checking Generate/Sending/Sent/Paused/Stopped/Blocked states, separate cooldown/readiness clocks, and an all-sent submission summary/toast. It never claims video completion. Manual Vids settings confirmation is reused.

Acceptance: A single explicit Start, then timed sequential submission of exact pairs with one Generate attempt per item; no completion attribution, per-Shot acknowledgement, downloads, timeline action, or provider-settings change. P10.4 owns live one-pair then two-pair verification.

### P10.4 — Verify actual Vids one-pair then two-pair generation
Evidence mode: **live-generation**.
Start in these files:

- docs/evidence/vids-video-batch.md
- PROJECT_STATUS.md

Acceptance: Correct selected references and real long JSON reach distinct completed results. User manually handles later timeline insertion.

## Phase gate
G-VIDS-VIDEO passes independently from Flow. A successful hosted download does not prove this generation path.

## Notes
- Do not mistake the old expected-prompt verification snippet for a full video JSON batch importer.
- Do not revive the old automatic scene-replacement/export workflow.

## Ready-to-copy first task

~~~text
Implement only P10.1 from phases/PHASE_10_VIDS_VIDEO.md.
Read AGENTS.md and PROJECT_STATUS.md first, then the context named in this card.
Start with this subphase's file list. Preserve unrelated work and legacy data.
Complete its acceptance checks. Live actions are excluded unless the user separately
includes a specific controlled live test in this task.
Do not start the next subphase. Update PROJECT_STATUS.md and report actual evidence.
~~~

## Completion report

State changed files and resulting behaviour, focused checks with actual output, relevant live/local-media evidence, remaining gaps and the next eligible subphase. Update PROJECT_STATUS.md, then stop. A required live gate remains NOT_RUN if no authorized runtime was available.

## Current task boundary

This card is a future work specification. Its presence does not authorize running live provider actions now. Follow the actual user task's authorization. Start only the requested subphase, not every row in this card.
