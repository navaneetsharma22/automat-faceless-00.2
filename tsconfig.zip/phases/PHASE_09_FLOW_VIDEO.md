# P09 — Flow image-to-video generation
Status: P09.1, P09.2, and P09.3 are OFFLINE_VERIFIED within their recorded offline boundaries; P09.4 live generation gate remains NOT_RUN.

**Outcome:** Matched image + full video JSON pairs generate videos in Flow using manually confirmed settings.

**Prerequisites:** P08, P04, P05.

**Requirements:** R12, R15, R16, R18, C04, C05, C13.
## Required context
- [Agent instructions](../AGENTS.md)
- [Current status](../PROJECT_STATUS.md)
- [ARCHITECTURE.md](../ARCHITECTURE.md)
- [DATA_MODEL.md](../DATA_MODEL.md)
- [TESTING.md](../TESTING.md)
- [DESIGN.md](../DESIGN.md)

## One-by-one subphases
The file lists below are planned paths in the new project. They are the initial editing scope, not a claim that source already exists. A necessary dependency edit may be added with an explanation; preserve unrelated work.

### P09.1 — Resolve video composer and attach the exact reference
Evidence mode: **offline**.
Start in these files:

- src/platforms/flow/video.ts
- src/platforms/flow/references.ts
- tests/unit/flowVideoReference.test.ts

Acceptance: Video mode/reference target is distinguished from image mode; intended image identity is verified. Do not reuse an image Generate resolver without evidence.

### P09.2 — Enter full video JSON and dispatch once
Evidence mode: **offline**.
Start in these files:

- src/platforms/flow/video.ts
- src/background/handlers/flowVideo.ts
- src/domain/jobs/attempt.ts
- tests/integration/flowVideoGenerate.test.ts

Acceptance: Exact long JSON readback, current project/reference preflight and durable intent precede one Generate activation. User's settings are unchanged.

### P09.3 — Timed Flow video submission queue
Evidence mode: **offline**.
Start in these files:

- src/platforms/flow/video.ts
- src/background/generationQueue.ts
- src/domain/jobs/results.ts
- tests/integration/flowVideoQueue.test.ts

Acceptance: After a durable one-shot Generate dispatch receipt, mark the item SENT and schedule the next pair after the 30-second minimum dispatch gap. Use Images-style Generate readiness waiting with a 60-second timeout. Video completion attribution is not a prerequisite for sending the next pair; successful submission does not claim completion. Errors or uncertain delivery pause and never replay. Reuse the shared alarm scheduler and Images control semantics, not a competing queue engine. Settings remain user-controlled.

### P09.4 — Verify real Flow one-pair then two-pair generation
Evidence mode: **live-generation**.
Start in these files:

- docs/evidence/flow-video-batch.md
- PROJECT_STATUS.md

Acceptance: Actual selected image and representative large video JSON produce attributable videos; user-selected Omni 1.1 Flash label/settings are recorded. No auto duration adjustment.

## Phase gate
G-FLOW-VIDEO passes for one pair and then two consecutive pairs; larger video batches are scaled with the same evidence discipline.

## Notes
- Model label is user-provided; verify it exists in the actual intended UI.
- Generation completion does not yet prove download success.

## Ready-to-copy first task

~~~text
Implement only P09.1 from phases/PHASE_09_FLOW_VIDEO.md.
Read AGENTS.md and PROJECT_STATUS.md first, then the context named in this card.
Start with this subphase's file list. Preserve unrelated work and legacy data.
Complete its acceptance checks. Live actions are excluded unless the user separately
includes a specific controlled live test in this task.
Do not start the next subphase. Update PROJECT_STATUS.md and report actual evidence.
~~~

## Completion report

State changed files and resulting behaviour, focused checks with actual output, relevant live/local-media evidence, remaining gaps and the next eligible subphase. Update PROJECT_STATUS.md, then stop. A required live gate remains NOT_RUN if no authorized runtime was available.

## Current task boundary

This card is a future work specification. Its presence does not authorize running live provider actions now. Follow the actual user task's authorization. Start only the requested subphase, not every row in this card.
