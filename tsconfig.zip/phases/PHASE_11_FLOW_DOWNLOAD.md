# P11 — Automatic Flow video downloads
Status: NOT_STARTED in the fresh implementation.

**Outcome:** Each attributable generated Flow video downloads as the correct named file.

**Prerequisites:** P09.

**Requirements:** R19, C03, C11.
## Required context
- [Agent instructions](../AGENTS.md)
- [Current status](../PROJECT_STATUS.md)
- [ARCHITECTURE.md](../ARCHITECTURE.md)
- [DATA_MODEL.md](../DATA_MODEL.md)
- [TESTING.md](../TESTING.md)
- [OPEN_QUESTIONS.md](../OPEN_QUESTIONS.md)

## One-by-one subphases
The file lists below are planned paths in the new project. They are the initial editing scope, not a claim that source already exists. A necessary dependency edit may be added with an explanation; preserve unrelated work.

### P11.1 — Investigate the actual supported/visible Flow download route
Evidence mode: **live-read-only**.
Start in these files:

- src/platforms/flow/downloads.ts
- docs/evidence/flow-download-feasibility.md

Acceptance: Record a demonstrated result-bound download route and URL/control lifecycle. Do not assume the Drive Vids route, a private API or a transferable blob URL.

### P11.2 — Implement result-bound preparation and exact download tracking
Evidence mode: **offline**.
Start in these files:

- src/platforms/flow/downloads.ts
- src/background/downloadManager.ts
- src/app/features/downloads/Downloads.tsx
- tests/integration/flowDownloads.test.ts

Acceptance: Track exact browser download ID, interruption and filename. Other PDFs/MP4s cannot complete the active result's download. No regeneration on download failure.

### P11.3 — Verify real files and batch download association
Evidence mode: **live-download**.
Start in these files:

- docs/evidence/flow-download-proof.md
- PROJECT_STATUS.md

Acceptance: One then two intended video files match their results/shot IDs and actual media properties. Browser complete and media verified are recorded separately.

## Phase gate
G-FLOW-DOWNLOAD passes. If no route is demonstrated, leave this capability BLOCKED and keep already verified generation work intact.

## Notes
- Automatic means acting on an eligible authorized generated result, not guessing from any new download.
- Browser-supported folder/filename behaviour must be stated; arbitrary absolute folder access is not promised.

## Ready-to-copy first task

~~~text
Implement only P11.1 from phases/PHASE_11_FLOW_DOWNLOAD.md.
Read AGENTS.md and PROJECT_STATUS.md first, then the context named in this card.
Start with this subphase's file list. Preserve unrelated work and legacy data.
Complete its acceptance checks. Live actions are excluded unless the user separately
includes a specific controlled live test in this task.
Do not start the next subphase. Update PROJECT_STATUS.md and report actual evidence.
~~~

## Completion report

State changed files and resulting behaviour, focused checks with actual output, relevant live/local-media evidence, remaining gaps and the next eligible subphase. Update PROJECT_STATUS.md, then stop. A required live gate remains NOT_RUN if no authorized runtime was available.

## Current task boundary

This card is a future work specification. Its presence does not authorize running live provider actions now. Follow the actual user task's authorization. Start only the requested subphase, not every row in this card.
