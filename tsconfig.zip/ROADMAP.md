# Complete Build Roadmap — Automat Faceless

Baseline: 28 October 2026. **15 phases; 53 bounded subphases.**
This roadmap includes the entire requested extension, not only an image-generation prototype.

## Product route

Connect Flow/Vids. Configure image settings manually and confirm. Import large image JSON.
Generate images sequentially. Select images manually in Flow. Import large video JSON.
Pair by shot identity. Choose Flow or Vids. Configure video settings manually and confirm.
Generate videos. Download the selected platform's results. For Vids, manually prepare the
timeline, download its whole MP4 through the authorized helper, and obtain separate scene files.

## Phase overview

| Phase | Outcome | Subphases | Exit gate |
| --- | --- | ---: | --- |
| [P00 — Requirements, legacy evidence and clean workspace](phases/PHASE_00_BASELINE.md) | A clean implementation boundary with the current requirements and evidence preserved. | 3 | Current baseline and legacy boundary |
| [P01 — Premium design system and dashboard shell](phases/PHASE_01_DESIGN.md) | A readable, consistent light/dark workspace before provider workflow complexity is added. | 3 | Both themes and shared UI reviewed |
| [P02 — Toolchain, MV3 foundation and platform connections](phases/PHASE_02_FOUNDATION.md) | The new dashboard and worker connect read-only to the intended Flow/Vids targets with visible build identity. | 4 | Actual Flow/Vids connection |
| [P03 — Lossless large JSON import for both stages](phases/PHASE_03_JSON_IMPORT.md) | Large image and video JSON batches become correct, stable, unchanged prompt items. | 4 | Lossless image/video JSON import |
| [P04 — One long image JSON: entry and one Generate](phases/PHASE_04_FLOW_ONE_IMAGE.md) | The extension can enter one actual long JSON in the correct Flow composer and activate Generate once. | 4 | One actual long image JSON + one activation |
| [P05 — Attributable image completion](phases/PHASE_05_FLOW_COMPLETION.md) | Preserve P05 as incomplete; automatic provider attribution and terminal acceptance are deferred for the timed workflow. | 3 | Authoritative provider result identity and terminal evidence remain unverified |
| [P06 — Timed sequential image submission](phases/PHASE_06_IMAGE_QUEUE.md) | Persist an ordered queue and dispatch one prompt at a time at a fixed 40-second interval; generation completion is not observed. | 4 | P06.4 controlled timed submission acceptance and scale |
| [P07 — Manual Flow selection and stable reference capture](phases/PHASE_07_REFERENCE_SELECTION.md) | The user's chosen Flow images appear under correct shot IDs and remain usable after reload. | 3 | Chosen Flow image retains shot identity |
| [P08 — Large video JSON import, pairing and destination choice](phases/PHASE_08_VIDEO_PAIRING.md) | All selected images and full video JSON bodies are reviewed as correct pairs before execution. | 3 | Correct long-video-JSON pairs + one destination |
| [P09 — Flow image-to-video generation](phases/PHASE_09_FLOW_VIDEO.md) | Matched image + full video JSON pairs generate videos in Flow using manually confirmed settings. | 4 | Real Flow video pairs |
| [P10 — Vids image-to-video generation](phases/PHASE_10_VIDS_VIDEO.md) | Matched images and long video JSON generate attributable Vids results while timeline insertion remains manual. | 4 | Real Vids video pairs |
| [P11 — Automatic Flow video downloads](phases/PHASE_11_FLOW_DOWNLOAD.md) | Each attributable generated Flow video downloads as the correct named file. | 3 | Correct Flow video downloads |
| [P12 — Vids manual timeline and authorized whole-MP4 download](phases/PHASE_12_VIDS_DRIVE_DOWNLOAD.md) | After the user prepares the timeline, reuse the hosted OAuth/Drive route to download the correct full MP4. | 4 | Correct whole Vids MP4 through helper |
| [P13 — Individual scene files through the native FFmpeg companion](phases/PHASE_13_SCENE_SPLIT.md) | The combined Vids MP4 becomes separately named scene videos using measured, explicit cut boundaries. | 4 | Verified individual scene files |
| [P14 — Full workflow verification, packaging and handoff](phases/PHASE_14_INTEGRATION_RELEASE.md) | A packaged, understandable extension completes the agreed workflow with documented limits. | 3 | Complete workflow and packaged handoff |

## First-task execution order

P00.1 -> P00.2/P00.3 -> P01.1 design foundations -> P02.1 working toolchain -> P01.2/P01.3 compiled shared UI -> P02.2/P02.3/P02.4 connections -> P03 and the remaining gated phases.

P01/P02 are intentionally interleaved: design decisions happen first, but a compiled React component is not marked verified before project tooling exists. Phase numbering groups work; individual prerequisites determine execution order.

## Ordering rules

- Start design foundations early; P01 and P02 can overlap after the clean workspace boundary.
- P03 supports both image and video JSON before either generation route is scaled.
- One-shot Flow image entry/Generate precedes completion automation.
- Timed image submission scheduling is independent of P05 count-mode observation and strict completion attribution.
- A sent dispatch records action evidence only; provider outcome remains unknown until separately verified.
- Pass two real image prompts before scaling to 5/10/15.
- Reference capture and stable pairing precede video generation.
- Flow and Vids video paths are verified independently. A pass for one does not prove the other.
- After pairing, P09 and P10 can be scheduled independently; do not introduce concurrent live provider queues as a side effect.
- Flow download research is a real capability gap, not an assumed reuse of Drive.
- Reuse Vids OAuth/helper and local splitter; do not redo them from scratch.
- P14 needs both selected video routes and their required downloads verified.

## What each phase delivers

Every card has exact proposed file scopes, one-by-one tasks, acceptance conditions, evidence modes and a ready-to-copy first task. Execute a single subphase per agent request.

Read IMPLEMENTATION_PLAN.md for the task register and AGENT_WORKFLOW.md for the work method.

## Gates, not optimistic percentages

A source module existing is not the same as a successful user workflow. Keep source review, offline checks, live provider success and media verification distinct.

If the real provider contract is unavailable, preserve completed work and report the smallest missing evidence. Do not fix unrelated components or create a new recovery system to force progression.

## Completion boundary

The final deliverable is a premium extension with the agreed manual controls, real long-JSON image/video execution, correct image-to-prompt associations, both destinations, useful downloads and separate Vids scene files.

No calendar estimate is promised here: provider UI evidence and actual prompt sizes determine the work. Report progress by accepted subphase evidence.
