import { z } from "zod";

export const VIDS_VIDEO_DISPATCH_GAP_MS = 50_000 as const;
export const VIDS_VIDEO_READINESS_TIMEOUT_MS = 60_000 as const;
export const VIDS_VIDEO_QUEUE_STATES = ["ready", "cooldown", "preparing", "checking_generate", "waiting_for_tab", "paused", "stopped", "blocked", "all_sent"] as const;
export const VIDS_VIDEO_QUEUE_ITEM_STATES = ["pending", "transitioning", "attaching", "entering_prompt", "checking_generate", "sending", "sent", "blocked", "uncertain"] as const;
export const VidsVideoQueueRunDiagnosticSchema = z.object({
  trigger: z.enum(["automatic_start", "automatic_alarm", "manual_resume", "visibility_wakeup", "unknown"]),
  scheduledAt: z.number().finite().nonnegative().nullable(),
  alarmScheduledAt: z.number().finite().nonnegative().nullable(),
  enteredAt: z.number().finite().nonnegative(),
  stage: z.enum(["alarm_entry", "queue_read", "prepared_validation", "cooldown_check", "claim", "composer_transition", "attachment", "generate", "resume_accepted", "sent_receipt", "skipped", "failed"]),
  claim: z.enum(["not_reached", "claimed", "skipped"]),
  reason: z.string().regex(/^[a-z0-9_]{1,64}$/).optional(),
  dispatchTrigger: z.enum(["automatic_start", "automatic_alarm", "manual_resume", "visibility_wakeup", "unknown"]).optional(),
  outcome: z.enum(["in_progress", "sent", "waiting", "paused", "blocked", "uncertain", "skipped", "failed"]),
  elapsedMs: z.number().int().min(0).max(120_000),
}).strict();
export type VidsVideoQueueRunDiagnostic = z.infer<typeof VidsVideoQueueRunDiagnosticSchema>;
export const VidsVideoAlarmScheduleDiagnosticSchema = z.object({ requestedDueAt: z.number().finite().nonnegative().nullable(), recordedAt: z.number().finite().nonnegative(), outcome: z.enum(["scheduled", "cleared", "failed"]), reason: z.string().regex(/^[a-z0-9_]{1,64}$/).optional() }).strict();
export type VidsVideoAlarmScheduleDiagnostic = z.infer<typeof VidsVideoAlarmScheduleDiagnosticSchema>;
export const VidsVideoAutomaticAlarmTraceSchema = z.object({ receivedAt: z.number().finite().nonnegative(), alarmScheduledAt: z.number().finite().nonnegative().nullable(), queueDeadlineAt: z.number().finite().nonnegative().nullable(), reconciliation: z.enum(["pending", "completed", "failed"]), reconciliationAt: z.number().finite().nonnegative().optional(), reconciliationStep: z.enum(["startup_readiness", "queue_list", "generation_read", "attachment_read", "queue_persist", "alarm_restore"]).optional(), reconciliationErrorCode: z.string().regex(/^[a-z0-9_]{1,64}$/).optional(), reconciliationRecordIndex: z.number().int().min(0).max(999_999).optional(), reconciliationRecordDigest: z.string().regex(/^[0-9a-f]{16}$/).optional(), reconciliationFieldPath: z.string().regex(/^[a-zA-Z0-9_.\x5b\x5d-]{1,128}$/).optional(), reconciliationValidationRule: z.string().regex(/^[a-zA-Z0-9_]{1,64}$/).optional(), handler: z.enum(["not_reached", "reached", "skipped"]).optional(), claim: z.enum(["not_reached", "claimed", "skipped"]).optional(), reason: z.string().regex(/^[a-z0-9_]{1,64}$/).optional(), outcome: z.enum(["in_progress", "waiting", "sent", "failed", "skipped"]).optional(), elapsedMs: z.number().int().min(0).max(120_000) }).strict();
export type VidsVideoAutomaticAlarmTrace = z.infer<typeof VidsVideoAutomaticAlarmTraceSchema>;
export const VidsVideoTransitionCheckpointSchema = z.object({
  // Optional only to read pre-mw01wgpj queue rows. A checkpoint without a
  // stage is stale and must be re-inspected before any cleanup mutation.
  stage: z.enum(["ownership_verified", "image_removed", "prompt_cleared"]).optional(),
  previousItemId: z.string().min(1).max(256), previousAttemptId: z.string().min(1).max(128),
  previousReferenceId: z.string().uuid(), previousReferenceSha256: z.string().regex(/^[0-9a-f]{64}$/), previousPromptHash: z.string().regex(/^[0-9a-f]{64}$/),
  nextItemId: z.string().min(1).max(256), nextReferenceId: z.string().uuid(), nextReferenceSha256: z.string().regex(/^[0-9a-f]{64}$/), nextPromptHash: z.string().regex(/^[0-9a-f]{64}$/),
  tabId: z.number().int().nonnegative(), canonicalTarget: z.string().min(1).max(2048), documentId: z.string().min(1).max(256), verifiedAt: z.number().finite().nonnegative(),
}).strict();
export type VidsVideoTransitionCheckpoint = z.infer<typeof VidsVideoTransitionCheckpointSchema>;
export const VidsVideoExecutionRebindSchema = z.object({
  // Optional on read for queues persisted before cross-tab recovery existed.
  fromTabId: z.number().int().nonnegative().optional(), toTabId: z.number().int().nonnegative().optional(),
  fromDocumentId: z.string().min(1).max(256), toDocumentId: z.string().min(1).max(256),
  projectId: z.string().min(1).max(256), canonicalTarget: z.string().min(1).max(2048),
  verifiedAt: z.number().finite().nonnegative(), sameAccountConfirmedAt: z.number().finite().nonnegative(),
}).strict();
export type VidsVideoExecutionRebind = z.infer<typeof VidsVideoExecutionRebindSchema>;
export const VidsCleanComposerRecoverySchema = z.object({
  tabId: z.number().int().nonnegative(), documentId: z.string().min(1).max(256), canonicalTarget: z.string().min(1).max(2048),
  referenceId: z.string().uuid(), referenceSha256: z.string().regex(/^[0-9a-f]{64}$/), promptHash: z.string().regex(/^[0-9a-f]{64}$/),
  verifiedAt: z.number().finite().nonnegative(),
}).strict();
export const VidsCleanupDiagnosticsSchema = z.object({
  stage: z.enum(["readiness", "ownership", "reference_remove", "prompt_clear", "settlement", "complete", "binding"]),
  editorRebound: z.boolean().optional(), panelRebound: z.boolean().optional(),
  panelStateBeforeExpansion: z.enum(["collapsed", "expanded", "unknown"]).optional(),
  panelStateAfterExpansion: z.enum(["settled", "missing", "unstable", "not_attempted"]).optional(),
  freshPreviewDetection: z.enum(["present", "absent_after_settle", "delayed_then_present", "unknown"]).optional(),
  checkpointRead: z.enum(["absent", "valid", "stale", "not_checked"]).optional(),
  checkpointWrite: z.enum(["not_attempted", "persisted", "failed"]).optional(),
  previewCount: z.number().int().min(0).max(1000).optional(), fileInputCount: z.number().int().min(0).max(1000).optional(),
  expectedPromptSha256: z.string().regex(/^[0-9a-f]{64}$/).optional(), currentPromptSha256: z.string().regex(/^[0-9a-f]{64}$/).optional(),
  expectedPromptLength: z.number().int().min(0).max(10_000_000).optional(), currentPromptLength: z.number().int().min(0).max(10_000_000).optional(),
  clearAvailable: z.enum(["unique", "missing", "ambiguous", "not_checked"]).optional(), settledEmpty: z.boolean().optional(),
  handoffTrace: z.object({
    triggerSource: z.enum(["automatic_start", "automatic_alarm", "manual_resume", "visibility_wakeup", "unknown"]).optional(),
    elapsedSinceReceiptToFirstReadMs: z.number().int().min(0).max(10_000_000).optional(),
    visibilityStart: z.enum(["visible", "hidden", "prerender", "unloaded", "unknown"]).optional(),
    visibilityEnd: z.enum(["visible", "hidden", "prerender", "unloaded", "unknown"]).optional(),
    visibilityChanges: z.array(z.object({ inspection: z.number().int().min(0).max(20), atMs: z.number().int().min(0).max(10_000_000), state: z.enum(["visible", "hidden", "prerender", "unloaded", "unknown"]) }).strict()).max(8).optional(),
    initialAnimateState: z.enum(["collapsed", "expanded", "missing", "ambiguous", "unknown"]).optional(),
    finalAnimateState: z.enum(["collapsed", "expanded", "missing", "ambiguous", "unknown"]).optional(),
    composerToggleLabelBefore: z.enum(["Expand", "Collapse", "missing", "ambiguous", "unknown"]).optional(),
    composerToggleLabelAfter: z.enum(["Expand", "Collapse", "missing", "ambiguous", "unknown"]).optional(),
    composerToggleClickAttempted: z.boolean().optional(),
    composerToggleOutcome: z.enum(["already_expanded", "expanded", "missing", "ambiguous", "disabled", "label_unrecognized", "settlement_failed"]).optional(),
    composerReadinessWaitMs: z.number().int().min(0).max(30_000).optional(),
    composerReadinessOutcome: z.enum(["ready", "timeout_hidden", "timeout_visible"]).optional(),
    composerEditorReady: z.boolean().optional(),
    composerToggleScope: z.enum(["panel", "tabpanel_sibling", "composer_container", "missing", "ambiguous", "unknown"]).optional(),
    composerToggleObservations: z.array(z.object({ atMs: z.number().int().min(0).max(30_000), label: z.enum(["Expand", "Collapse", "missing", "ambiguous", "unknown"]), scope: z.enum(["panel", "tabpanel_sibling", "composer_container", "missing", "ambiguous", "unknown"]), candidateCount: z.number().int().min(0).max(10).optional(), panelCount: z.number().int().min(0).max(10), editorCount: z.number().int().min(0).max(10), visibility: z.enum(["visible", "hidden", "prerender", "unloaded", "unknown"]) }).strict()).max(8).optional(),
    expansionAttempted: z.boolean().optional(), panelReplaced: z.boolean().optional(), editorReplaced: z.boolean().optional(),
    previewObservations: z.array(z.object({ inspection: z.number().int().min(0).max(20), atMs: z.number().int().min(0).max(10_000_000), selectorMatches: z.number().int().min(0).max(10), visibleMatches: z.number().int().min(0).max(10), loadedMatches: z.number().int().min(0).max(10), composerToggleLabel: z.enum(["Expand", "Collapse", "missing", "ambiguous", "unknown"]).optional() }).strict()).max(8).optional(),
  }).strict().optional(),
}).strict();
export type VidsCleanupDiagnostics = z.infer<typeof VidsCleanupDiagnosticsSchema>;
export const VidsResumeRecoveryEvidenceSchema = z.object({
  priorReason: z.string().regex(/^[a-z0-9_]{1,64}$/), verifiedAt: z.number().finite().nonnegative(),
}).strict();
export type VidsVideoQueueItem = {
  itemId: string; order: number; shotId: string; referenceId: string; referenceSha256: string; promptHash: string;
  state: typeof VIDS_VIDEO_QUEUE_ITEM_STATES[number]; reason?: string; attemptId?: string;
  transitionCheckpoint?: VidsVideoTransitionCheckpoint;
  cleanupDiagnostics?: VidsCleanupDiagnostics;
  resumeRecoveryEvidence?: z.infer<typeof VidsResumeRecoveryEvidenceSchema>;
  cleanComposerRecovery?: z.infer<typeof VidsCleanComposerRecoverySchema>;
  dispatchReceipt?: { attemptId: string; storedAt: number };
};
export type VidsVideoQueueRecord = {
  queueId: string; preparedBatchId: string; state: typeof VIDS_VIDEO_QUEUE_STATES[number]; items: VidsVideoQueueItem[];
  revision: number; createdAt: number; updatedAt: number; lastDispatchAt: number | null;
  cooldownDeadlineAt: number | null; readinessDeadlineAt: number | null; readinessStartedAt: number | null;
  nextActionAt: number | null; pauseReason?: string; runId: string;
  executionDocumentRebind?: VidsVideoExecutionRebind;
  lastRunDiagnostic?: VidsVideoQueueRunDiagnostic;
  lastAlarmScheduleDiagnostic?: VidsVideoAlarmScheduleDiagnostic;
  lastAutomaticAlarmTrace?: VidsVideoAutomaticAlarmTrace;
  lastDispatchTrigger?: "automatic_start" | "automatic_alarm" | "manual_resume" | "visibility_wakeup" | "unknown";
};
const itemSchema = z.object({ itemId: z.string().min(1).max(256), order: z.number().int().nonnegative(), shotId: z.string().regex(/^[1-9][0-9]*$/), referenceId: z.string().uuid(), referenceSha256: z.string().regex(/^[0-9a-f]{64}$/), promptHash: z.string().regex(/^[0-9a-f]{64}$/), state: z.enum(VIDS_VIDEO_QUEUE_ITEM_STATES), reason: z.string().regex(/^[a-z0-9_]{1,64}$/).optional(), attemptId: z.string().min(1).max(128).optional(), transitionCheckpoint: VidsVideoTransitionCheckpointSchema.optional(), cleanComposerRecovery: VidsCleanComposerRecoverySchema.optional(), cleanupDiagnostics: VidsCleanupDiagnosticsSchema.optional(), resumeRecoveryEvidence: VidsResumeRecoveryEvidenceSchema.optional(), dispatchReceipt: z.object({ attemptId: z.string().min(1).max(128), storedAt: z.number().finite().nonnegative() }).strict().optional() }).strict();
export const VidsVideoQueueRecordSchema = z.object({ queueId: z.string().min(1).max(512), preparedBatchId: z.string().min(1).max(512), state: z.enum(VIDS_VIDEO_QUEUE_STATES), items: z.array(itemSchema).nonempty().max(100), revision: z.number().int().nonnegative(), createdAt: z.number().finite().nonnegative(), updatedAt: z.number().finite().nonnegative(), lastDispatchAt: z.number().finite().nonnegative().nullable(), cooldownDeadlineAt: z.number().finite().nullable(), readinessDeadlineAt: z.number().finite().nullable(), readinessStartedAt: z.number().finite().nullable(), nextActionAt: z.number().finite().nullable(), pauseReason: z.string().regex(/^[a-z0-9_]{1,64}$/).optional(), runId: z.string().min(1).max(128), executionDocumentRebind: VidsVideoExecutionRebindSchema.optional(), lastRunDiagnostic: VidsVideoQueueRunDiagnosticSchema.optional(), lastAlarmScheduleDiagnostic: VidsVideoAlarmScheduleDiagnosticSchema.optional(), lastAutomaticAlarmTrace: VidsVideoAutomaticAlarmTraceSchema.optional(), lastDispatchTrigger: z.enum(["automatic_start", "automatic_alarm", "manual_resume", "visibility_wakeup", "unknown"]).optional() }).strict().refine((queue) => queue.items.every((item, index) => item.order === index));
