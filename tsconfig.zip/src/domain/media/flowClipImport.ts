import { z } from "zod";

export const FlowClipThumbnailMetadataSchema = z
  .object({
    available: z.boolean(),
    width: z.number().int().nonnegative().max(100_000).optional(),
    height: z.number().int().nonnegative().max(100_000).optional(),
    fingerprint: z.string().regex(/^[a-f0-9]{64}$/).optional(),
  })
  .strict();

export type FlowClipImportRecord = {
  id: string;
  projectId: string;
  clipId: string;
  title: string;
  detailUrl: string;
  galleryImportMethod?: "source_asset" | "native_card_navigation";
  galleryAssetId?: string;
  galleryIdentityEvidence?: "same_card_detail_link" | "detail_selected_asset_match";
  detailSelectedAssetId?: string;
  thumbnail: FlowClipThumbnailMetadata;
  importedAt: number;
  updatedAt: number;
};

export const FlowClipImportRecordSchema: z.ZodType<FlowClipImportRecord> = z
  .object({
    id: z.string().min(1).max(300),
    projectId: z.string().regex(/^[A-Za-z0-9_-]{1,128}$/),
    clipId: z
      .string()
      .regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i),
    title: z.string().max(200),
    detailUrl: z.string().url().max(2048),
    galleryImportMethod: z
      .enum(["source_asset", "native_card_navigation"])
      .optional(),
    galleryAssetId: z.string().uuid().optional(),
    galleryIdentityEvidence: z
      .enum(["same_card_detail_link", "detail_selected_asset_match"])
      .optional(),
    detailSelectedAssetId: z.string().uuid().optional(),
    thumbnail: FlowClipThumbnailMetadataSchema,
    importedAt: z.number().int().nonnegative(),
    updatedAt: z.number().int().nonnegative(),
  })
  .strict()
  .refine(
    (record) => record.id === flowClipImportId(record.projectId, record.clipId),
    { message: "clip_import_key_must_match_identity" },
  )
  .refine((record) => flowClipImportRouteMatches(record), {
    message: "clip_import_route_must_match_identity",
  })
  .refine(
    (record) =>
      (record.galleryAssetId === undefined) ===
      (record.galleryIdentityEvidence === undefined),
    { message: "clip_import_gallery_asset_evidence_must_be_paired" },
  )
  .refine(
    (record) =>
      record.galleryImportMethod !== "native_card_navigation" ||
      (record.detailSelectedAssetId !== undefined &&
        record.galleryAssetId === undefined &&
        record.galleryIdentityEvidence === undefined),
    { message: "native_gallery_import_must_not_claim_source_asset_equality" },
  )
  .refine(
    (record) =>
      record.galleryImportMethod !== "source_asset" ||
      (record.galleryAssetId !== undefined &&
        record.galleryIdentityEvidence !== undefined),
    { message: "source_asset_gallery_import_requires_identity_evidence" },
  )
  .refine(
    (record) =>
      record.galleryIdentityEvidence !== "detail_selected_asset_match" ||
      record.detailSelectedAssetId === undefined ||
      record.detailSelectedAssetId === record.galleryAssetId,
    { message: "selected_detail_asset_must_match_gallery_asset" },
  );

export type FlowClipThumbnailMetadata = z.infer<
  typeof FlowClipThumbnailMetadataSchema
>;
export function flowClipImportId(projectId: string, clipId: string) {
  return `flow:${projectId}:${clipId.toLowerCase()}`;
}

export function flowClipDetailIdentityFromUrl(rawUrl: string):
  | { projectId: string; clipId: string; detailUrl: string }
  | undefined {
  try {
    const url = new URL(rawUrl);
    if (
      url.protocol !== "https:" ||
      url.hostname !== "flow.google.com" ||
      url.username ||
      url.password
    )
      return;
    const match =
      /^\/(?:u\/[0-9]+\/)?project\/([A-Za-z0-9_-]+)\/edit\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\/?$/i.exec(
        url.pathname,
      );
    if (!match) return;
    return {
      projectId: match[1]!,
      clipId: match[2]!.toLowerCase(),
      detailUrl: `${url.origin}${url.pathname}`,
    };
  } catch {
    return;
  }
}

export function flowClipImportRouteMatches(
  record: Pick<FlowClipImportRecord, "projectId" | "clipId" | "detailUrl">,
) {
  try {
    const identity = flowClipDetailIdentityFromUrl(record.detailUrl);
    if (!identity || new URL(record.detailUrl).search || new URL(record.detailUrl).hash)
      return false;
    return Boolean(
      identity.projectId === record.projectId &&
        identity.clipId === record.clipId.toLowerCase(),
    );
  } catch {
    return false;
  }
}
