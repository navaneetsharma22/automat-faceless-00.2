import { z } from "zod";
import { INPUT_POLICY } from "../domain/batches/inputPolicy";
import {
  FLOW_IMAGE_ATTEMPT_STATES,
  flowImageAttemptActiveKey,
} from "../domain/jobs/attempt";
import {
  FlowImageResultBaselineSchema,
  FlowImageCountBaselineDeclarationSchema,
  FlowImageCountDecisionSchema,
  FlowImageCountModeRequestSchema,
  FlowImageReadinessModeSchema,
  FlowImageObservationOutcomeSchema,
  FlowImageObservationReceiptSchema,
  FlowImageObservationSessionSchema,
  FlowStructuralObservationEventSchema,
  FlowImageResultLinkSchema,
  flowProviderResultIdentityKey,
  flowResultBaselineMatchesAttempt,
} from "../domain/jobs/results";
import { flowImagePromptSnapshotId } from "../domain/batches/flowImagePromptSnapshot";
import { VidsVideoGenerationOperationSchema } from "../domain/jobs/vidsVideoGeneration";

const promptSourceSchema = z
  .string()
  .max(INPUT_POLICY.maxBatchCodeUnits)
  .refine(
    (source) =>
      new TextEncoder().encode(source).byteLength <=
      INPUT_POLICY.maxBatchUtf8Bytes,
    "Source exceeds the provisional total UTF-8 byte limit.",
  );

const workspaceIdSchema = z
  .string()
  .min(1)
  .max(128)
  .regex(/^[A-Za-z0-9][A-Za-z0-9._:-]*$/);

const promptMeasurementSchema = z
  .object({
    stringCodeUnits: z.number().int().nonnegative(),
    utf8Bytes: z.number().int().nonnegative(),
  })
  .strict();

const sourceSpanSchema = z
  .object({
    start: z.number().int().nonnegative(),
    end: z.number().int().positive(),
  })
  .strict()
  .refine((span) => span.end >= span.start);

export const PromptBatchInputSchema = z
  .object({
    workspaceId: workspaceIdSchema,
    kind: z.enum(["image", "video"]),
    sourceText: promptSourceSchema,
  })
  .strict();

export const PromptBatchKeySchema = z
  .object({ workspaceId: workspaceIdSchema, kind: z.enum(["image", "video"]) })
  .strict();

export const PromptItemRecordSchema = z
  .object({
    id: z.string().min(1).max(256),
    batchId: z.string().min(1).max(256),
    workspaceId: workspaceIdSchema,
    kind: z.enum(["image", "video"]),
    order: z
      .number()
      .int()
      .nonnegative()
      .max(INPUT_POLICY.maxPromptCount - 1),
    shotId: z
      .string()
      .regex(/^[1-9][0-9]*$/)
      .optional(),
    identitySource: z
      .enum(["outer_label", "envelope", "body_shot_id"])
      .optional(),
    rawJsonBody: z
      .string()
      .min(2)
      .max(INPUT_POLICY.maxPromptCodeUnits)
      .refine(
        (body) =>
          new TextEncoder().encode(body).byteLength <=
          INPUT_POLICY.maxPromptUtf8Bytes,
      ),
    sourceSpan: sourceSpanSchema,
    measurement: promptMeasurementSchema,
    contentHash: z.string().regex(/^[0-9a-f]{64}$/),
    createdAt: z.number().finite().nonnegative(),
  })
  .strict()
  .refine(
    (item) =>
      item.measurement.stringCodeUnits === item.rawJsonBody.length &&
      item.measurement.utf8Bytes ===
        new TextEncoder().encode(item.rawJsonBody).byteLength,
  );

export const PromptBatchRecordSchema = z
  .object({
    id: z.string().min(1).max(256),
    workflowId: workspaceIdSchema,
    workspaceId: workspaceIdSchema,
    kind: z.enum(["image", "video"]),
    status: z.literal("draft"),
    sourceText: promptSourceSchema,
    sourceMode: z.enum([
      "single_json_value",
      "numbered_json_blocks",
      "versioned_envelope",
    ]),
    orderedItemIds: z
      .array(z.string().min(1).max(256))
      .min(1)
      .max(INPUT_POLICY.maxPromptCount),
    total: promptMeasurementSchema,
    updatedAt: z.number().finite().nonnegative(),
  })
  .strict();

export const PromptBatchSnapshotSchema = z
  .object({
    batch: PromptBatchRecordSchema,
    items: z
      .array(PromptItemRecordSchema)
      .min(1)
      .max(INPUT_POLICY.maxPromptCount),
  })
  .strict();

export const FlowImagePromptSnapshotRecordSchema = z
  .object({
    snapshotId: z.string().min(1).max(512),
    workspaceId: workspaceIdSchema,
    batchId: z.string().min(1).max(256),
    itemId: z.string().min(1).max(256),
    promptHash: z.string().regex(/^[0-9a-f]{64}$/),
    rawJsonBody: z
      .string()
      .min(2)
      .max(INPUT_POLICY.maxPromptCodeUnits)
      .refine(
        (body) =>
          new TextEncoder().encode(body).byteLength <=
          INPUT_POLICY.maxPromptUtf8Bytes,
      ),
    promptCodeUnits: z.number().int().positive(),
    promptUtf8Bytes: z.number().int().positive(),
    createdAt: z.number().finite().nonnegative(),
  })
  .strict()
  .refine(
    (snapshot) =>
      snapshot.snapshotId ===
        flowImagePromptSnapshotId(snapshot.itemId, snapshot.promptHash) &&
      snapshot.promptCodeUnits === snapshot.rawJsonBody.length &&
      snapshot.promptUtf8Bytes ===
        new TextEncoder().encode(snapshot.rawJsonBody).byteLength,
  );

const flowImageAttemptEventSchema = z
  .object({
    stage: z.enum([
      "preparation",
      "verification",
      "preflight",
      "observer",
      "dispatch",
      "storage",
      "recovery",
    ]),
    at: z.number().finite().nonnegative(),
    method: z.enum([
      "none",
      "CDP Input.insertText",
      "CDP Input.dispatchMouseEvent",
    ]),
    code: z
      .string()
      .regex(/^[a-z0-9_]{1,64}$/)
      .optional(),
  })
  .strict();

export const FlowCountRecoveryRecordSchema = z
  .object({
    recoveryId: z.string().uuid(),
    oldAttemptId: z.string().uuid(),
    oldSessionId: z.string().uuid(),
    oldSourceHash: z.string().regex(/^[0-9a-f]{64}$/),
    oldOutcome: z.literal("unknown"),
    oldMonitoringStatus: z.enum([
      "active",
      "arming",
      "lost",
      "timed_out",
      "closed",
    ]),
    oldCountDecisionStatus: z.literal("interrupted"),
    producerInspection: z.literal("absent_interrupted"),
    newSourceHash: z.string().regex(/^[0-9a-f]{64}$/),
    newWorkspaceId: z.string().min(1).max(128),
    newItemId: z.string().min(1).max(256),
    newSnapshotId: z.string().min(1).max(512),
    countSessionId: z.string().uuid(),
    projectId: z.string().min(1).max(512),
    canonicalTarget: z.string().min(1).max(2048),
    tabId: z.number().int().nonnegative(),
    documentId: z.string().min(1).max(256),
    buildId: z.string().min(1).max(128),
    protocolVersion: z.number().int().positive(),
    countDeclarationProvenance: z.literal("user_attested_existing_image_count"),
    userConfirmed: z.literal(true),
    startingImageCount: z.number().int().nonnegative().max(100_000),
    baselineCandidateIds: z.array(z.string().regex(/^[0-9a-f]{64}$/)).max(500),
    qualifyingBaselineCandidateIds: z
      .array(z.string().regex(/^[0-9a-f]{64}$/))
      .max(500),
    baselineTileTokens: z.array(z.string().regex(/^tile-[0-9]{1,6}$/)).max(100),
    capturedAt: z.number().finite().nonnegative(),
  })
  .strict()
  .superRefine((record, context) => {
    if (
      record.oldAttemptId !== record.recoveryId ||
      record.oldSourceHash === record.newSourceHash
    )
      context.addIssue({
        code: "custom",
        message: "invalid_recovery_source_binding",
      });
    if (
      new Set(record.baselineCandidateIds).size !==
        record.baselineCandidateIds.length ||
      new Set(record.qualifyingBaselineCandidateIds).size !==
        record.qualifyingBaselineCandidateIds.length ||
      new Set(record.baselineTileTokens).size !==
        record.baselineTileTokens.length ||
      record.qualifyingBaselineCandidateIds.some(
        (id) => !record.baselineCandidateIds.includes(id),
      )
    )
      context.addIssue({
        code: "custom",
        message: "invalid_recovery_baseline",
      });
  });
export type ValidatedFlowCountRecoveryRecord = z.infer<
  typeof FlowCountRecoveryRecordSchema
>;

export const FlowImageAttemptRecordSchema = z
  .object({
    attemptId: z.string().min(1).max(128),
    activeKey: z.string().min(1).max(512).optional(),
    confirmationKey: z.string().min(1).max(128),
    workspaceId: workspaceIdSchema,
    batchId: z.string().min(1).max(256),
    itemId: z.string().min(1).max(256),
    shotId: z
      .string()
      .regex(/^[1-9][0-9]*$/)
      .optional(),
    promptHash: z.string().regex(/^[0-9a-f]{64}$/),
    sourceSnapshotId: z.string().min(1).max(512),
    promptCodeUnits: z
      .number()
      .int()
      .positive()
      .max(INPUT_POLICY.maxPromptCodeUnits),
    promptUtf8Bytes: z
      .number()
      .int()
      .positive()
      .max(INPUT_POLICY.maxPromptUtf8Bytes),
    provider: z.literal("Flow"),
    projectId: z.string().min(1).max(512),
    tabId: z.number().int().nonnegative(),
    frameId: z.string().min(1).max(256),
    loaderId: z.string().min(1).max(256),
    documentId: z.string().min(1).max(256).optional(),
    senderFrameId: z.number().int().nonnegative().optional(),
    buildId: z.string().min(1).max(128),
    protocolVersion: z.number().int().positive(),
    settingsConfirmation: z
      .object({
        confirmationId: z.string().min(1).max(128),
        confirmedAt: z.number().finite().nonnegative(),
        userAttested: z.literal(true),
        tabId: z.number().int().nonnegative(),
        projectId: z.string().min(1).max(512),
        canonicalTarget: z.string().min(1).max(2048).optional(),
        declaredVariantCount: z.number().int().positive().max(100).optional(),
      })
      .strict(),
    state: z.enum(FLOW_IMAGE_ATTEMPT_STATES),
    revision: z.number().int().nonnegative().optional(),
    baseline: z
      .union([
        z
          .object({
            regionLabel: z.string().min(1).max(80),
            mediaCount: z.number().int().nonnegative().max(100_000),
            capturedAt: z.number().finite().nonnegative(),
          })
          .strict(),
        z
          .object({
            kind: z.literal("flow_empty_workspace_ui"),
            workspaceTag: z.literal("flow-project-page"),
            markerPhrase: z.literal("Start creating or drop media"),
            markerCount: z.literal(1),
            visibleMediaCount: z.literal(0),
            visibleResultCardCount: z.literal(0),
            loadingMarkerCount: z.literal(0),
            capturedAt: z.number().finite().nonnegative(),
          })
          .strict(),
        z
          .object({
            kind: z.literal("flow_rendered_tile_candidates"),
            workspaceTag: z.literal("flow-project-page"),
            renderedTileCount: z.number().int().positive().max(100),
            candidateIds: z.array(z.string().regex(/^[0-9a-f]{64}$/)).max(500),
            qualifyingCandidateIds: z
              .array(z.string().regex(/^[0-9a-f]{64}$/))
              .max(500)
              .optional(),
            candidateMultiplicity: z
              .array(
                z
                  .object({
                    candidateId: z.string().regex(/^[0-9a-f]{64}$/),
                    renderedCopies: z.number().int().positive().max(1000),
                  })
                  .strict(),
              )
              .max(500),
            repeatedCandidateCount: z.number().int().nonnegative().max(10_000),
            unidentifiedImageCount: z.number().int().nonnegative().max(1000),
            unrelatedImageCount: z.number().int().nonnegative().max(10_000),
            virtualScrollContainerCount: z
              .number()
              .int()
              .nonnegative()
              .max(32)
              .optional(),
            virtualizationEvidence: z
              .array(
                z.enum([
                  "scroll_extent_exceeds_viewport",
                  "nonzero_scroll_offset",
                  "viewport_dimensions_unavailable",
                  "scroll_observed_during_capture",
                  "tile_identity_recycled",
                ]),
              )
              .max(8)
              .optional(),
            virtualized: z.boolean(),
            loadingSignalCount: z.number().int().nonnegative().max(10_000),
            captureGaps: z.array(z.string().min(1).max(64)).max(16),
            capturedAt: z.number().finite().nonnegative(),
          })
          .strict()
          .superRefine((baseline, context) => {
            const ids = new Set(baseline.candidateIds);
            if (
              ids.size !== baseline.candidateIds.length ||
              baseline.candidateMultiplicity.length !== ids.size ||
              baseline.candidateMultiplicity.some(
                (candidate) => !ids.has(candidate.candidateId),
              )
            ) {
              context.addIssue({
                code: "custom",
                message: "rendered_candidate_baseline_must_be_deduplicated",
              });
            }
            if (
              baseline.qualifyingCandidateIds?.some(
                (candidateId) => !ids.has(candidateId),
              )
            )
              context.addIssue({
                code: "custom",
                message: "qualifying_candidates_must_be_owned_candidates",
              });
          }),
      ])
      .optional(),
    resultBaseline: FlowImageResultBaselineSchema.optional(),
    observationSession: FlowImageObservationSessionSchema.optional(),
    resultLinks: z.array(FlowImageResultLinkSchema).max(100).optional(),
    observationReceipts: z
      .array(FlowImageObservationReceiptSchema)
      .max(128)
      .optional(),
    structuralObservations: z
      .array(FlowStructuralObservationEventSchema)
      .max(64)
      .optional(),
    resultOutcome: FlowImageObservationOutcomeSchema.optional(),
    countSessionId: z.string().uuid().optional(),
    countBaseline: FlowImageCountBaselineDeclarationSchema.optional(),
    countDecision: FlowImageCountDecisionSchema.optional(),
    events: z.array(flowImageAttemptEventSchema).min(1).max(24),
    createdAt: z.number().finite().nonnegative(),
    updatedAt: z.number().finite().nonnegative(),
  })
  .strict()
  .refine(
    (attempt) =>
      attempt.sourceSnapshotId ===
      flowImagePromptSnapshotId(attempt.itemId, attempt.promptHash),
  )
  .refine(
    (attempt) =>
      attempt.resultBaseline === undefined ||
      flowResultBaselineMatchesAttempt(attempt.resultBaseline, attempt),
    { message: "result_baseline_attempt_binding_mismatch" },
  )
  .refine(
    (attempt) =>
      attempt.observationSession === undefined ||
      (attempt.documentId === attempt.observationSession.documentId &&
        attempt.senderFrameId === attempt.observationSession.senderFrameId),
    { message: "observation_session_document_binding_mismatch" },
  )
  .refine((attempt) => {
    if (!attempt.resultBaseline) return true;
    const declaration = attempt.resultBaseline.variantDeclaration;
    const attemptCount = attempt.settingsConfirmation.declaredVariantCount;
    return declaration.status === "absent"
      ? attemptCount === undefined
      : declaration.count === attemptCount;
  }, "attempt_variant_declaration_mismatch")
  .refine((attempt) => {
    if (!attempt.countBaseline) return attempt.countDecision === undefined;
    const baseline = attempt.countBaseline;
    const decision = attempt.countDecision;
    const declaredVariantCount =
      attempt.settingsConfirmation.declaredVariantCount;
    return Boolean(
      decision &&
      declaredVariantCount !== undefined &&
      attempt.countSessionId === baseline.countSessionId &&
      baseline.projectId === attempt.projectId &&
      baseline.tabId === attempt.tabId &&
      baseline.documentId === attempt.documentId &&
      baseline.buildId === attempt.buildId &&
      baseline.protocolVersion === attempt.protocolVersion &&
      baseline.canonicalTarget ===
        attempt.settingsConfirmation.canonicalTarget &&
      decision.countSessionId === baseline.countSessionId &&
      decision.mode === baseline.mode &&
      decision.startingImageCount === baseline.startingImageCount &&
      decision.declaredVariantCount === declaredVariantCount &&
      decision.expectedCumulativeAdditions ===
        baseline.priorDeclaredAdditions + declaredVariantCount &&
      decision.priorMatchedAttemptIds.length ===
        baseline.priorMatchedAttemptIds.length &&
      decision.priorMatchedAttemptIds.every(
        (attemptId, index) =>
          attemptId === baseline.priorMatchedAttemptIds[index],
      ),
    );
  }, "attempt_count_decision_binding_mismatch")
  .refine((attempt) => {
    const identities = (attempt.resultLinks ?? []).map((link) =>
      flowProviderResultIdentityKey(link.identity),
    );
    return new Set(identities).size === identities.length;
  }, "duplicate_result_link_identity")
  .refine((attempt) => {
    const receipts = attempt.observationReceipts ?? [];
    return (
      new Set(receipts.map((receipt) => receipt.observationId)).size ===
        receipts.length &&
      new Set(receipts.map((receipt) => receipt.sequence)).size ===
        receipts.length
    );
  }, "duplicate_observation_receipt")
  .refine(
    (attempt) =>
      attempt.activeKey === undefined ||
      attempt.activeKey ===
        flowImageAttemptActiveKey(attempt.itemId, attempt.promptHash) ||
      attempt.activeKey === flowImageAttemptActiveKey(attempt.itemId),
  )
  .refine((attempt) =>
    attempt.state === "failed-before-dispatch"
      ? attempt.activeKey === undefined
      : attempt.activeKey ===
          flowImageAttemptActiveKey(attempt.itemId, attempt.promptHash) ||
        attempt.activeKey === flowImageAttemptActiveKey(attempt.itemId),
  );

export const FlowSettingsConfirmationSchema = z
  .object({
    confirmationId: z.string().min(1).max(128),
    confirmedAt: z.number().finite().nonnegative(),
    tabId: z.number().int().nonnegative(),
    projectId: z.string().min(1).max(512),
    canonicalTarget: z.string().min(1).max(2048),
    declaredVariantCount: z.number().int().positive().max(100),
  })
  .strict();
export type FlowSettingsConfirmation = z.infer<
  typeof FlowSettingsConfirmationSchema
>;

export const VideoDestinationSchema = z.enum(["Flow", "Vids"]);
export type VideoDestination = z.infer<typeof VideoDestinationSchema>;

export const VideoSettingsConfirmationSchema = z
  .object({
    confirmationId: z.string().min(1).max(128),
    confirmedAt: z.number().finite().nonnegative(),
    destination: VideoDestinationSchema,
    declaredDurationSeconds: z.number().int().positive().max(3600),
    tabId: z.number().int().nonnegative(),
    canonicalTarget: z.string().min(1).max(2048),
    projectId: z.string().min(1).max(512).optional(),
    documentId: z.string().min(1).max(256).optional(),
  })
  .strict();
export type VideoSettingsConfirmation = z.infer<
  typeof VideoSettingsConfirmationSchema
>;

export const PreparedVideoBatchItemSchema = z
  .object({
    itemId: z.string().min(1).max(256),
    order: z.number().int().nonnegative(),
    shotId: z.string().regex(/^[1-9][0-9]*$/).optional(),
    canonicalShotId: z.string().regex(/^[1-9][0-9]*$/),
    rawJsonBody: z.string().min(2),
    contentHash: z.string().regex(/^[0-9a-f]{64}$/),
    sourceSpan: sourceSpanSchema,
    reference: z
      .object({
        referenceId: z.string().uuid(),
        assignmentVersion: z.number().int().positive(),
        sha256: z.string().regex(/^[0-9a-f]{64}$/),
        mimeType: z.string().min(1),
        byteSize: z.number().int().positive(),
        width: z.number().int().positive(),
        height: z.number().int().positive(),
        capturedAt: z.number().finite().nonnegative(),
      })
      .strict(),
  })
  .strict();
export type PreparedVideoBatchItem = z.infer<
  typeof PreparedVideoBatchItemSchema
>;

export const PreparedVideoBatchRecordSchema = z
  .object({
    id: z.string().min(1).max(512),
    requestId: z.string().uuid(),
    workspaceId: workspaceIdSchema,
    preparedAt: z.number().finite().nonnegative(),
    videoBatchId: z.string().min(1).max(256),
    videoSourceHash: z.string().regex(/^[0-9a-f]{64}$/),
    videoSourceText: promptSourceSchema,
    imageSourceBatchId: z.string().min(1).max(256),
    imageSourceBatchHash: z.string().regex(/^[0-9a-f]{64}$/),
    destination: VideoDestinationSchema,
    target: z
      .object({
        provider: VideoDestinationSchema,
        tabId: z.number().int().nonnegative(),
        canonicalTarget: z.string().min(1).max(2048),
        projectId: z.string().min(1).max(512).optional(),
        documentId: z.string().min(1).max(256).optional(),
        verification: z.literal("verified"),
        verifiedAt: z.number().finite().nonnegative(),
      })
      .strict(),
    manualSettingsDeclaration: VideoSettingsConfirmationSchema,
    status: z.literal("prepared"),
    itemCount: z.number().int().positive(),
    items: z.array(PreparedVideoBatchItemSchema).nonempty(),
    createdAt: z.number().finite().nonnegative(),
    updatedAt: z.number().finite().nonnegative(),
  })
  .strict();
export type PreparedVideoBatchRecord = z.infer<
  typeof PreparedVideoBatchRecordSchema
>;


export const ReferenceCandidateSchema = z
  .object({
    sourceUrl: z.string().min(1).max(4096),
    naturalWidth: z.number().int().nonnegative(),
    naturalHeight: z.number().int().nonnegative(),
    displayWidth: z.number().nonnegative(),
    displayHeight: z.number().nonnegative(),
    providerAssetId: z.string().min(1).max(256).optional(),
    cardTag: z.string().min(1).max(64),
    selectedAt: z.number().finite().nonnegative(),
    selectionVersion: z.string().uuid().optional(),
    workspaceId: workspaceIdSchema.optional(),
    batchId: z.string().min(1).max(256).optional(),
    shotId: z
      .string()
      .regex(/^[1-9][0-9]*$/)
      .optional(),
    batchSourceHash: z
      .string()
      .regex(/^[0-9a-f]{64}$/)
      .optional(),
    promptHash: z
      .string()
      .regex(/^[0-9a-f]{64}$/)
      .optional(),
    flowProjectId: z.string().min(1).max(512).optional(),
    tabId: z.number().int().nonnegative().optional(),
    canonicalTarget: z.string().min(1).max(2048).optional(),
    documentId: z.string().min(1).max(256).optional(),
    selectionSessionId: z.string().min(1).max(128).optional(),
    acceptedAt: z.number().finite().nonnegative().optional(),
    observedSourceSha256: z
      .string()
      .regex(/^[0-9a-f]{64}$/)
      .optional(),
  })
  .strict();
export type ReferenceCandidate = z.infer<typeof ReferenceCandidateSchema>;

export const FlowReferencePickerCandidateSchema =
  ReferenceCandidateSchema.extend({
    candidateId: z.string().uuid(),
  });
export type FlowReferencePickerCandidate = z.infer<
  typeof FlowReferencePickerCandidateSchema
>;

export const ActiveReferenceSelectionSessionSchema = z
  .object({
    sessionId: z.string().min(1).max(128),
    workspaceId: workspaceIdSchema,
    batchId: z.string().min(1).max(256),
    sourceHash: z.string().regex(/^[0-9a-f]{64}$/),
    shotId: z.string().regex(/^[1-9][0-9]*$/),
    tabId: z.number().int().nonnegative(),
    projectId: z.string().min(1).max(512),
    canonicalTarget: z.string().min(1).max(2048),
    documentId: z.string().min(1).max(256),
    frameId: z.number().int().nonnegative(),
    startedAt: z.number().finite().nonnegative(),
    status: z.enum(["active", "cancelled", "completed"]),
  })
  .strict();
export type ActiveReferenceSelectionSession = z.infer<
  typeof ActiveReferenceSelectionSessionSchema
>;

export const FLOW_REFERENCE_CANDIDATE_SELECTED_MESSAGE =
  "AUTOMAT_FLOW_REFERENCE_CANDIDATE_SELECTED" as const;

export const FlowReferenceCandidateSelectedMessageSchema = z
  .object({
    type: z.literal(FLOW_REFERENCE_CANDIDATE_SELECTED_MESSAGE),
    protocolVersion: z.number().int().positive(),
    buildId: z.string().min(1).max(128),
    sessionId: z.string().min(1).max(128),
    workspaceId: workspaceIdSchema,
    batchId: z.string().min(1).max(256),
    shotId: z.string().regex(/^[1-9][0-9]*$/),
    candidate: ReferenceCandidateSchema,
  })
  .strict();
export type FlowReferenceCandidateSelectedMessage = z.infer<
  typeof FlowReferenceCandidateSelectedMessageSchema
>;

export const FLOW_REFERENCE_EVENT_MESSAGE =
  "AUTOMAT_FLOW_REFERENCE_EVENT" as const;

export const FlowReferenceEventMessageSchema = z.discriminatedUnion("event", [
  z
    .object({
      type: z.literal(FLOW_REFERENCE_EVENT_MESSAGE),
      event: z.literal("candidate_selected"),
      sessionId: z.string().min(1).max(128),
      workspaceId: workspaceIdSchema,
      batchId: z.string().min(1).max(256),
      batchSourceHash: z.string().regex(/^[0-9a-f]{64}$/),
      shotId: z.string().regex(/^[1-9][0-9]*$/),
      candidate: ReferenceCandidateSchema,
      retained: z.literal(false),
      message: z.literal(
        "Candidate selected — not saved. Save reference to capture and keep image bytes.",
      ),
    })
    .strict(),
  z
    .object({
      type: z.literal(FLOW_REFERENCE_EVENT_MESSAGE),
      event: z.literal("session_cancelled"),
      sessionId: z.string().min(1).max(128),
      workspaceId: workspaceIdSchema,
      shotId: z.string().regex(/^[1-9][0-9]*$/),
      reason: z.string().min(1).max(128),
    })
    .strict(),
  z
    .object({
      type: z.literal(FLOW_REFERENCE_EVENT_MESSAGE),
      event: z.literal("session_started"),
      sessionId: z.string().min(1).max(128),
      workspaceId: workspaceIdSchema,
      batchId: z.string().min(1).max(256),
      batchSourceHash: z.string().regex(/^[0-9a-f]{64}$/),
      shotId: z.string().regex(/^[1-9][0-9]*$/),
    })
    .strict(),
  z
    .object({
      type: z.literal(FLOW_REFERENCE_EVENT_MESSAGE),
      event: z.literal("candidate_cleared"),
      workspaceId: workspaceIdSchema,
      batchId: z.string().min(1).max(256).optional(),
      batchSourceHash: z.string().regex(/^[0-9a-f]{64}$/).optional(),
      shotId: z.string().regex(/^[1-9][0-9]*$/),
    })
    .strict(),
  z
    .object({
      type: z.literal(FLOW_REFERENCE_EVENT_MESSAGE),
      event: z.literal("capture_progress"),
      captureOperationId: z.string().uuid(),
      workspaceId: workspaceIdSchema,
      batchId: z.string().min(1).max(256),
      batchSourceHash: z.string().regex(/^[0-9a-f]{64}$/),
      shotId: z.string().regex(/^[1-9][0-9]*$/),
      stage: z.enum(["capturing", "saving"]),
    })
    .strict(),
  z
    .object({
      type: z.literal(FLOW_REFERENCE_EVENT_MESSAGE),
      event: z.literal("reference_saved"),
      captureOperationId: z.string().uuid(),
      workspaceId: workspaceIdSchema,
      batchId: z.string().min(1).max(256),
      batchSourceHash: z.string().regex(/^[0-9a-f]{64}$/),
      shotId: z.string().regex(/^[1-9][0-9]*$/),
      referenceId: z.string().uuid(),
    })
    .strict(),
]);
export type FlowReferenceEventMessage = z.infer<
  typeof FlowReferenceEventMessageSchema
>;

const requestBase = z
  .object({
    protocolVersion: z.number().int().positive(),
    buildId: z.string().min(1).max(128),
    requestId: z.string().min(1).max(128),
  })
  .strict();

export const AppRequestSchema = z.discriminatedUnion("type", [
  requestBase.extend({
    type: z.literal("foundation.ping"),
    payload: z.object({}).strict(),
  }),
  requestBase.extend({
    type: z.literal("promptDraft.put"),
    payload: z
      .object({
        id: z.string().min(1).max(128),
        kind: z.enum(["image", "video"]),
        rawText: z.string(),
      })
      .strict(),
  }),
  requestBase.extend({
    type: z.literal("promptDraft.get"),
    payload: z.object({ id: z.string().min(1).max(128) }).strict(),
  }),
  requestBase.extend({
    type: z.literal("promptBatch.put"),
    payload: PromptBatchInputSchema,
  }),
  requestBase.extend({
    type: z.literal("promptBatch.get"),
    payload: PromptBatchKeySchema,
  }),
  requestBase.extend({
    type: z.literal("imageQueue.createTimed"),
    payload: z
      .object({
        workspaceId: workspaceIdSchema,
        queueId: z.string().uuid(),
        settingsConfirmation: FlowSettingsConfirmationSchema,
      })
      .strict(),
  }),
  requestBase.extend({
    type: z.literal("imageQueue.get"),
    payload: z.object({ queueId: z.string().uuid() }).strict(),
  }),
  requestBase.extend({
    type: z.literal("imageQueue.start"),
    payload: z.object({ queueId: z.string().uuid() }).strict(),
  }),
  ...(["pause", "resume", "stop", "recheckAndResume"] as const).map((command) =>
    requestBase.extend({
      type: z.literal(`imageQueue.${command}`),
      payload: z
        .object({
          queueId: z.string().uuid(),
          expectedRevision: z.number().int().nonnegative(),
        })
        .strict(),
    }),
  ),
  requestBase.extend({
    type: z.literal("imageQueue.list"),
    payload: z.object({ workspaceId: workspaceIdSchema }).strict(),
  }),
  requestBase.extend({
    type: z.literal("imageQueue.inspectReadback"),
    payload: z
      .object({
        queueId: z.string().uuid().or(z.string().min(1).max(128)),
        order: z.number().int().nonnegative().optional(),
      })
      .strict(),
  }),
  requestBase.extend({
    type: z.literal("imageQueue.retryBlocked"),
    payload: z
      .object({
        queueId: z.string().uuid().or(z.string().min(1).max(128)),
        expectedRevision: z.number().int().nonnegative(),
        order: z.number().int().nonnegative(),
      })
      .strict(),
  }),
  requestBase.extend({
    type: z.literal("connections.recordSelection"),
    payload: z
      .object({
        provider: z.enum(["Flow", "Vids"]),
        tabId: z.number().int().nonnegative(),
        canonicalTarget: z.string().min(1).max(2048),
      })
      .strict(),
  }),
  requestBase.extend({
    type: z.literal("connections.getSelection"),
    payload: z.object({ provider: z.enum(["Flow", "Vids"]) }).strict(),
  }),
  requestBase.extend({
    type: z.literal("connections.revalidate"),
    payload: z
      .object({
        provider: z.enum(["Flow", "Vids"]),
        enableReconnect: z.boolean().optional(),
      })
      .strict(),
  }),
  requestBase.extend({
    type: z.literal("connections.setReconnectIntent"),
    payload: z
      .object({ provider: z.enum(["Flow", "Vids"]), enabled: z.boolean() })
      .strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.prompt.fill"),
    payload: z
      .object({
        workspaceId: workspaceIdSchema,
        promptHash: z.string().regex(/^[0-9a-f]{64}$/),
      })
      .strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.image.generateOnce"),
    payload: z
      .object({
        workspaceId: workspaceIdSchema,
        promptHash: z.string().regex(/^[0-9a-f]{64}$/),
        settingsConfirmation: FlowSettingsConfirmationSchema,
        countMode: FlowImageCountModeRequestSchema,
      })
      .strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.image.checkReadiness"),
    payload: z.object({ countMode: FlowImageReadinessModeSchema }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.image.getCountDecision"),
    payload: z.object({ attemptId: z.string().min(1).max(128) }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.image.inspectCountBlockers"),
    payload: z.object({}).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.image.rebaselineForNewPrompt"),
    payload: z
      .object({
        oldAttemptId: z.string().uuid(),
        workspaceId: workspaceIdSchema,
        promptHash: z.string().regex(/^[0-9a-f]{64}$/),
        countSessionId: z.string().uuid(),
        startingImageCount: z.number().int().nonnegative().max(100_000),
        userConfirmed: z.literal(true),
      })
      .strict(),
  }),
  requestBase.extend({
    type: z.literal("preferences.getTheme"),
    payload: z.object({}).strict(),
  }),
  requestBase.extend({
    type: z.literal("preferences.setTheme"),
    payload: z.object({ theme: z.enum(["light", "dark"]) }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.reference.startSelection"),
    payload: z
      .object({
        workspaceId: workspaceIdSchema,
        batchId: z.string().min(1).max(256),
        shotId: z.string().regex(/^[1-9][0-9]*$/),
      })
      .strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.reference.cancelSelection"),
    payload: z
      .object({
        sessionId: z.string().min(1).max(128),
      })
      .strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.reference.getState"),
    payload: z
      .object({
        workspaceId: workspaceIdSchema,
      })
      .strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.reference.clearCandidate"),
    payload: z
      .object({
        workspaceId: workspaceIdSchema,
        shotId: z.string().regex(/^[1-9][0-9]*$/),
      })
      .strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.reference.listCandidates"),
    payload: z.object({ sessionId: z.string().min(1).max(128) }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.reference.chooseCandidate"),
    payload: z
      .object({
        sessionId: z.string().min(1).max(128),
        candidateId: z.string().uuid(),
      })
      .strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.reference.getPreview"),
    payload: z
      .object({
        sessionId: z.string().min(1).max(128),
        candidateId: z.string().uuid(),
        previewId: z.string().uuid(),
      })
      .strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.reference.cancelPreview"),
    payload: z
      .object({
        sessionId: z.string().min(1).max(128),
        previewId: z.string().uuid(),
      })
      .strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.reference.capture"),
    payload: z
      .object({
        workspaceId: workspaceIdSchema,
        batchId: z.string().min(1).max(256),
        shotId: z.string().regex(/^[1-9][0-9]*$/),
        selectionVersion: z.string().uuid(),
        expectedAssignmentVersion: z.number().int().nonnegative(),
        captureOperationId: z.string().uuid(),
      })
      .strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.reference.cancelCapture"),
    payload: z.object({ captureOperationId: z.string().uuid() }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.reference.getCaptureStatus"),
    payload: z.object({ captureOperationId: z.string().uuid() }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.reference.getSavedReference"),
    payload: z.object({ referenceId: z.string().uuid() }).strict(),
  }),
  requestBase.extend({
    type: z.literal("videoBatch.prepare"),
    payload: z
      .object({
        workspaceId: workspaceIdSchema,
        requestId: z.string().uuid(),
        destination: VideoDestinationSchema,
        imageSourceBatchId: z.string().min(1).max(256),
        manualSettingsDeclaration: VideoSettingsConfirmationSchema,
        expectedVideoSourceHash: z.string().regex(/^[0-9a-f]{64}$/).optional(),
        expectedImageSourceHash: z.string().regex(/^[0-9a-f]{64}$/).optional(),
        expectedReferenceVersions: z
          .array(
            z
              .object({
                canonicalShotId: z.string().regex(/^[1-9][0-9]*$/),
                referenceId: z.string().uuid(),
                assignmentVersion: z.number().int().positive(),
              })
              .strict(),
          )
          .optional(),
      })
      .strict(),
  }),
  requestBase.extend({
    type: z.literal("videoBatch.getPrepared"),
    payload: z.object({ workspaceId: workspaceIdSchema }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.downloadDiagnostic.arm"),
    payload: z
      .object({ identityCaptureEnabled: z.boolean().optional() })
      .strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.downloadDiagnostic.stop"),
    payload: z.object({}).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.downloadDiagnostic.get"),
    payload: z.object({}).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.clipImport.importCurrent"),
    payload: z.object({}).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.clipImport.list"),
    payload: z.object({}).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.projectVideos.import.start"),
    payload: z.object({ singleCardCheck: z.boolean().optional() }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.projectVideos.import.get"),
    payload: z.object({}).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.projectVideos.import.cancel"),
    payload: z.object({}).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.clipDownloadProof.inspect"),
    payload: z.object({ recordId: z.string().min(1).max(256) }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.clipDownload.start"),
    payload: z.object({ recordId: z.string().min(1).max(256), allowNewAttempt: z.boolean().optional() }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.clipDownloadProof.arm"),
    payload: z.object({ recordId: z.string().min(1).max(256) }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.video.attachReference"),
    payload: z.object({ preparedBatchId: z.string().min(1).max(256), itemId: z.string().min(1).max(256) }).strict(),
  }),
  requestBase.extend({
    type: z.literal("vids.video.attachReference"),
    payload: z.object({ preparedBatchId: z.string().min(1).max(512), itemId: z.string().min(1).max(256) }).strict(),
  }),
  requestBase.extend({
    type: z.literal("vids.video.getAttachmentStatus"),
    payload: z.object({ preparedBatchId: z.string().min(1).max(512), itemId: z.string().min(1).max(256) }).strict(),
  }),
  requestBase.extend({ type: z.literal("vids.video.getReferencePreview"), payload: z.object({ preparedBatchId: z.string().min(1).max(512), itemId: z.string().min(1).max(256) }).strict() }),
  requestBase.extend({
    type: z.literal("vids.video.generateOnce"),
    payload: z.object({ preparedBatchId: z.string().min(1).max(512), itemId: z.string().min(1).max(256) }).strict(),
  }),
  requestBase.extend({
    type: z.literal("vids.video.getGenerationStatus"),
    payload: z.object({ preparedBatchId: z.string().min(1).max(512), itemId: z.string().min(1).max(256) }).strict(),
  }),
  requestBase.extend({
    type: z.literal("vids.video.recoverPreActivationFailure"),
    payload: z.object({ expected: VidsVideoGenerationOperationSchema }).strict(),
  }),
  requestBase.extend({ type: z.literal("vids.videoQueue.get"), payload: z.object({ preparedBatchId: z.string().min(1).max(512) }).strict() }),
  requestBase.extend({ type: z.literal("vids.videoQueue.start"), payload: z.object({ preparedBatchId: z.string().min(1).max(512) }).strict() }),
  requestBase.extend({ type: z.literal("vids.videoQueue.pause"), payload: z.object({ preparedBatchId: z.string().min(1).max(512), expectedRevision: z.number().int().nonnegative() }).strict() }),
  requestBase.extend({ type: z.literal("vids.videoQueue.resume"), payload: z.object({ preparedBatchId: z.string().min(1).max(512), expectedRevision: z.number().int().nonnegative(), confirmSameAccount: z.boolean().optional() }).strict() }),
  requestBase.extend({ type: z.literal("vids.videoQueue.stop"), payload: z.object({ preparedBatchId: z.string().min(1).max(512), expectedRevision: z.number().int().nonnegative() }).strict() }),
  requestBase.extend({ type: z.literal("vids.videoQueue.inspectTransition"), payload: z.object({ preparedBatchId: z.string().min(1).max(512), itemId: z.string().min(1).max(256) }).strict() }),
  requestBase.extend({
    type: z.literal("flow.video.inspectReferenceBytes"),
    payload: z.object({ preparedBatchId: z.string().min(1).max(256), itemId: z.string().min(1).max(256) }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.video.verifyAttachedReference"),
    payload: z.object({ preparedBatchId: z.string().min(1).max(256), itemId: z.string().min(1).max(256) }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.video.generateOnce"),
    payload: z.object({ preparedBatchId: z.string().min(1).max(256), itemId: z.string().min(1).max(256) }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.video.getAttachmentStatus"),
    payload: z.object({ preparedBatchId: z.string().min(1).max(256), itemId: z.string().min(1).max(256) }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.videoQueue.get"),
    payload: z.object({ preparedBatchId: z.string().min(1).max(512) }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.videoQueue.start"),
    payload: z.object({ preparedBatchId: z.string().min(1).max(512) }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.videoQueue.pause"),
    payload: z.object({ preparedBatchId: z.string().min(1).max(512), expectedRevision: z.number().int().nonnegative() }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.videoQueue.resume"),
    payload: z.object({ preparedBatchId: z.string().min(1).max(512), expectedRevision: z.number().int().nonnegative() }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.videoQueue.stop"),
    payload: z.object({ preparedBatchId: z.string().min(1).max(512), expectedRevision: z.number().int().nonnegative() }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.videoQueue.recheckAndResume"),
    payload: z.object({ preparedBatchId: z.string().min(1).max(512), expectedRevision: z.number().int().nonnegative() }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.videoQueue.reconcilePreAddFailure"),
    payload: z.object({ preparedBatchId: z.literal("prepared:default:1235934d-8b2d-43b9-990c-8e103413d179"), expectedRevision: z.number().int().nonnegative() }).strict(),
  }),
  requestBase.extend({
    type: z.literal("flow.video.reconcilePreClickFailure"),
    payload: z.object({
      preparedBatchId: z.literal("prepared:default:1235934d-8b2d-43b9-990c-8e103413d179"),
      itemId: z.literal("import:default:video:item:0"),
      expectedStatus: z.literal("uncertain"),
      expectedReason: z.literal("composer_unsupported"),
      expectedReferenceId: z.literal("014ebcff-06e3-4ac2-b980-568f0755febf"),
      expectedUpdatedAt: z.number().finite().nonnegative(),
    }).strict(),
  }),
]);

export const FailureCategorySchema = z.enum([
  "invalid_request",
  "unauthorized_sender",
  "protocol_mismatch",
  "build_mismatch",
  "duplicate_request",
  "not_found",
  "storage_failure",
  "missing_receiver",
  "context_invalidated",
  "worker_error",
  "malformed_response",
  "timeout",
]);

const responseBase = z
  .object({
    protocolVersion: z.number().int(),
    buildId: z.string().max(128),
    requestId: z.string().min(1).max(128),
  })
  .strict();

export const AppResponseSchema = z.discriminatedUnion("ok", [
  responseBase.extend({ ok: z.literal(true), data: z.unknown() }),
  responseBase.extend({
    ok: z.literal(false),
    error: z
      .object({
        category: FailureCategorySchema,
        code: z.string().min(1).max(64),
        message: z.string().min(1).max(240),
        stage: z.string().min(1).max(64).optional(),
      })
      .strict(),
  }),
]);

export type AppRequest = z.infer<typeof AppRequestSchema>;
export type AppResponse = z.infer<typeof AppResponseSchema>;
export type FailureCategory = z.infer<typeof FailureCategorySchema>;
