import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  FoundationClientError,
  type FoundationClient,
} from "../../../shared/messageClient";
import type { FlowSettingsConfirmation } from "../../../shared/schemas";
import {
  ImageSubmissionQueueRecordSchema,
  TIMED_IMAGE_SUBMISSION_INTERVAL_MS,
  type FlowEditorReadbackInspectionResult,
  type ImageQueueItem,
  type ImageSubmissionQueueRecord,
} from "../../../domain/jobs/queue";
import { Button } from "../../components/Button";
import styles from "./Progress.module.css";

const QUEUE_READBACK_INTERVAL_MS = 5_000;

export function ImageQueueProgress({
  workspaceId,
  persistenceClient,
  sourceReady,
  savedSource,
  savedShotIds,
  settingsConfirmation,
  settingsConfirmationPending,
  settingsConfirmationError,
  settingsConfirmationControls,
  onCurrentQueueChange,
}: {
  workspaceId: string;
  persistenceClient: FoundationClient;
  sourceReady: boolean;
  savedSource?: string;
  savedShotIds: readonly string[];
  settingsConfirmation?: FlowSettingsConfirmation;
  settingsConfirmationPending: boolean;
  settingsConfirmationError?: string;
  settingsConfirmationControls: ReactNode;
  onCurrentQueueChange?: (
    queue: ImageSubmissionQueueRecord | undefined,
  ) => void;
}) {
  const [queues, setQueues] = useState<ImageSubmissionQueueRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [startingQueueId, setStartingQueueId] = useState<string>();
  const [commanding, setCommanding] = useState<{
    queueId: string;
    command: "pause" | "resume" | "stop";
  }>();
  const [error, setError] = useState<string | undefined>();

  useEffect(() => {
    let active = true;
    const refresh = () =>
      persistenceClient
        .request("imageQueue.list", { workspaceId })
        .then((value) => {
          if (!Array.isArray(value))
            throw new Error("The queue list was invalid.");
          const records = value.map((entry) => {
            const parsed = ImageSubmissionQueueRecordSchema.safeParse(entry);
            if (!parsed.success)
              throw new Error("A saved queue failed validation.");
            return parsed.data;
          });
          if (active) {
            setQueues(records);
            setError(undefined);
          }
        })
        .catch((cause: unknown) => {
          if (active)
            setError(
              cause instanceof Error
                ? cause.message
                : "Saved queues could not be read.",
            );
        })
        .finally(() => {
          if (active) setLoading(false);
        });
    void refresh();
    const refreshTimer = window.setInterval(
      refresh,
      QUEUE_READBACK_INTERVAL_MS,
    );
    return () => {
      active = false;
      window.clearInterval(refreshTimer);
    };
  }, [persistenceClient, workspaceId]);

  const startQueue = async (queueId: string) => {
    if (startingQueueId || commanding) return;
    setStartingQueueId(queueId);
    setError(undefined);
    try {
      const record = await persistenceClient.request("imageQueue.start", {
        queueId,
      });
      const parsed = ImageSubmissionQueueRecordSchema.safeParse(record);
      if (!parsed.success)
        throw new Error("The queue start readback was invalid.");
      setQueues((current) =>
        current.map((queue) =>
          queue.queueId === queueId ? parsed.data : queue,
        ),
      );
    } catch (cause) {
      setError(
        cause instanceof Error
          ? cause.message
          : "The timed queue could not start.",
      );
    } finally {
      setStartingQueueId(undefined);
    }
  };

  const commandQueue = async (
    queue: ImageSubmissionQueueRecord,
    command: "pause" | "resume" | "stop",
  ) => {
    if (commanding || startingQueueId) return;
    setCommanding({ queueId: queue.queueId, command });
    setError(undefined);
    try {
      const record = await persistenceClient.request(`imageQueue.${command}`, {
        queueId: queue.queueId,
        expectedRevision: queue.revision,
      });
      const parsed = ImageSubmissionQueueRecordSchema.safeParse(record);
      if (!parsed.success)
        throw new Error("Queue lifecycle readback was invalid.");
      setQueues((current) =>
        current.map((entry) =>
          entry.queueId === queue.queueId ? parsed.data : entry,
        ),
      );
    } catch (cause) {
      setError(
        cause instanceof Error ? cause.message : `Queue ${command} failed.`,
      );
    } finally {
      setCommanding(undefined);
    }
  };

  const createQueue = async () => {
    if (
      disabledReason ||
      !sourceReady ||
      !savedSource ||
      !settingsConfirmation ||
      creating
    )
      return;
    setCreating(true);
    setError(undefined);
    try {
      const record = await persistenceClient.request("imageQueue.createTimed", {
        workspaceId,
        queueId: crypto.randomUUID(),
        settingsConfirmation,
      });
      const parsed = ImageSubmissionQueueRecordSchema.safeParse(record);
      if (!parsed.success)
        throw new Error("The saved queue failed readback validation.");
      const savedQueue = parsed.data;
      const readbackMatches =
        savedQueue.workspaceId === workspaceId &&
        savedQueue.sourceText === savedSource &&
        !queues.some((queue) => queue.queueId === savedQueue.queueId) &&
        savedQueue.state === "ready" &&
        savedQueue.nextEligibleDispatchAt === null &&
        savedQueue.lastDispatchReceiptStoredAt === null &&
        savedQueue.items.every(
          (item) =>
            item.itemState === "pending" &&
            item.providerOutcome === "not_started" &&
            !item.dispatchReceipt &&
            !item.dispatchIntent,
        ) &&
        savedQueue.items
          .map((item) => item.shotId ?? `Prompt ${item.order + 1}`)
          .join("\u0000") === savedShotIds.join("\u0000") &&
        savedQueue.manualSettingsDeclaration.confirmationId ===
          settingsConfirmation.confirmationId &&
        savedQueue.selectedProject.tabId === settingsConfirmation.tabId &&
        savedQueue.selectedProject.projectId ===
          settingsConfirmation.projectId &&
        savedQueue.selectedProject.canonicalTarget ===
          settingsConfirmation.canonicalTarget;
      if (!readbackMatches)
        throw new Error(
          "Queue creation readback did not match the current saved source, selected project, or ready state.",
        );
      setQueues((current) => [...current, parsed.data]);
    } catch (cause) {
      setError(
        cause instanceof Error
          ? cause.message
          : "The timed queue could not be saved.",
      );
    } finally {
      setCreating(false);
    }
  };

  const [expandedQueueIds, setExpandedQueueIds] = useState<Set<string>>(
    () => new Set(),
  );
  const [historyPage, setHistoryPage] = useState(1);

  const toggleQueueExpand = (queueId: string) => {
    setExpandedQueueIds((prev) => {
      const next = new Set(prev);
      if (next.has(queueId)) next.delete(queueId);
      else next.add(queueId);
      return next;
    });
  };

  const sortedQueues = useMemo(
    () =>
      [...queues].sort(
        (a, b) =>
          b.createdAt - a.createdAt ||
          b.updatedAt - a.updatedAt ||
          b.queueId.localeCompare(a.queueId),
      ),
    [queues],
  );

  const currentQueue =
    sourceReady && savedSource
      ? sortedQueues.find((queue) => queue.sourceText === savedSource)
      : undefined;
  const otherQueues = sortedQueues.filter(
    (queue) => queue.queueId !== currentQueue?.queueId,
  );
  useEffect(() => {
    onCurrentQueueChange?.(currentQueue);
  }, [currentQueue, onCurrentQueueChange]);

  const unresolvedQueues = otherQueues.filter(isQueueCreationBlocker);
  const terminalQueues = otherQueues.filter(
    (queue) => !isQueueCreationBlocker(queue),
  );
  const latestTerminalQueue = terminalQueues[0];
  const olderTerminalQueues = terminalQueues.slice(1);
  const PAGE_SIZE = 10;
  const visibleOlderQueues = olderTerminalQueues.slice(
    0,
    historyPage * PAGE_SIZE,
  );
  const hasMoreOlder = olderTerminalQueues.length > visibleOlderQueues.length;

  const blockingPreviousQueue = otherQueues.find(isQueueCreationBlocker);
  const disabledReason = loading
    ? "Reading saved queues before allowing another queue."
    : error
      ? "Saved queue status is unavailable; creation is disabled until it can be checked."
      : !sourceReady || !savedSource
        ? "Validate and save the current image source before creating a queue."
        : currentQueue
          ? "This exact saved source already belongs to a timed queue."
          : blockingPreviousQueue
            ? `A previous queue is ${queueBlockerLabel(blockingPreviousQueue)}. Resolve it before creating another queue.`
            : settingsConfirmationError
              ? "Correct the Flow settings confirmation before creating a queue."
              : settingsConfirmationPending
                ? "Binding your manual settings confirmation to the selected Flow project."
                : !settingsConfirmation
                  ? "Confirm the manually selected Flow settings for this saved batch."
                  : creating
                    ? "Queue creation is being saved and read back."
                    : undefined;

  return (
    <section className={styles.progress} aria-labelledby="image-queue-title">
      <div className={styles.header}>
        <div>
          <p className={styles.kicker}>TIMED SUBMISSION MODE</p>
          <h3 id="image-queue-title">Image queue</h3>
        </div>
        <span className={styles.interval}>40 seconds between prompts</span>
      </div>
      <p className={styles.helper}>
        Sent counts durable local dispatch receipts. Image results are not
        verified.
      </p>
      <div className={styles.createCard}>
        <div>
          <strong>Current saved image source</strong>
          <p className={styles.helper}>
            {sourceReady && savedSource
              ? `${savedShotIds.length} prompt${savedShotIds.length === 1 ? "" : "s"} saved. Queue creation copies this exact source and its current Flow project binding.`
              : "Validate and save the new image source to prepare a timed queue."}
          </p>
          {sourceReady && savedShotIds.length > 0 ? (
            <p className={styles.shotSummary}>
              {savedShotIds.map((shotId) => `Shot ${shotId}`).join(" · ")}
            </p>
          ) : null}
        </div>
        <div className={styles.createSettings}>
          <strong>Confirm settings for this batch</strong>
          <p className={styles.helper}>
            The confirmation is bound to the selected Flow project. It must be
            made again after changing the saved source.
          </p>
          {settingsConfirmationControls}
        </div>
        <Button
          type="button"
          disabled={Boolean(disabledReason)}
          loading={creating}
          loadingLabel="Saving queue…"
          onClick={() => void createQueue()}
        >
          Create timed queue
        </Button>
        <span className={styles.helper} role="status">
          {disabledReason ??
            `Ready to save ${savedShotIds.length} prompt${savedShotIds.length === 1 ? "" : "s"}. Creation does not start dispatch.`}
        </span>
      </div>
      {error ? (
        <p className={styles.error} role="alert">
          {error}
        </p>
      ) : null}
      {error && !loading ? (
        <p className={styles.helper} role="status">
          Saved queue status unavailable. No empty-state conclusion can be made.
        </p>
      ) : null}
      {loading ? (
        <p className={styles.helper} role="status">
          Reading saved queues…
        </p>
      ) : null}
      {currentQueue ? (
        <div className={styles.currentQueueBlock}>
          <p className={styles.queueContext}>Queue for current saved batch</p>
          <QueueCard
            queue={currentQueue}
            commanding={
              commanding?.queueId === currentQueue.queueId
                ? commanding
                : undefined
            }
            starting={startingQueueId === currentQueue.queueId}
            busy={Boolean(commanding || startingQueueId)}
            onStart={() => void startQueue(currentQueue.queueId)}
            onCommand={(command) => void commandQueue(currentQueue, command)}
            persistenceClient={persistenceClient}
          />
        </div>
      ) : null}
      {unresolvedQueues.map((queue) => (
        <div className={styles.previousQueueBlock} key={queue.queueId}>
          <p className={styles.queueContext}>
            Operational queue — {titleCase(queue.state)}
          </p>
          <QueueCard
            queue={queue}
            commanding={
              commanding?.queueId === queue.queueId ? commanding : undefined
            }
            starting={startingQueueId === queue.queueId}
            busy={Boolean(commanding || startingQueueId)}
            onStart={() => void startQueue(queue.queueId)}
            onCommand={(command) => void commandQueue(queue, command)}
            persistenceClient={persistenceClient}
          />
        </div>
      ))}
      {latestTerminalQueue ? (
        <div
          className={styles.previousQueueBlock}
          key={latestTerminalQueue.queueId}
        >
          <p className={styles.queueContext}>Latest previous batch</p>
          <CompactQueueSummary
            queue={latestTerminalQueue}
            isExpanded={expandedQueueIds.has(latestTerminalQueue.queueId)}
            onToggleExpand={() =>
              toggleQueueExpand(latestTerminalQueue.queueId)
            }
            commanding={
              commanding?.queueId === latestTerminalQueue.queueId
                ? commanding
                : undefined
            }
            starting={startingQueueId === latestTerminalQueue.queueId}
            busy={Boolean(commanding || startingQueueId)}
            onStart={() => void startQueue(latestTerminalQueue.queueId)}
            onCommand={(command) =>
              void commandQueue(latestTerminalQueue, command)
            }
            persistenceClient={persistenceClient}
          />
        </div>
      ) : null}
      {olderTerminalQueues.length > 0 ? (
        <details className={styles.batchHistorySection}>
          <summary className={styles.batchHistorySummary}>
            <span>Batch history</span>
            <span className={styles.batchHistoryBadge}>
              {olderTerminalQueues.length} older{" "}
              {olderTerminalQueues.length === 1 ? "batch" : "batches"}
            </span>
          </summary>
          <div className={styles.batchHistoryList}>
            {visibleOlderQueues.map((queue) => (
              <CompactQueueSummary
                key={queue.queueId}
                queue={queue}
                isExpanded={expandedQueueIds.has(queue.queueId)}
                onToggleExpand={() => toggleQueueExpand(queue.queueId)}
                commanding={
                  commanding?.queueId === queue.queueId ? commanding : undefined
                }
                starting={startingQueueId === queue.queueId}
                busy={Boolean(commanding || startingQueueId)}
                onStart={() => void startQueue(queue.queueId)}
                onCommand={(command) => void commandQueue(queue, command)}
                persistenceClient={persistenceClient}
              />
            ))}
            {hasMoreOlder ? (
              <Button
                size="compact"
                variant="secondary"
                type="button"
                className={styles.loadMoreButton}
                onClick={() => setHistoryPage((p) => p + 1)}
              >
                Load more (
                {olderTerminalQueues.length - visibleOlderQueues.length}{" "}
                remaining)
              </Button>
            ) : null}
          </div>
        </details>
      ) : null}
    </section>
  );
}

export function formatQueueDate(timestamp: number): string {
  if (!timestamp || !Number.isFinite(timestamp)) return "";
  const date = new Date(timestamp);
  return date.toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function formatShotRange(
  items: readonly ImageQueueItem[],
): string | undefined {
  if (!items || items.length === 0) return undefined;
  const shotIds = items
    .map((item) => item.shotId)
    .filter(
      (id): id is string => typeof id === "string" && id.trim().length > 0,
    );
  if (shotIds.length === 0) {
    return `${items.length} prompt${items.length === 1 ? "" : "s"}`;
  }
  if (shotIds.length === 1) {
    return `Shot ${shotIds[0]}`;
  }
  const first = shotIds[0];
  const last = shotIds[shotIds.length - 1];
  const nums = shotIds.map(Number);
  const isContiguousSequence = nums.every(
    (n, i) => !Number.isNaN(n) && (i === 0 || n === nums[i - 1] + 1),
  );
  if (isContiguousSequence) {
    return `Shots ${first}–${last}`;
  }
  if (shotIds.length === items.length) {
    return `Shots ${first}–${last} (${items.length} prompts)`;
  }
  return `${items.length} prompts`;
}

export function CompactQueueSummary({
  queue,
  isExpanded,
  onToggleExpand,
  commanding,
  starting,
  busy,
  onStart,
  onCommand,
  persistenceClient,
  onInspectReadback,
  onRetryBlocked,
}: {
  queue: ImageSubmissionQueueRecord;
  isExpanded: boolean;
  onToggleExpand: () => void;
  commanding?: { queueId: string; command: "pause" | "resume" | "stop" };
  starting: boolean;
  busy: boolean;
  onStart: () => void;
  onCommand: (command: "pause" | "resume" | "stop") => void;
  persistenceClient?: FoundationClient;
  onInspectReadback?: (payload: {
    queueId: string;
    order: number;
  }) => Promise<FlowEditorReadbackInspectionResult>;
  onRetryBlocked?: (payload: {
    queueId: string;
    expectedRevision: number;
    order: number;
  }) => Promise<ImageSubmissionQueueRecord>;
}) {
  const sentCount = queue.items.filter((item) => item.dispatchReceipt).length;
  const isComplete =
    queue.items.length > 0 &&
    queue.items.every((item) => item.itemState === "sent");
  const status =
    queue.state === "sent" && isComplete ? "Finished" : titleCase(queue.state);
  const badgeClassKey = `state${status.replace(/[^a-zA-Z0-9]/g, "")}`;
  const badgeClass = styles[badgeClassKey] ?? styles.stateWaiting;
  const shotRange = formatShotRange(queue.items);
  const dateLabel = formatQueueDate(queue.createdAt);

  return (
    <div
      className={styles.compactCard}
      data-state={queue.state}
      data-queue-id={queue.queueId}
    >
      <div className={styles.compactHeader}>
        <div className={styles.compactMeta}>
          <span className={`${styles.stateBadge} ${badgeClass}`} role="status">
            {status}
          </span>
          <strong className={styles.compactSent}>
            {sentCount}/{queue.items.length} sent
          </strong>
          {shotRange ? (
            <span className={styles.compactShotRange}>{shotRange}</span>
          ) : null}
          {dateLabel ? (
            <span className={styles.compactDate}>{dateLabel}</span>
          ) : null}
        </div>
        <Button
          size="compact"
          variant="secondary"
          type="button"
          onClick={onToggleExpand}
          aria-expanded={isExpanded}
        >
          {isExpanded ? "Collapse" : "View details"}
        </Button>
      </div>
      {isExpanded ? (
        <div className={styles.compactExpanded}>
          <QueueCard
            queue={queue}
            commanding={commanding}
            starting={starting}
            busy={busy}
            onStart={onStart}
            onCommand={onCommand}
            persistenceClient={persistenceClient}
            onInspectReadback={onInspectReadback}
            onRetryBlocked={onRetryBlocked}
          />
        </div>
      ) : null}
    </div>
  );
}

export function QueueCard({
  queue,
  commanding,
  starting,
  busy,
  onStart,
  onCommand,
  persistenceClient,
  onInspectReadback,
  onRetryBlocked,
}: {
  queue: ImageSubmissionQueueRecord;
  commanding?: { queueId: string; command: "pause" | "resume" | "stop" };
  starting: boolean;
  busy: boolean;
  onStart: () => void;
  onCommand: (command: "pause" | "resume" | "stop") => void;
  persistenceClient?: FoundationClient;
  onInspectReadback?: (payload: {
    queueId: string;
    order: number;
  }) => Promise<FlowEditorReadbackInspectionResult>;
  onRetryBlocked?: (payload: {
    queueId: string;
    expectedRevision: number;
    order: number;
  }) => Promise<ImageSubmissionQueueRecord>;
}) {
  const [inspecting, setInspecting] = useState(false);
  const [retrying, setRetrying] = useState(false);
  const [inspectionResult, setInspectionResult] =
    useState<FlowEditorReadbackInspectionResult>();
  const [inspectionError, setInspectionError] = useState<string>();
  const [retryError, setRetryError] = useState<string>();

  const sentCount = queue.items.filter((item) => item.dispatchReceipt).length;
  const sendingItem = queue.items.find((item) => item.itemState === "sending");
  const blockedItem = queue.items.find((item) => item.itemState === "blocked");
  const nextItem = queue.items.find((item) => item.itemState === "pending");
  const focusItem =
    sendingItem ??
    blockedItem ??
    (queue.state === "blocked" || queue.state === "stopped"
      ? undefined
      : nextItem);

  const handleInspectEditor = async () => {
    if (inspecting || busy) return;
    setInspecting(true);
    setInspectionError(undefined);
    try {
      const targetOrder = blockedItem ? blockedItem.order : 0;
      let response: unknown;
      if (onInspectReadback) {
        response = await onInspectReadback({
          queueId: queue.queueId,
          order: targetOrder,
        });
      } else if (persistenceClient) {
        response = await persistenceClient.request(
          "imageQueue.inspectReadback",
          {
            queueId: queue.queueId,
            order: targetOrder,
          },
        );
      } else {
        throw new Error("No inspection client available.");
      }
      setInspectionResult(response as FlowEditorReadbackInspectionResult);
    } catch (cause) {
      if (cause instanceof FoundationClientError) {
        const stagePrefix = cause.stage ? `[${cause.stage}] ` : "";
        setInspectionError(
          `${stagePrefix}${cause.code} (${cause.category}): ${cause.message}`,
        );
      } else {
        setInspectionError(
          cause instanceof Error
            ? cause.message
            : "Editor readback inspection failed.",
        );
      }
    } finally {
      setInspecting(false);
    }
  };

  const handleGuardedRetry = async () => {
    if (retrying || busy || !blockedItem) return;
    setRetrying(true);
    setRetryError(undefined);
    try {
      if (onRetryBlocked) {
        await onRetryBlocked({
          queueId: queue.queueId,
          expectedRevision: queue.revision,
          order: blockedItem.order,
        });
      } else if (persistenceClient) {
        await persistenceClient.request("imageQueue.retryBlocked", {
          queueId: queue.queueId,
          expectedRevision: queue.revision,
          order: blockedItem.order,
        });
      } else {
        throw new Error("No client available for guarded retry.");
      }
      setInspectionResult(undefined);
    } catch (cause) {
      if (cause instanceof FoundationClientError) {
        const stagePrefix = cause.stage ? `[${cause.stage}] ` : "";
        setRetryError(
          `${stagePrefix}${cause.code} (${cause.category}): ${cause.message}`,
        );
      } else {
        setRetryError(
          cause instanceof Error
            ? cause.message
            : "Guarded retry operation failed.",
        );
      }
    } finally {
      setRetrying(false);
    }
  };
  const isComplete = sentCount === queue.items.length && queue.items.length > 0;
  const isWaitingForReadiness = Boolean(
    sendingItem?.dispatchIntent?.readinessDeadlineAt,
  );
  const status = isWaitingForReadiness
    ? "Waiting for Flow readiness"
    : sendingItem
      ? "Sending"
      : queue.state === "ready"
        ? "Ready"
        : queue.state === "sent" && isComplete
          ? "Finished"
          : titleCase(queue.state);
  const currentTitle = focusItem ? getPromptTitle(focusItem) : undefined;
  const queueKicker =
    queue.state === "waiting" || sendingItem
      ? "ACTIVE QUEUE"
      : queue.state === "ready"
        ? "READY QUEUE"
        : "QUEUE SUMMARY";

  const badgeClassKey = `state${status.replace(/[^a-zA-Z0-9]/g, "")}`;
  const badgeClass = styles[badgeClassKey] ?? styles.stateWaiting;

  return (
    <section
      className={styles.queue}
      aria-label={`Timed image queue ${queue.queueId}`}
      data-state={queue.state}
    >
      <div className={styles.queueHeader}>
        <div>
          <p className={styles.kicker}>{queueKicker}</p>
          <h4>{status}</h4>
        </div>
        <span
          className={`${styles.stateBadge} ${badgeClass}`}
          role="status"
          aria-live="polite"
        >
          {status}
        </span>
      </div>

      <div className={styles.summaryGrid}>
        <div className={styles.sentSummary}>
          <span>Prompts sent</span>
          <strong>
            {sentCount}
            <small> / {queue.items.length}</small>
          </strong>
          <span>Local dispatch receipts</span>
        </div>
        <div className={styles.nextSummary}>
          <span>
            {sendingItem
              ? "Current prompt"
              : blockedItem
                ? "Blocked prompt"
                : queue.state === "blocked"
                  ? "Queue blocked"
                  : queue.state === "stopped"
                    ? "Queue stopped"
                    : "Next prompt"}
          </span>
          {focusItem ? (
            <>
              <strong>{shotLabel(focusItem)}</strong>
              {currentTitle ? (
                <span className={styles.promptTitle}>{currentTitle}</span>
              ) : null}
            </>
          ) : (
            <strong>
              {queue.state === "stopped"
                ? "No further prompts will be sent."
                : isComplete
                  ? "No prompts remaining"
                  : queue.state === "blocked"
                    ? "Review required"
                    : "Checking next prompt…"}
            </strong>
          )}
        </div>
      </div>

      {queue.state === "waiting" &&
      queue.nextEligibleDispatchAt !== null &&
      nextItem ? (
        <WaitingClock
          deadline={queue.nextEligibleDispatchAt}
          item={nextItem}
          intervalMs={queue.intervalMs}
        />
      ) : null}
      {isWaitingForReadiness && sendingItem ? (
        <div className={styles.sending} role="status" aria-live="polite">
          <span className={styles.spinner} aria-hidden="true" />
          <span>Waiting for Flow readiness for {shotLabel(sendingItem)}…</span>
        </div>
      ) : sendingItem ? (
        <div className={styles.sending} role="status" aria-live="polite">
          <span className={styles.spinner} aria-hidden="true" />
          <span>Sending {shotLabel(sendingItem)}…</span>
        </div>
      ) : null}
      {queue.state === "paused" &&
      queue.pauseReason === "flow_generate_readiness_timeout" ? (
        <p className={styles.helper} role="status" aria-live="polite">
          Paused: Flow readiness timed out after 60s. Click Resume when the
          Generate button is ready.
        </p>
      ) : null}
      {queue.state === "waiting" && queue.nextEligibleDispatchAt === null ? (
        <p className={styles.checking} role="status" aria-live="polite">
          Checking next prompt…
        </p>
      ) : null}

      <div className={styles.actionRow}>
        {queue.state === "ready" &&
        queue.items.every((item) => item.itemState === "pending") ? (
          <Button
            type="button"
            disabled={busy}
            loading={starting}
            loadingLabel="Starting queue…"
            onClick={onStart}
          >
            Start queue
          </Button>
        ) : null}
        {queue.state === "waiting" ? (
          <Button
            type="button"
            disabled={busy}
            loading={commanding?.command === "pause"}
            loadingLabel="Pausing…"
            onClick={() => onCommand("pause")}
          >
            Pause
          </Button>
        ) : null}
        {queue.state === "paused" ? (
          <Button
            type="button"
            disabled={busy}
            loading={commanding?.command === "resume"}
            loadingLabel="Resuming…"
            onClick={() => onCommand("resume")}
          >
            Resume
          </Button>
        ) : null}
        {queue.state === "waiting" ||
        queue.state === "paused" ||
        queue.state === "ready" ? (
          <Button
            variant="secondary"
            className={styles.stopButton}
            type="button"
            disabled={busy}
            loading={commanding?.command === "stop"}
            loadingLabel="Stopping…"
            onClick={() => onCommand("stop")}
          >
            Stop queue
          </Button>
        ) : null}
        {queue.state === "blocked" ? (
          <Button
            type="button"
            variant="secondary"
            disabled={busy || inspecting || retrying}
            loading={inspecting}
            loadingLabel="Inspecting editor…"
            onClick={() => void handleInspectEditor()}
          >
            Inspect current editor (read-only)
          </Button>
        ) : null}
        {queue.state === "blocked" && inspectionResult?.equal ? (
          <Button
            type="button"
            variant="primary"
            disabled={busy || inspecting || retrying}
            loading={retrying}
            loadingLabel="Retrying…"
            onClick={() => void handleGuardedRetry()}
          >
            Retry {blockedItem ? shotLabel(blockedItem) : "blocked prompt"}{" "}
            (guarded)
          </Button>
        ) : null}
        {commanding ? (
          <span
            className={styles.commandStatus}
            role="status"
            aria-live="polite"
          >
            {commandPendingText(commanding.command)} Readback pending; saved
            status has not changed yet.
          </span>
        ) : null}
      </div>

      {isComplete ? (
        <div className={styles.complete} role="status" aria-live="polite">
          <strong>
            Batch submission finished — {sentCount}/{queue.items.length} prompts
            sent.
          </strong>
          <span>Image results are not verified.</span>
        </div>
      ) : null}
      {queue.state === "blocked" ? (
        <div className={styles.blocked} role="status">
          <strong>Blocked — review required.</strong>
          <details>
            <summary>View block reason</summary>
            <code>
              {queue.items.find((item) => item.blockReason)?.blockReason ??
                "review_required"}
            </code>
          </details>
          <span>Elapsed time does not authorize replay.</span>
        </div>
      ) : null}
      {inspectionError ? (
        <p className={styles.error} role="alert">
          Inspection error: {inspectionError}
        </p>
      ) : null}
      {retryError ? (
        <p className={styles.error} role="alert">
          Retry error: {retryError}
        </p>
      ) : null}
      {inspectionResult ? (
        <div
          className={styles.technicalDetails}
          data-testid="read-only-inspection-result"
        >
          <strong>
            Live editor inspection (read-only) —{" "}
            {inspectionResult.shotId
              ? `Shot ${inspectionResult.shotId}`
              : `Prompt ${inspectionResult.order + 1}`}
            :
          </strong>
          {inspectionResult.equal ? (
            <p>
              Current editor text matches prompt exactly (
              {inspectionResult.expectedCodeUnits} code units, SHA-256:{" "}
              <code>{inspectionResult.expectedSha256}</code>).
            </p>
          ) : (
            <>
              <p>
                Editor text does not match prompt (
                {inspectionResult.mismatchCategory ?? "mismatch"}).
              </p>
              <p>
                Expected: {inspectionResult.expectedCodeUnits} code units (
                {inspectionResult.expectedUtf8Bytes} bytes), SHA-256:{" "}
                <code>{inspectionResult.expectedSha256}</code>
              </p>
              {inspectionResult.actualCodeUnits !== undefined ? (
                <p>
                  Actual: {inspectionResult.actualCodeUnits} code units (
                  {inspectionResult.actualUtf8Bytes} bytes), SHA-256:{" "}
                  <code>{inspectionResult.actualSha256}</code>
                </p>
              ) : null}
              {inspectionResult.firstDifferenceOffset !== undefined ? (
                <p>
                  First difference at offset{" "}
                  {inspectionResult.firstDifferenceOffset} (
                  {inspectionResult.mismatchCategory}):
                  <br />
                  Expected context:{" "}
                  <code>{inspectionResult.expectedContext}</code>
                  <br />
                  Actual context: <code>{inspectionResult.actualContext}</code>
                </p>
              ) : null}
              {inspectionResult.readError ? (
                <p>
                  Read error: <code>{inspectionResult.readError}</code>
                </p>
              ) : null}
            </>
          )}
        </div>
      ) : null}
      {queue.state === "paused" ? (
        <p className={styles.inactiveNotice} role="status">
          {queue.pauseReason === "guarded_retry_ready"
            ? "Paused — guarded retry ready. The 40-second interval from previous dispatch receipt is preserved."
            : "Paused. No future prompt will be dispatched until the saved target and settings binding are revalidated."}
        </p>
      ) : null}
      {queue.state === "stopped" ? (
        <p className={styles.inactiveNotice} role="status">
          Stopped. Remaining prompts will not be sent. An authorized activation
          may have finished; provider results are not verified.
        </p>
      ) : null}

      <ol className={styles.items} aria-label="Prompt queue">
        {queue.items.map((item) => (
          <PromptRow
            key={item.queueItemId}
            item={item}
            queueState={queue.state}
            active={item === focusItem && !isComplete}
          />
        ))}
      </ol>
      <details className={styles.technicalDetails}>
        <summary>Queue and provider evidence</summary>
        <p>
          Queue ID: <code>{queue.queueId}</code>
        </p>
        <p>
          Stored interval: {TIMED_IMAGE_SUBMISSION_INTERVAL_MS.toLocaleString()}{" "}
          ms. A deadline makes the next prompt eligible for worker recheck; it
          does not mark it sent.
        </p>
        <p>
          Project and exact source are frozen in this queue snapshot. Sent means
          a local dispatch receipt exists; image results are not verified.
        </p>
      </details>
    </section>
  );
}

function WaitingClock({
  deadline,
  item,
  intervalMs,
}: {
  deadline: number;
  item: ImageQueueItem;
  intervalMs: number;
}) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);
  const remainingMs = Math.max(0, deadline - now);
  const seconds = Math.ceil(remainingMs / 1000);
  const display = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
  const percent = Math.max(
    0,
    Math.min(100, ((intervalMs - remainingMs) / intervalMs) * 100),
  );
  const promptTitle = getPromptTitle(item);

  return (
    <div className={styles.waitingPanel}>
      <div className={styles.clockHeader}>
        <span>Time until next prompt</span>
        <span>
          {shotLabel(item)}
          {promptTitle ? ` · ${promptTitle}` : ""}
        </span>
      </div>
      <div
        className={styles.countdown}
        role="timer"
        aria-live="off"
        aria-label={`Time until next prompt: ${display}`}
      >
        {display}
      </div>
      <div className={styles.waitingTrack} aria-hidden="true">
        <span style={{ width: `${percent}%` }} />
      </div>
      <p className={styles.clockHint}>
        {remainingMs === 0
          ? "Checking next prompt…"
          : "The saved deadline controls eligibility. Sent changes only after receipt readback."}
      </p>
    </div>
  );
}

function PromptRow({
  item,
  queueState,
  active,
}: {
  item: ImageQueueItem;
  queueState: ImageSubmissionQueueRecord["state"];
  active: boolean;
}) {
  const effectiveState =
    item.itemState === "pending" && queueState === "paused"
      ? "paused"
      : item.itemState === "pending" && queueState === "stopped"
        ? "stopped"
        : item.itemState;
  const icon = {
    pending: "○",
    sending: "◌",
    sent: "✓",
    paused: "Ⅱ",
    blocked: "!",
    stopped: "—",
  }[effectiveState];
  return (
    <li
      className={`${styles.item} ${active ? styles.itemActive : ""}`}
      data-active={active || undefined}
    >
      <span
        className={`${styles.itemIcon} ${styles[`item${titleCase(effectiveState)}`]}`}
        aria-hidden="true"
      >
        {icon}
      </span>
      <div className={styles.itemIdentity}>
        <strong>{shotLabel(item)}</strong>
        <span>{getPromptTitle(item) ?? `Prompt ${item.order + 1}`}</span>
      </div>
      <span
        className={`${styles.itemBadge} ${styles[`item${titleCase(effectiveState)}`]}`}
      >
        {titleCase(effectiveState)}
      </span>
      <details className={styles.sourceDetails}>
        <summary>Source &amp; evidence</summary>
        <p>
          {item.dispatchReceipt
            ? "Dispatch receipt stored. Provider outcome is unknown."
            : item.providerOutcome === "unknown"
              ? "Activation is uncertain; automatic replay is blocked."
              : "Not dispatched. Provider outcome not started."}
        </p>
        {item.blockReason ? <code>{item.blockReason}</code> : null}
        {item.readbackDiagnostic ? (
          <div className={styles.technicalDetails}>
            <strong>
              Readback mismatch diagnostics ({item.readbackDiagnostic.stage}):
            </strong>
            <p>
              Expected: {item.readbackDiagnostic.expectedCodeUnits} code units (
              {item.readbackDiagnostic.expectedUtf8Bytes} bytes), SHA-256:{" "}
              <code>{item.readbackDiagnostic.expectedSha256}</code>
            </p>
            {item.readbackDiagnostic.actualCodeUnits !== undefined ? (
              <p>
                Actual: {item.readbackDiagnostic.actualCodeUnits} code units (
                {item.readbackDiagnostic.actualUtf8Bytes} bytes), SHA-256:{" "}
                <code>{item.readbackDiagnostic.actualSha256}</code>
              </p>
            ) : null}
            {item.readbackDiagnostic.firstDifferenceOffset !== undefined ? (
              <p>
                First difference at offset{" "}
                {item.readbackDiagnostic.firstDifferenceOffset} (
                {item.readbackDiagnostic.mismatchCategory}):
                <br />
                Expected context:{" "}
                <code>{item.readbackDiagnostic.expectedContext}</code>
                <br />
                Actual context:{" "}
                <code>{item.readbackDiagnostic.actualContext}</code>
              </p>
            ) : null}
            {item.readbackDiagnostic.settledEqual !== undefined ? (
              <p>
                Settled editor sample:{" "}
                {item.readbackDiagnostic.settledEqual ? (
                  <span>
                    Matched expected text (
                    {item.readbackDiagnostic.settledActualCodeUnits} code
                    units). Initial dispatch sample failed.
                  </span>
                ) : (
                  <span>
                    Mismatched ({item.readbackDiagnostic.settledActualCodeUnits}{" "}
                    code units, SHA-256:{" "}
                    <code>{item.readbackDiagnostic.settledActualSha256}</code>)
                  </span>
                )}
              </p>
            ) : null}
            {item.readbackDiagnostic.readError ? (
              <p>Read error: {item.readbackDiagnostic.readError}</p>
            ) : null}
          </div>
        ) : null}
        <pre>{item.rawJsonBody}</pre>
      </details>
    </li>
  );
}

function getPromptTitle(item: ImageQueueItem) {
  try {
    const body: unknown = JSON.parse(item.rawJsonBody);
    if (!body || typeof body !== "object" || Array.isArray(body))
      return undefined;
    const fields = body as Record<string, unknown>;
    const title = fields.scene_title ?? fields.shot_title ?? fields.title;
    return typeof title === "string" && title.trim() ? title.trim() : undefined;
  } catch {
    return undefined;
  }
}

function shotLabel(item: ImageQueueItem) {
  return item.shotId ? `Shot ${item.shotId}` : `Prompt ${item.order + 1}`;
}

function titleCase(value: string) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

function commandPendingText(command: "pause" | "resume" | "stop") {
  return {
    pause: "Pausing queue…",
    resume: "Resuming queue…",
    stop: "Stopping queue…",
  }[command];
}

export function isQueueCreationBlocker(queue: ImageSubmissionQueueRecord) {
  return (
    ["ready", "waiting", "paused", "blocked"].includes(queue.state) ||
    queue.items.some(
      (item) =>
        item.itemState === "sending" ||
        (item.providerOutcome === "unknown" && !item.dispatchReceipt),
    )
  );
}

function queueBlockerLabel(queue: ImageSubmissionQueueRecord) {
  if (queue.state === "blocked") return "blocked or uncertain";
  if (queue.state === "paused") return "paused";
  if (queue.state === "waiting") return "active";
  if (queue.state === "ready") return "ready to start";
  return "awaiting review";
}
