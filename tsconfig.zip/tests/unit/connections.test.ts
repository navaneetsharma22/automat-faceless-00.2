import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { BUILD_ID } from "../../src/shared/buildInfo";
import {
  attachToSelectedTab,
  formatHandshakeDiagnostics,
  isSameProviderTargetUrl,
  providerTabFromUrl,
  verifyPersistedTarget,
} from "../../src/platforms/shared/connection";
import { classifyProviderRouteUpdate } from "../../src/platforms/shared/providerRoute";
import {
  createChromeConnectionPort,
  hasTabListingAccess,
  listOpenProviderTabs,
  requestProviderAccess,
  requestTabListingAccess,
} from "../../src/platforms/shared/chromeConnectionPort";
import {
  CONNECTION_CAPABILITY,
  CONNECTOR_PROTOCOL_VERSION,
  type ConnectionPort,
  type ConnectionProbeRequest,
  type ConnectionProbeResponse,
  type ProviderName,
  type ProviderTab,
} from "../../src/platforms/shared/contracts";
import {
  isCurrentConnectionAttempt,
  isCurrentWorkerStart,
  providerDocumentNeedsReverification,
  readWorkerStartEvent,
  workerStartAction,
} from "../../src/platforms/shared/connectionLifecycle";
import { FOUNDATION_WORKER_RESTARTED } from "../../src/shared/messages";
import { PROTOCOL_VERSION } from "../../src/shared/buildInfo";
import { FlowClipDownloadStartError } from "../../src/background/flowDownloadDiagnostic";
import { flowClipDownloadStartFailure } from "../../src/background/handlers/connections";
import {
  connectionApiDiagnostic,
  getChromeExecutionContext,
  hasDiscoveryApis,
  hasWorkerMessagingApi,
} from "../../src/platforms/shared/chromeApiDiagnostics";

beforeEach(() => {
  vi.stubGlobal("location", {
    protocol: "chrome-extension:",
    hostname: "offline-extension",
  });
});

afterEach(() => {
  vi.unstubAllGlobals();
  vi.resetModules();
  delete (
    globalThis as typeof globalThis & {
      __automatFacelessConnector?: unknown;
    }
  ).__automatFacelessConnector;
  delete (
    globalThis as typeof globalThis & {
      __automatFacelessConnectionProbeInstalled?: boolean;
    }
  ).__automatFacelessConnectionProbeInstalled;
});

function makeTab(
  id = 42,
  provider: ProviderName = "Flow",
  projectId = "project-1",
): ProviderTab {
  const url =
    provider === "Flow"
      ? `https://labs.google/fx/tools/flow/${projectId}`
      : `https://vids.google.com/video/${projectId}/edit`;
  return providerTabFromUrl(id, `${provider} ${projectId}`, url)!;
}

function makeResponse(
  tab: ProviderTab,
  request: ConnectionProbeRequest,
  overrides: Partial<ConnectionProbeResponse> = {},
): ConnectionProbeResponse {
  return {
    ok: true,
    provider: tab.provider,
    canonicalTarget: tab.canonicalTarget,
    projectId: tab.projectId,
    protocolVersion: CONNECTOR_PROTOCOL_VERSION,
    buildId: BUILD_ID,
    attemptId: request.attemptId,
    documentToken: "document-token-1",
    capabilities: [CONNECTION_CAPABILITY],
    ...overrides,
  };
}

function makePort(tab = makeTab()) {
  let request: ConnectionProbeRequest | undefined;
  const port = {
    getMissingAccess: vi.fn(async () => ({})),
    getTab: vi.fn(async () => tab),
    pingTopFrame: vi.fn(async (_tabId, value) => {
      request = value;
      return undefined;
    }),
    identifyDocument: vi.fn(async () => ({
      documentId: "chrome-document-1",
      frameId: 0,
      url: tab.url,
    })),
    injectConnector: vi.fn(async () => ({
      documentId: "chrome-document-1",
      frameId: 0,
      url: tab.url,
    })),
    probeTopFrame: vi.fn(async (_tabId, _documentId, value) => {
      request = value;
      return makeResponse(tab, value);
    }),
    releaseConnector: vi.fn(async () => undefined),
    makeAttemptId: vi.fn(() => "attempt-1"),
  } satisfies ConnectionPort;
  const forbiddenTabActions = {
    reload: vi.fn(),
    navigate: vi.fn(),
    update: vi.fn(),
    replace: vi.fn(),
    close: vi.fn(),
    reopen: vi.fn(),
    remove: vi.fn(),
    mutateContent: vi.fn(),
    mutateTimeline: vi.fn(),
    mutateSettings: vi.fn(),
  };
  return { port, tab, forbiddenTabActions, getRequest: () => request };
}

function expectProviderUntouched(
  actions: ReturnType<typeof makePort>["forbiddenTabActions"],
) {
  for (const action of Object.values(actions)) {
    expect(action).not.toHaveBeenCalled();
  }
}

describe("explicit read-only Flow/Vids attachment", () => {
  it("accepts only the observed project routes and extracts stable IDs", () => {
    expect(
      providerTabFromUrl(
        8,
        "Flow project",
        "https://flow.google.com/project/AbC_9-xy?panel=assets",
      ),
    ).toMatchObject({
      provider: "Flow",
      projectId: "AbC_9-xy",
      canonicalTarget: "https://flow.google.com/project/AbC_9-xy",
    });
    const accountFlowUrl = "https://flow.google.com/u/1/project/AbC_9-xy?pli=1";
    expect(
      providerTabFromUrl(18, "Account Flow project", accountFlowUrl),
    ).toMatchObject({
      provider: "Flow",
      projectId: "AbC_9-xy",
      url: accountFlowUrl,
      canonicalTarget: "https://flow.google.com/u/1/project/AbC_9-xy",
    });
    const detailUrl = "https://flow.google.com/u/1/project/AbC_9-xy/edit/268e65f5-7fd4-4918-9e9e-6744371d16a8";
    expect(providerTabFromUrl(18, "Flow asset detail", detailUrl)).toMatchObject({
      provider: "Flow",
      projectId: "AbC_9-xy",
      canonicalTarget: "https://flow.google.com/u/1/project/AbC_9-xy",
    });
    expect(classifyProviderRouteUpdate("https://flow.google.com/u/1/project/AbC_9-xy", detailUrl)).toBe("same_project_route_changed");
    expect(classifyProviderRouteUpdate("https://flow.google.com/u/1/project/AbC_9-xy", accountFlowUrl)).toBe("same_project_route_changed");
    expect(classifyProviderRouteUpdate("https://flow.google.com/u/1/project/AbC_9-xy", "https://flow.google.com/u/2/project/AbC_9-xy/edit/268e65f5-7fd4-4918-9e9e-6744371d16a8")).toBe("project_route_changed");
    expect(classifyProviderRouteUpdate("https://flow.google.com/u/1/project/AbC_9-xy", "https://flow.google.com/u/1/project/Other/edit/268e65f5-7fd4-4918-9e9e-6744371d16a8")).toBe("project_route_changed");
    expect(providerTabFromUrl(18, "Flow arbitrary nested route", "https://flow.google.com/u/1/project/AbC_9-xy/edit/extra/path")).toBeUndefined();
    expect(
      isSameProviderTargetUrl(
        providerTabFromUrl(18, "Account Flow project", accountFlowUrl)!,
        "https://flow.google.com/u/2/project/AbC_9-xy",
      ),
    ).toBe(false);
    expect(
      providerTabFromUrl(
        9,
        "Flow project",
        "https://labs.google/fx/tools/flow/project_9?tab=assets",
      ),
    ).toMatchObject({
      provider: "Flow",
      projectId: "project_9",
      canonicalTarget: "https://labs.google/fx/tools/flow/project_9",
    });
    expect(
      providerTabFromUrl(
        10,
        "Vids document",
        "https://vids.google.com/video/vid-10/edit?panel=share",
      ),
    ).toMatchObject({
      provider: "Vids",
      projectId: "vid-10",
      canonicalTarget: "https://vids.google.com/video/vid-10/edit",
    });
    const actualVidsUrl =
      "https://docs.google.com/videos/d/VIDEO_ID/edit?pli=1&scene=id.p#scene=id.p";
    expect(
      providerTabFromUrl(17, "Vids document", actualVidsUrl),
    ).toMatchObject({
      provider: "Vids",
      projectId: "VIDEO_ID",
      url: actualVidsUrl,
      canonicalTarget: "https://docs.google.com/videos/d/VIDEO_ID/edit",
    });
    const selectedVids = providerTabFromUrl(
      17,
      "Vids document",
      actualVidsUrl,
    )!;
    expect(
      isSameProviderTargetUrl(
        selectedVids,
        "https://docs.google.com/videos/d/VIDEO_ID/edit?scene=other#scene=other",
      ),
    ).toBe(true);
    expect(
      isSameProviderTargetUrl(
        selectedVids,
        "https://docs.google.com/videos/d/DIFFERENT_ID/edit?scene=id.p",
      ),
    ).toBe(false);
    expect(
      providerTabFromUrl(11, "Vids home", "https://vids.google.com/"),
    ).toBeUndefined();
    expect(
      providerTabFromUrl(
        12,
        "Other Google page",
        "https://docs.google.com/document/d/not-a-vids-project/edit",
      ),
    ).toBeUndefined();
    expect(
      providerTabFromUrl(
        13,
        "Flow nested route",
        "https://labs.google/fx/tools/flow/project-1/settings",
      ),
    ).toBeUndefined();
    expect(
      providerTabFromUrl(
        14,
        "Flow nested route",
        "https://flow.google.com/project/valid/settings",
      ),
    ).toBeUndefined();
    expect(
      providerTabFromUrl(
        15,
        "Spoofed Flow host",
        "https://flow.google.com.evil.example/project/valid",
      ),
    ).toBeUndefined();
    expect(
      providerTabFromUrl(
        16,
        "Credentials in URL",
        "https://user:secret@flow.google.com/project/valid",
      ),
    ).toBeUndefined();
  });

  it("uses the explicitly selected account/project tab when several are open", async () => {
    vi.stubGlobal("chrome", {
      tabs: {
        query: vi.fn().mockResolvedValue([
          {
            id: 31,
            title: "Flow project in another account",
            url: "https://flow.google.com/u/0/project/shared-project",
          },
          {
            id: 32,
            title: "Flow project selected by the user",
            url: "https://flow.google.com/u/4/project/shared-project",
          },
        ]),
      },
    });
    const listing = await listOpenProviderTabs();
    expect(listing.tabs.map((tab) => tab.id)).toEqual([31, 32]);
    const otherAccount = listing.tabs[0]!;
    const selected = listing.tabs[1]!;
    const { port, getRequest } = makePort(selected);

    const result = await attachToSelectedTab("Flow", selected, port);

    expect(result).toMatchObject({ ok: true, state: "connected" });
    expect(port.getTab).toHaveBeenCalledWith(32);
    expect(port.probeTopFrame).toHaveBeenCalledWith(
      32,
      "chrome-document-1",
      expect.objectContaining({ canonicalTarget: selected.canonicalTarget }),
    );
    expect(getRequest()?.canonicalTarget).toBe(selected.canonicalTarget);
    expect(otherAccount.canonicalTarget).not.toBe(selected.canonicalTarget);
  });

  it("attaches only to the user-selected candidate and reuses a compatible connector", async () => {
    const candidates = [
      makeTab(41, "Flow", "first"),
      makeTab(42, "Flow", "chosen"),
    ];
    const chosen = candidates[1]!;
    const { port, forbiddenTabActions, getRequest } = makePort(chosen);
    vi.mocked(port.pingTopFrame).mockImplementation(async (_id, request) => {
      return makeResponse(chosen, request);
    });

    const result = await attachToSelectedTab("Flow", chosen, port);

    expect(result).toMatchObject({ ok: true, tab: chosen, state: "connected" });
    expect(port.getTab).toHaveBeenCalledWith(chosen.id);
    expect(port.identifyDocument).toHaveBeenCalledExactlyOnceWith(
      chosen.id,
      chosen,
    );
    expect(port.injectConnector).not.toHaveBeenCalled();
    expect(port.probeTopFrame).toHaveBeenCalledWith(
      chosen.id,
      "chrome-document-1",
      expect.objectContaining({ attemptId: "attempt-1" }),
    );
    expect(getRequest()?.projectId).toBe("chosen");
    expect(candidates[0]?.id).not.toBe(chosen.id);
    expectProviderUntouched(forbiddenTabActions);
  });

  it("pings first, injects into the selected top frame, then revalidates identity", async () => {
    for (const provider of ["Flow", "Vids"] as const) {
      const tab = makeTab(provider === "Flow" ? 20 : 21, provider, "selected");
      const { port, forbiddenTabActions } = makePort(tab);
      const result = await attachToSelectedTab(provider, tab, port);

      expect(result).toMatchObject({ ok: true, tab, state: "connected" });
      expect(port.pingTopFrame).toHaveBeenCalledBefore(port.injectConnector);
      expect(port.injectConnector).toHaveBeenCalledExactlyOnceWith(tab.id, tab);
      expect(port.getTab).toHaveBeenCalledTimes(3);
      expect(port.probeTopFrame).toHaveBeenCalledExactlyOnceWith(
        tab.id,
        "chrome-document-1",
        expect.objectContaining({ provider, projectId: "selected" }),
      );
      expectProviderUntouched(forbiddenTabActions);
    }
  });

  it("rejects a changed project before attachment and a changed project after injection", async () => {
    const selected = makeTab();
    const { port, forbiddenTabActions } = makePort(selected);
    vi.mocked(port.getTab).mockResolvedValueOnce(
      makeTab(selected.id, "Flow", "changed-project"),
    );
    const changed = await attachToSelectedTab("Flow", selected, port);
    expect(changed).toMatchObject({ ok: false, state: "wrong-target" });
    expect(port.pingTopFrame).not.toHaveBeenCalled();

    const { port: afterInjectionPort, forbiddenTabActions: afterActions } =
      makePort(selected);
    vi.mocked(afterInjectionPort.getTab)
      .mockResolvedValueOnce(selected)
      .mockResolvedValueOnce(makeTab(selected.id, "Flow", "changed-project"));
    const afterInjection = await attachToSelectedTab(
      "Flow",
      selected,
      afterInjectionPort,
    );
    expect(afterInjection).toMatchObject({ ok: false, state: "wrong-target" });
    expect(afterInjectionPort.probeTopFrame).not.toHaveBeenCalled();
    expectProviderUntouched(forbiddenTabActions);
    expectProviderUntouched(afterActions);
  });

  it("blocks a changed document and any non-top-frame identity", async () => {
    const tab = makeTab();
    const { port } = makePort(tab);
    vi.mocked(port.getTab)
      .mockResolvedValueOnce(tab)
      .mockResolvedValueOnce(tab)
      .mockResolvedValueOnce(makeTab(tab.id, "Flow", "new-document-project"));
    const changedDocument = await attachToSelectedTab("Flow", tab, port);
    expect(changedDocument).toMatchObject({ ok: false, state: "wrong-target" });

    const nonTop = makePort(tab);
    vi.mocked(nonTop.port.injectConnector).mockResolvedValueOnce({
      documentId: "child-frame",
      frameId: 3,
      url: tab.url,
    });
    const nonTopResult = await attachToSelectedTab("Flow", tab, nonTop.port);
    expect(nonTopResult).toMatchObject({ ok: false, state: "failed" });
    expect(nonTop.port.probeTopFrame).not.toHaveBeenCalled();
  });

  it("reports missing access without probing or injecting", async () => {
    const { port, forbiddenTabActions } = makePort();
    vi.mocked(port.getMissingAccess).mockResolvedValueOnce({
      permissions: ["scripting"],
      origins: ["https://labs.google/*"],
    });
    const result = await attachToSelectedTab("Flow", makeTab(), port);
    expect(result).toMatchObject({
      ok: false,
      state: "permission-needed",
      stage: "permission_check",
      permissionRequest: {
        permissions: ["scripting"],
        origins: ["https://labs.google/*"],
      },
    });
    expect(port.getTab).not.toHaveBeenCalled();
    expect(port.pingTopFrame).not.toHaveBeenCalled();
    expect(port.injectConnector).not.toHaveBeenCalled();
    expectProviderUntouched(forbiddenTabActions);
  });

  it("inspects connect permissions and requests only the selected site from its own action", async () => {
    const permissions = {
      contains: vi
        .fn()
        .mockResolvedValueOnce(true)
        .mockResolvedValueOnce(false),
      request: vi.fn().mockResolvedValue(true),
    };
    vi.stubGlobal("chrome", {
      runtime: { id: "offline-extension" },
      permissions,
      tabs: { get: vi.fn(), query: vi.fn(), sendMessage: vi.fn() },
      scripting: { executeScript: vi.fn() },
    });
    const port = createChromeConnectionPort()!;

    expect(await port.getMissingAccess("Flow", makeTab())).toEqual({
      origins: ["https://labs.google/*"],
    });
    expect(permissions.contains).toHaveBeenNthCalledWith(1, {
      permissions: ["scripting"],
    });
    expect(permissions.contains).toHaveBeenNthCalledWith(2, {
      origins: ["https://labs.google/*"],
    });
    expect(permissions.request).not.toHaveBeenCalled();

    permissions.contains
      .mockResolvedValueOnce(true)
      .mockResolvedValueOnce(false);
    const currentFlowRoute = providerTabFromUrl(
      19,
      "Flow current route",
      "https://flow.google.com/project/selected-project",
    )!;
    expect(await port.getMissingAccess("Flow", currentFlowRoute)).toEqual({
      origins: ["https://flow.google.com/*"],
    });
    expect(permissions.contains).toHaveBeenNthCalledWith(3, {
      permissions: ["scripting"],
    });
    expect(permissions.contains).toHaveBeenNthCalledWith(4, {
      origins: ["https://flow.google.com/*"],
    });
    expect(permissions.request).not.toHaveBeenCalled();

    permissions.contains
      .mockResolvedValueOnce(true)
      .mockResolvedValueOnce(false);
    const actualVidsRoute = providerTabFromUrl(
      21,
      "Vids document",
      "https://docs.google.com/videos/d/VIDEO_ID/edit?pli=1&scene=id.p#scene=id.p",
    )!;
    expect(await port.getMissingAccess("Vids", actualVidsRoute)).toEqual({
      origins: ["https://docs.google.com/*"],
    });
    expect(permissions.contains).toHaveBeenNthCalledWith(5, {
      permissions: ["scripting"],
    });
    expect(permissions.contains).toHaveBeenNthCalledWith(6, {
      origins: ["https://docs.google.com/*"],
    });
    expect(permissions.request).not.toHaveBeenCalled();

    await expect(
      port.getMissingAccess(
        "Vids",
        providerTabFromUrl(
          20,
          "Vids project",
          "https://flow.google.com/project/wrong-provider",
        )!,
      ),
    ).rejects.toThrow("Selected provider origin is unsupported");
    expect(permissions.request).not.toHaveBeenCalled();

    permissions.request.mockResolvedValueOnce(false);
    const selectedAccess = requestProviderAccess({
      origins: ["https://flow.google.com/*"],
    });
    expect(permissions.request).toHaveBeenCalledExactlyOnceWith({
      origins: ["https://flow.google.com/*"],
    });
    expect(await selectedAccess).toBe(false);
    permissions.request.mockRejectedValueOnce(new Error("denied by browser"));
    await expect(
      requestProviderAccess({ permissions: ["scripting"] }),
    ).rejects.toThrow("denied by browser");
  });

  it("recognizes already-granted provider permissions without requesting again", async () => {
    const permissions = {
      contains: vi.fn().mockResolvedValue(true),
      request: vi.fn(),
    };
    vi.stubGlobal("chrome", {
      runtime: { id: "offline-extension" },
      permissions,
      tabs: { get: vi.fn(), query: vi.fn(), sendMessage: vi.fn() },
      scripting: { executeScript: vi.fn() },
    });
    const port = createChromeConnectionPort()!;

    expect(await port.getMissingAccess("Flow", makeTab())).toEqual({});
    expect(permissions.contains).toHaveBeenNthCalledWith(1, {
      permissions: ["scripting"],
    });
    expect(permissions.contains).toHaveBeenNthCalledWith(2, {
      origins: ["https://labs.google/*"],
    });
    expect(permissions.request).not.toHaveBeenCalled();
  });

  it("first checks tabs access, then requests it synchronously from the dedicated user action", async () => {
    const query = vi.fn().mockResolvedValue([
      {
        id: 5,
        title: "Flow project",
        url: "https://flow.google.com/project/selected-project",
      },
    ]);
    const permissions = {
      contains: vi.fn().mockResolvedValue(false),
      request: vi.fn().mockResolvedValue(true),
    };
    vi.stubGlobal("chrome", {
      runtime: { id: "offline-extension" },
      permissions,
      tabs: { query, get: vi.fn(), sendMessage: vi.fn() },
      scripting: { executeScript: vi.fn() },
    });

    expect(await hasTabListingAccess()).toBe(false);
    expect(permissions.contains).toHaveBeenCalledExactlyOnceWith({
      permissions: ["tabs"],
    });
    expect(query).not.toHaveBeenCalled();

    const permissionRequest = requestTabListingAccess();
    expect(permissions.request).toHaveBeenCalledExactlyOnceWith({
      permissions: ["tabs"],
    });
    expect(await permissionRequest).toBe(true);

    const listing = await listOpenProviderTabs();
    expect(query).toHaveBeenCalledExactlyOnceWith({});
    expect(listing.tabs).toMatchObject([
      { provider: "Flow", projectId: "selected-project" },
    ]);
  });

  it("keeps a packaged connection port available before optional scripting access is granted", async () => {
    let granted = false;
    const executeScript = vi.fn(async () => [
      {
        documentId: "doc-after-grant",
        frameId: 0,
        result: "https://flow.google.com/project/selected-project",
      },
    ]);
    const extensionChrome = {
      runtime: { id: "offline-extension" },
      permissions: {
        contains: vi.fn(async () => granted),
        request: vi.fn(async () => true),
      },
      tabs: { get: vi.fn(), query: vi.fn(), sendMessage: vi.fn() },
      scripting: undefined as unknown as typeof chrome.scripting,
    };
    vi.stubGlobal("chrome", extensionChrome);
    const selected = providerTabFromUrl(
      42,
      "Flow project",
      "https://flow.google.com/project/selected-project",
    )!;

    expect(getChromeExecutionContext()).toBe("packaged_extension");
    expect(hasDiscoveryApis()).toBe(true);
    expect(hasWorkerMessagingApi()).toBe(false);
    const port = createChromeConnectionPort();
    expect(port).toBeDefined();
    expect(await port!.getMissingAccess("Flow", selected)).toEqual({
      permissions: ["scripting"],
      origins: ["https://flow.google.com/*"],
    });

    await expect(
      port!.injectConnector(selected.id, selected),
    ).rejects.toMatchObject({
      name: "ConnectionApiUnavailableError",
      stage: "connector_injection",
      diagnostic: expect.stringContaining(
        "missing_api=chrome.scripting.executeScript",
      ),
    });
    const beforeGrant = await connectionApiDiagnostic(
      "connector_injection",
      selected,
    );
    expect(beforeGrant).toContain("context=packaged_extension");
    expect(beforeGrant).toContain("permission.scripting=not_granted");
    expect(beforeGrant).toContain("permission.selected_host=not_granted");

    const permission = requestProviderAccess({
      permissions: ["scripting"],
      origins: ["https://flow.google.com/*"],
    });
    expect(extensionChrome.permissions.request).toHaveBeenCalledWith({
      permissions: ["scripting"],
      origins: ["https://flow.google.com/*"],
    });
    await expect(permission).resolves.toBe(true);
    granted = true;
    extensionChrome.scripting = { executeScript };

    const afterGrantPort = createChromeConnectionPort();
    expect(afterGrantPort).toBeDefined();
    expect(await afterGrantPort!.getMissingAccess("Flow", selected)).toEqual(
      {},
    );
    await expect(
      afterGrantPort!.injectConnector(selected.id, selected),
    ).resolves.toMatchObject({
      documentId: "doc-after-grant",
      frameId: 0,
    });
  });

  it("reports localhost and invalid extension contexts without confusing them with optional access", async () => {
    vi.stubGlobal("chrome", undefined);
    vi.stubGlobal("location", {
      protocol: "http:",
      hostname: "localhost",
    });
    expect(getChromeExecutionContext()).toBe("localhost_preview");
    expect(hasDiscoveryApis()).toBe(false);
    await expect(connectionApiDiagnostic("discovery")).resolves.toContain(
      "context=localhost_preview; stage=discovery; missing_api=chrome.runtime.id",
    );

    vi.stubGlobal("location", {
      protocol: "https:",
      hostname: "example.test",
    });
    vi.stubGlobal("chrome", {
      runtime: {},
      tabs: { get: vi.fn(), query: vi.fn(), sendMessage: vi.fn() },
      permissions: { contains: vi.fn(), request: vi.fn() },
    });
    expect(getChromeExecutionContext()).toBe("invalid_extension_context");
    expect(createChromeConnectionPort()).toBeUndefined();
    await expect(
      connectionApiDiagnostic("connection_setup"),
    ).resolves.toContain("runtime.id=absent");

    vi.stubGlobal("location", {
      protocol: "chrome-extension:",
      hostname: "offline-extension",
    });
    await expect(
      connectionApiDiagnostic("connection_setup"),
    ).resolves.toContain(
      "extension_context_invalidated; context=invalidated_extension_context",
    );
  });

  it("distinguishes unsupported provider routes and unavailable URLs from no matches", async () => {
    const query = vi.fn().mockResolvedValue([
      {
        id: 1,
        title: "Flow project",
        url: "https://labs.google/fx/tools/flow/project-1/settings",
      },
      {
        id: 6,
        title: "Unsupported Vids route",
        url: "https://docs.google.com/videos/d/video-1/preview",
      },
      { id: 2, title: "Hidden URL" },
      { id: 3, title: "Unrelated", url: "https://example.com/" },
    ]);
    vi.stubGlobal("chrome", { tabs: { query } });

    await expect(listOpenProviderTabs()).resolves.toMatchObject({
      tabs: [],
      unsupportedProviderRoutes: 2,
      unavailableUrls: 1,
    });
    query.mockResolvedValueOnce([
      {
        id: 5,
        title: "Vids document",
        url: "https://docs.google.com/videos/d/VIDEO_ID/edit?pli=1&scene=id.p#scene=id.p",
      },
    ]);
    await expect(listOpenProviderTabs()).resolves.toMatchObject({
      tabs: [
        {
          id: 5,
          provider: "Vids",
          projectId: "VIDEO_ID",
          canonicalTarget: "https://docs.google.com/videos/d/VIDEO_ID/edit",
        },
      ],
      unsupportedProviderRoutes: 0,
    });
    query.mockResolvedValueOnce([
      { id: 4, title: "Unrelated", url: "https://example.com/" },
    ]);
    await expect(listOpenProviderTabs()).resolves.toMatchObject({
      tabs: [],
      unsupportedProviderRoutes: 0,
      unavailableUrls: 0,
    });
    query.mockRejectedValueOnce(new Error("query failed"));
    await expect(listOpenProviderTabs()).rejects.toThrow("query failed");
  });

  it("keeps the local preview graceful when Chrome extension APIs are absent", async () => {
    vi.stubGlobal("chrome", undefined);
    expect(createChromeConnectionPort()).toBeUndefined();
    expect(await requestTabListingAccess()).toBe(false);
  });

  it("rejects a connector response for a different project before injecting", async () => {
    const tab = makeTab();
    const { port } = makePort(tab);
    vi.mocked(port.pingTopFrame).mockImplementationOnce(async (_id, request) =>
      makeResponse(tab, request, {
        projectId: "other-project",
        canonicalTarget: "https://labs.google/fx/tools/flow/other-project",
      }),
    );
    const result = await attachToSelectedTab("Flow", tab, port);
    expect(result).toMatchObject({ ok: false, state: "wrong-target" });
    expect(port.injectConnector).not.toHaveBeenCalled();
  });

  it("keeps missing receivers and injection failures visibly failed", async () => {
    const { port, forbiddenTabActions } = makePort();
    vi.mocked(port.injectConnector).mockResolvedValueOnce(undefined);
    const result = await attachToSelectedTab("Flow", makeTab(), port);
    expect(result).toMatchObject({ ok: false, state: "failed" });
    expect(port.pingTopFrame).toHaveBeenCalledOnce();
    expect(port.probeTopFrame).not.toHaveBeenCalled();
    expectProviderUntouched(forbiddenTabActions);
  });

  it("preserves safe stage diagnostics for permission inspection, injection, and handshake failures", async () => {
    const permissionCheck = makePort();
    vi.mocked(permissionCheck.port.getMissingAccess).mockRejectedValueOnce(
      new Error("private URL https://labs.google/fx/tools/flow/private-id"),
    );
    const permissionResult = await attachToSelectedTab(
      "Flow",
      permissionCheck.tab,
      permissionCheck.port,
    );
    expect(permissionResult).toMatchObject({
      ok: false,
      state: "failed",
      stage: "permission_check",
      reasonCode: "permission_inspection_failed",
    });
    if (!permissionResult.ok) {
      expect(permissionResult.error).not.toContain("private-id");
    }

    const injection = makePort();
    vi.mocked(injection.port.injectConnector).mockRejectedValueOnce(
      new Error("Chrome injection error"),
    );
    const injectionResult = await attachToSelectedTab(
      "Flow",
      injection.tab,
      injection.port,
    );
    expect(injectionResult).toMatchObject({
      ok: false,
      state: "failed",
      stage: "connector_injection",
    });

    const handshake = makePort();
    vi.mocked(handshake.port.probeTopFrame).mockRejectedValueOnce(
      new Error("response channel closed"),
    );
    const handshakeResult = await attachToSelectedTab(
      "Flow",
      handshake.tab,
      handshake.port,
    );
    expect(handshakeResult).toMatchObject({
      ok: false,
      state: "failed",
      stage: "handshake",
    });
  });

  it("distinguishes a rejected permissions.contains inspection from missing access", async () => {
    const executeScript = vi.fn();
    const sendMessage = vi.fn();
    vi.stubGlobal("chrome", {
      runtime: { id: "offline-extension" },
      permissions: {
        contains: vi.fn().mockRejectedValue(new Error("browser API rejected")),
        request: vi.fn(),
      },
      tabs: { get: vi.fn(), query: vi.fn(), sendMessage },
      scripting: { executeScript },
    });
    const selected = makeTab();
    const port = createChromeConnectionPort()!;
    await expect(port.getMissingAccess("Flow", selected)).rejects.toMatchObject(
      { name: "PermissionInspectionError" },
    );
    const result = await attachToSelectedTab("Flow", selected, port);
    expect(result).toMatchObject({
      ok: false,
      state: "failed",
      stage: "permission_check",
      reasonCode: "permission_inspection_failed",
    });
    expect(executeScript).not.toHaveBeenCalled();
    expect(sendMessage).not.toHaveBeenCalled();
  });

  it("blocks stale connector builds without reinjection or page replacement", async () => {
    const tab = makeTab();
    const replaced = makePort(tab);
    vi.mocked(replaced.port.pingTopFrame).mockImplementationOnce(
      async (_id, request) =>
        makeResponse(tab, request, {
          buildId: "old-build",
          ok: false,
          projectId: "stale-project",
          canonicalTarget: "https://labs.google/fx/tools/flow/stale-project",
        }),
    );
    const stale = await attachToSelectedTab("Flow", tab, replaced.port);
    expect(stale).toMatchObject({ ok: false, state: "stale-build" });
    expect(replaced.port.injectConnector).not.toHaveBeenCalled();

    const blocked = makePort(tab);
    vi.mocked(blocked.port.pingTopFrame).mockImplementationOnce(
      async (_id, request) =>
        makeResponse(tab, request, { buildId: "old-build", ok: false }),
    );
    vi.mocked(blocked.port.injectConnector).mockResolvedValueOnce(undefined);
    const stillStale = await attachToSelectedTab("Flow", tab, blocked.port);
    expect(stillStale).toMatchObject({ ok: false, state: "stale-build" });
    expect(blocked.port.injectConnector).not.toHaveBeenCalled();
  });

  it("requires response correlation and exact protocol/build/capability identity", async () => {
    const tab = makeTab();
    const { port } = makePort(tab);
    vi.mocked(port.probeTopFrame).mockImplementationOnce(
      async (_id, _documentId, request) =>
        makeResponse(tab, request, { attemptId: "other-attempt" }),
    );
    const result = await attachToSelectedTab("Flow", tab, port);
    expect(result).toMatchObject({ ok: false, state: "wrong-target" });

    const staleProtocol = makePort(tab);
    vi.mocked(staleProtocol.port.pingTopFrame).mockImplementationOnce(
      async (_id, request) =>
        makeResponse(tab, request, { protocolVersion: 999, ok: false }),
    );
    vi.mocked(staleProtocol.port.probeTopFrame).mockImplementationOnce(
      async (_id, _documentId, request) =>
        makeResponse(tab, request, { protocolVersion: 999 }),
    );
    const protocolResult = await attachToSelectedTab(
      "Flow",
      tab,
      staleProtocol.port,
    );
    expect(protocolResult).toMatchObject({ ok: false, state: "stale-build" });
  });

  it("reports safe handshake field checks and accepts compatible extra capabilities", async () => {
    const tab = providerTabFromUrl(
      42,
      "Flow project",
      "https://flow.google.com/u/1/project/project-private-id",
    )!;
    const compatible = makePort(tab);
    vi.mocked(compatible.port.probeTopFrame).mockImplementationOnce(
      async (_id, _documentId, request) =>
        makeResponse(tab, request, {
          capabilities: [
            CONNECTION_CAPABILITY,
            "flow-image-entry-v1",
            "flow-image-generate-once-v1",
          ],
        }),
    );
    const accepted = await attachToSelectedTab("Flow", tab, compatible.port);
    expect(accepted).toMatchObject({
      ok: true,
      capabilities: [CONNECTION_CAPABILITY],
    });

    const mismatch = makePort(tab);
    vi.mocked(mismatch.port.probeTopFrame).mockImplementationOnce(
      async (_id, _documentId, request) =>
        makeResponse(tab, request, {
          ok: false,
          provider: undefined,
          canonicalTarget: undefined,
          projectId: undefined,
        }),
    );
    const rejected = await attachToSelectedTab("Flow", tab, mismatch.port);
    expect(rejected).toMatchObject({
      ok: false,
      stage: "handshake_validation",
      handshakeDiagnostics: {
        selectedProvider: "match",
        selectedOrigin: "match",
        selectedProjectId: "match",
        selectedCanonicalTarget: "match",
        browserDocumentId: "bound",
        topFrame: "match",
        responseProvider: "missing",
        responseOrigin: "missing",
        responseProjectId: "missing",
        responseCanonicalTarget: "missing",
        attemptCorrelation: "match",
        protocolVersion: "match",
        buildIdentity: "match",
        readOnlyCapability: "match",
        connectorAcceptance: "rejected",
        documentToken: "present",
      },
    });
    if (!rejected.ok) {
      const detail = formatHandshakeDiagnostics(rejected.handshakeDiagnostics!);
      expect(detail).toContain("response-target=missing");
      expect(detail).not.toContain("project-private-id");
      expect(detail).not.toContain("https://");
      expect(detail).not.toContain("document-token-1");
    }

    const missingCapability = makePort(tab);
    vi.mocked(missingCapability.port.probeTopFrame).mockImplementationOnce(
      async (_id, _documentId, request) =>
        makeResponse(tab, request, { capabilities: ["flow-image-entry-v1"] }),
    );
    const blocked = await attachToSelectedTab(
      "Flow",
      tab,
      missingCapability.port,
    );
    expect(blocked).toMatchObject({
      ok: false,
      stage: "handshake_validation",
      handshakeDiagnostics: { readOnlyCapability: "mismatch" },
    });

    const malformedCapability = makePort(tab);
    vi.mocked(malformedCapability.port.probeTopFrame).mockImplementationOnce(
      async (_id, _documentId, request) =>
        makeResponse(tab, request, {
          capabilities:
            `${CONNECTION_CAPABILITY}:flow-image-generate-once-v1` as unknown as readonly string[],
        }),
    );
    const malformedBlocked = await attachToSelectedTab(
      "Flow",
      tab,
      malformedCapability.port,
    );
    expect(malformedBlocked).toMatchObject({
      ok: false,
      stage: "handshake_validation",
      handshakeDiagnostics: { readOnlyCapability: "mismatch" },
    });

    const changedDocument = makePort(tab);
    vi.mocked(changedDocument.port.pingTopFrame).mockImplementationOnce(
      async (_id, request) => makeResponse(tab, request),
    );
    vi.mocked(changedDocument.port.probeTopFrame).mockImplementationOnce(
      async (_id, _documentId, request) =>
        makeResponse(tab, request, { documentToken: "different-token" }),
    );
    const changed = await attachToSelectedTab(
      "Flow",
      tab,
      changedDocument.port,
    );
    expect(changed).toMatchObject({
      ok: false,
      state: "wrong-target",
      handshakeDiagnostics: { documentTokenContinuity: "mismatch" },
    });
  });

  it("coalesces repeated Connect clicks so only one attachment runs", async () => {
    const { port } = makePort();
    let grant!: (access: Record<string, never>) => void;
    vi.mocked(port.getMissingAccess).mockImplementationOnce(
      () => new Promise((resolve) => (grant = resolve)),
    );
    const selected = makeTab();
    const first = attachToSelectedTab("Flow", selected, port);
    const second = attachToSelectedTab("Flow", selected, port);
    expect(second).toBe(first);
    expect(port.getMissingAccess).toHaveBeenCalledOnce();
    grant({});
    expect(await first).toMatchObject({ ok: true, state: "connected" });
    expect(port.injectConnector).toHaveBeenCalledOnce();
  });

  it("leaves disconnected or closed targets unconnected", async () => {
    const { port } = makePort();
    vi.mocked(port.getTab).mockResolvedValueOnce(undefined);
    const result = await attachToSelectedTab("Flow", makeTab(), port);
    expect(result).toMatchObject({ ok: false, state: "wrong-target" });
  });

  it("recognizes a genuine worker start event once and rejects invalid or stale versions", () => {
    const event = readWorkerStartEvent({
      type: FOUNDATION_WORKER_RESTARTED,
      buildId: BUILD_ID,
      workerInstanceId: "worker-instance-1",
      protocolVersion: PROTOCOL_VERSION,
    });
    expect(event).toEqual({
      buildId: BUILD_ID,
      workerInstanceId: "worker-instance-1",
      protocolVersion: PROTOCOL_VERSION,
    });
    expect(isCurrentWorkerStart(event!)).toBe(true);
    expect(
      isCurrentWorkerStart({ ...event!, buildId: "different-build" }),
    ).toBe(false);
    expect(
      readWorkerStartEvent({
        type: FOUNDATION_WORKER_RESTARTED,
        buildId: BUILD_ID,
        workerInstanceId: "worker-instance-1",
        protocolVersion: PROTOCOL_VERSION - 1,
      }),
    ).toMatchObject({ protocolVersion: PROTOCOL_VERSION - 1 });
    expect(readWorkerStartEvent({ type: "unrelated-event" })).toBeUndefined();
    expect(
      readWorkerStartEvent({
        type: FOUNDATION_WORKER_RESTARTED,
        buildId: BUILD_ID,
        protocolVersion: PROTOCOL_VERSION,
      }),
    ).toBeUndefined();
  });

  it("schedules verification after a worker start without disconnecting manual choices", () => {
    expect(workerStartAction(true, true)).toBe("verify");
    expect(workerStartAction(true, false)).toBe("preserve_disconnected");
    expect(workerStartAction(false, true)).toBe("no_target");
    expect(isCurrentConnectionAttempt(7, 7, true)).toBe(true);
    expect(isCurrentConnectionAttempt(8, 7, true)).toBe(false);
    expect(isCurrentConnectionAttempt(7, 7, false)).toBe(false);
  });

  it("invalidates a live target when its route or browser document changes", () => {
    const selected = providerTabFromUrl(
      42,
      "Flow project",
      "https://flow.google.com/u/1/project/project-1",
    )!;

    expect(
      providerDocumentNeedsReverification(selected, {
        url: "https://flow.google.com/u/2/project/project-1",
      }),
    ).toBe(true);
    expect(
      providerDocumentNeedsReverification(selected, {
        url: "https://flow.google.com/u/1/project/project-2",
      }),
    ).toBe(true);
    expect(
      providerDocumentNeedsReverification(selected, { status: "loading" }),
    ).toBe(true);
    expect(
      providerDocumentNeedsReverification(selected, {
        url: "https://flow.google.com/u/1/project/project-1?panel=assets",
      }),
    ).toBe(false);
  });

  it("re-verifies only the persisted tab and blocks a changed or closed target", async () => {
    const { port, tab, forbiddenTabActions } = makePort();
    const result = await verifyPersistedTarget(
      "Flow",
      { tabId: tab.id, canonicalTarget: tab.canonicalTarget },
      port,
    );
    expect(result).toMatchObject({ ok: true, state: "connected" });
    expect(port.getTab).toHaveBeenCalledWith(tab.id);
    expect(port.injectConnector).toHaveBeenCalledOnce();
    expectProviderUntouched(forbiddenTabActions);

    const changed = makePort();
    vi.mocked(changed.port.getTab).mockResolvedValueOnce(
      makeTab(42, "Flow", "different-project"),
    );
    const blocked = await verifyPersistedTarget(
      "Flow",
      { tabId: tab.id, canonicalTarget: tab.canonicalTarget },
      changed.port,
    );
    expect(blocked).toMatchObject({ ok: false, state: "wrong-target" });
    expect(changed.port.injectConnector).not.toHaveBeenCalled();

    const accountTarget = providerTabFromUrl(
      42,
      "Flow account route",
      "https://flow.google.com/u/1/project/same-project",
    )!;
    const accountChanged = makePort(accountTarget);
    vi.mocked(accountChanged.port.getTab).mockResolvedValueOnce(
      providerTabFromUrl(
        42,
        "Flow account route changed",
        "https://flow.google.com/u/2/project/same-project",
      ),
    );
    const accountBlocked = await verifyPersistedTarget(
      "Flow",
      {
        tabId: accountTarget.id,
        canonicalTarget: accountTarget.canonicalTarget,
      },
      accountChanged.port,
    );
    expect(accountBlocked).toMatchObject({
      ok: false,
      state: "wrong-target",
    });
    expect(accountChanged.port.injectConnector).not.toHaveBeenCalled();

    const closed = makePort();
    vi.mocked(closed.port.getTab).mockResolvedValueOnce(undefined);
    const closedResult = await verifyPersistedTarget(
      "Flow",
      { tabId: tab.id, canonicalTarget: tab.canonicalTarget },
      closed.port,
    );
    expect(closedResult).toMatchObject({ ok: false, state: "wrong-target" });
    expect(closed.port.injectConnector).not.toHaveBeenCalled();
  });

  it("keeps all provider page mutation and navigation methods unused", async () => {
    for (const failureState of ["success", "denied", "missing"] as const) {
      const { port, forbiddenTabActions } = makePort();
      if (failureState === "denied") {
        vi.mocked(port.getMissingAccess).mockResolvedValueOnce({
          permissions: ["scripting"],
        });
      }
      if (failureState === "missing") {
        vi.mocked(port.injectConnector).mockResolvedValueOnce(undefined);
      }
      await attachToSelectedTab("Flow", makeTab(), port);
      expectProviderUntouched(forbiddenTabActions);
    }
  });
});

describe("packaged connector listener lifecycle", () => {
  it("validates the current Flow host and exact project ID in its read-only handshake", async () => {
    const listeners = new Set<(...args: unknown[]) => unknown>();
    const runtime = {
      id: "offline-extension",
      onMessage: {
        addListener: vi.fn((listener: (...args: unknown[]) => unknown) =>
          listeners.add(listener),
        ),
        removeListener: vi.fn((listener: (...args: unknown[]) => unknown) =>
          listeners.delete(listener),
        ),
      },
    };
    vi.stubGlobal("chrome", { runtime });
    vi.stubGlobal("document", {});
    const frame = { top: undefined as unknown };
    frame.top = frame;
    vi.stubGlobal("window", frame);
    vi.stubGlobal("location", {
      href: "https://flow.google.com/project/selected_9?panel=assets",
    });

    await import("../../src/platforms/shared/connectionProbe");

    const [listener] = [...listeners];
    const respond = vi.fn();
    const request = {
      type: "AUTOMAT_FACELESS_CONNECTION_PROBE",
      provider: "Flow",
      canonicalTarget: "https://flow.google.com/project/selected_9",
      projectId: "selected_9",
      protocolVersion: CONNECTOR_PROTOCOL_VERSION,
      buildId: BUILD_ID,
      attemptId: "attempt-current-flow",
    };
    listener!(request, { id: runtime.id }, respond);
    expect(respond).toHaveBeenCalledWith(
      expect.objectContaining({
        ok: true,
        provider: "Flow",
        projectId: "selected_9",
        canonicalTarget: "https://flow.google.com/project/selected_9",
        attemptId: "attempt-current-flow",
        capabilities: [CONNECTION_CAPABILITY],
      }),
    );

    const wrongProjectResponse = vi.fn();
    listener!(
      { ...request, projectId: "other-project" },
      { id: runtime.id },
      wrongProjectResponse,
    );
    expect(wrongProjectResponse).toHaveBeenCalledWith(
      expect.objectContaining({
        ok: false,
        projectId: "selected_9",
        error: "The current document does not match the selected project.",
      }),
    );
  });

  it.each([
    [
      "unprefixed",
      "https://flow.google.com/project/selected_9?panel=assets",
      "https://flow.google.com/project/selected_9",
    ],
    [
      "manual account index 1",
      "https://flow.google.com/u/1/project/selected_9?panel=assets",
      "https://flow.google.com/u/1/project/selected_9",
    ],
    [
      "manual account index 7",
      "https://flow.google.com/u/7/project/selected_9?panel=assets",
      "https://flow.google.com/u/7/project/selected_9",
    ],
  ])(
    "uses the shared route contract for Flow %s",
    async (_label, url, canonicalTarget) => {
      const listeners = new Set<(...args: unknown[]) => unknown>();
      const runtime = {
        id: "offline-extension",
        onMessage: {
          addListener: vi.fn((listener: (...args: unknown[]) => unknown) =>
            listeners.add(listener),
          ),
          removeListener: vi.fn((listener: (...args: unknown[]) => unknown) =>
            listeners.delete(listener),
          ),
        },
      };
      vi.stubGlobal("chrome", { runtime });
      vi.stubGlobal("document", {});
      const frame = { top: undefined as unknown };
      frame.top = frame;
      vi.stubGlobal("window", frame);
      vi.stubGlobal("location", { href: url });

      await import("../../src/platforms/shared/connectionProbe");

      const [listener] = [...listeners];
      const respond = vi.fn();
      listener!(
        {
          type: "AUTOMAT_FACELESS_CONNECTION_PROBE",
          provider: "Flow",
          canonicalTarget,
          projectId: "selected_9",
          protocolVersion: CONNECTOR_PROTOCOL_VERSION,
          buildId: BUILD_ID,
          attemptId: "attempt-account-route",
        },
        { id: runtime.id },
        respond,
      );
      expect(respond).toHaveBeenCalledWith(
        expect.objectContaining({
          ok: true,
          provider: "Flow",
          projectId: "selected_9",
          canonicalTarget,
          attemptId: "attempt-account-route",
          capabilities: [CONNECTION_CAPABILITY],
        }),
      );
      expect(location.href).toBe(url);
    },
  );

  it("validates the current Vids document ID while ignoring scene query and fragment", async () => {
    const listeners = new Set<(...args: unknown[]) => unknown>();
    const runtime = {
      id: "offline-extension",
      onMessage: {
        addListener: vi.fn((listener: (...args: unknown[]) => unknown) =>
          listeners.add(listener),
        ),
        removeListener: vi.fn((listener: (...args: unknown[]) => unknown) =>
          listeners.delete(listener),
        ),
      },
    };
    const actualVidsUrl =
      "https://docs.google.com/videos/d/VIDEO_ID/edit?pli=1&scene=id.p#scene=id.p";
    vi.stubGlobal("chrome", { runtime });
    vi.stubGlobal("document", {});
    const frame = { top: undefined as unknown };
    frame.top = frame;
    vi.stubGlobal("window", frame);
    vi.stubGlobal("location", { href: actualVidsUrl });

    await import("../../src/platforms/shared/connectionProbe");

    const [listener] = [...listeners];
    const respond = vi.fn();
    listener!(
      {
        type: "AUTOMAT_FACELESS_CONNECTION_PROBE",
        provider: "Vids",
        canonicalTarget: "https://docs.google.com/videos/d/VIDEO_ID/edit",
        projectId: "VIDEO_ID",
        protocolVersion: CONNECTOR_PROTOCOL_VERSION,
        buildId: BUILD_ID,
        attemptId: "attempt-actual-vids",
      },
      { id: runtime.id },
      respond,
    );
    expect(respond).toHaveBeenCalledWith(
      expect.objectContaining({
        ok: true,
        provider: "Vids",
        projectId: "VIDEO_ID",
        canonicalTarget: "https://docs.google.com/videos/d/VIDEO_ID/edit",
        attemptId: "attempt-actual-vids",
        capabilities: [CONNECTION_CAPABILITY],
      }),
    );
    expect(location.href).toBe(actualVidsUrl);
  });

  it("removes a known prior listener before installing one replacement", async () => {
    const listeners = new Set<(...args: unknown[]) => unknown>();
    const runtime = {
      id: "offline-extension",
      onMessage: {
        addListener: vi.fn((listener: (...args: unknown[]) => unknown) =>
          listeners.add(listener),
        ),
        removeListener: vi.fn((listener: (...args: unknown[]) => unknown) =>
          listeners.delete(listener),
        ),
      },
    };
    const oldListener = vi.fn();
    (
      globalThis as typeof globalThis & { __automatFacelessConnector?: unknown }
    ).__automatFacelessConnector = {
      buildId: "old-build",
      listener: oldListener,
      documentToken: "old-document",
    };
    vi.stubGlobal("chrome", { runtime });
    vi.stubGlobal("document", {});
    const frame = { top: undefined as unknown };
    frame.top = frame;
    vi.stubGlobal("window", frame);
    vi.stubGlobal("location", {
      href: "https://labs.google/fx/tools/flow/project-1",
    });

    await import("../../src/platforms/shared/connectionProbe");

    const firstInstalled = [...listeners][0];
    vi.resetModules();
    await import("../../src/platforms/shared/connectionProbe");

    expect(runtime.onMessage.removeListener).toHaveBeenLastCalledWith(
      firstInstalled,
    );
    expect(runtime.onMessage.removeListener).toHaveBeenCalledTimes(2);
    expect(runtime.onMessage.addListener).toHaveBeenCalledTimes(2);
    expect(listeners).toHaveLength(1);
  });

  it("does not duplicate a legacy listener whose reference cannot be removed safely", async () => {
    const runtime = {
      id: "offline-extension",
      onMessage: {
        addListener: vi.fn(),
        removeListener: vi.fn(),
      },
    };
    vi.stubGlobal("chrome", { runtime });
    vi.stubGlobal("document", {});
    const frame = { top: undefined as unknown };
    frame.top = frame;
    vi.stubGlobal("window", frame);
    vi.stubGlobal("location", {
      href: "https://vids.google.com/video/vid-1/edit",
    });
    (
      globalThis as typeof globalThis & {
        __automatFacelessConnectionProbeInstalled?: boolean;
      }
    ).__automatFacelessConnectionProbeInstalled = true;

    await import("../../src/platforms/shared/connectionProbe");

    expect(runtime.onMessage.addListener).not.toHaveBeenCalled();
    expect(runtime.onMessage.removeListener).not.toHaveBeenCalled();
  });

  it("preserves known Flow connection, document and menu failures with bounded stage details", () => {
    for (const [code, failureStage, responseStage] of [
      ["flow_target_not_currently_verified", "validation", "validation_input_not_attempted"],
      ["flow_target_document_changed", "validation", "validation_input_not_attempted"],
      ["flow_clip_document_changed", "final_preparation", "final_preparation_input_not_attempted"],
      ["flow_detail_download_menu_not_ready", "initial_preparation", "initial_preparation_input_not_attempted"],
    ] as const) {
      const mapped = flowClipDownloadStartFailure(
        new FlowClipDownloadStartError(code, failureStage, false),
      );
      expect(mapped.code).toBe(code);
      expect(mapped.stage).toBe(responseStage);
      expect(mapped.message).not.toContain("delivery is uncertain");
    }
    const uncertain = flowClipDownloadStartFailure(
      new FlowClipDownloadStartError(
        "flow_download_dispatch_uncertain",
        "native_input",
        true,
      ),
    );
    expect(uncertain).toMatchObject({
      code: "flow_download_dispatch_uncertain",
      stage: "native_input_input_attempted",
    });
    const sanitized = flowClipDownloadStartFailure(
      new Error("Chrome included https://private.invalid/?token=secret"),
    );
    expect(sanitized).toMatchObject({
      code: "flow_clip_download_preparation_failed",
      message: expect.not.stringContaining("secret"),
    });
  });
});
