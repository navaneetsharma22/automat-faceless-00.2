import type { RepositoryDatabase } from "../../src/storage/repositories";
import type {
  BatchRecord,
  PromptDraftRecord,
  PromptItemRecord,
  SelectedTargetRecord,
  WorkflowRecord,
} from "../../src/storage/db";
import type { FlowImageAttemptRecord } from "../../src/domain/jobs/attempt";
import type { FlowImagePromptSnapshotRecord } from "../../src/domain/batches/flowImagePromptSnapshot";
import type { FlowCountRecoveryRecord } from "../../src/storage/db";
import type { FlowVideoAttachmentOperation } from "../../src/storage/db";
import type { ImageSubmissionQueueRecord } from "../../src/domain/jobs/queue";
import type {
  ReferenceAssignmentRecord,
  ReferenceCaptureOperationRecord,
} from "../../src/domain/media/references";
import type { PreparedVideoBatchRecord } from "../../src/domain/batches/types";
import type { FlowVideoQueueRecord } from "../../src/domain/jobs/videoQueue";
import type { VidsVideoAttachmentOperation } from "../../src/domain/jobs/vidsVideoAttachment";
import type { VidsVideoGenerationOperation } from "../../src/domain/jobs/vidsVideoGeneration";
import type { VidsVideoQueueRecord } from "../../src/domain/jobs/vidsVideoQueue";
import type { FlowClipImportRecord } from "../../src/domain/media/flowClipImport";

export function createMemoryRepositoryDatabase(): RepositoryDatabase {
  const drafts = new Map<string, PromptDraftRecord>();
  const targets = new Map<string, SelectedTargetRecord>();
  const workflows = new Map<string, WorkflowRecord>();
  const batches = new Map<string, BatchRecord>();
  const promptItems = new Map<string, PromptItemRecord>();
  const flowImageAttempts = new Map<string, FlowImageAttemptRecord>();
  const flowImagePromptSnapshots = new Map<
    string,
    FlowImagePromptSnapshotRecord
  >();
  const flowCountRecoveries = new Map<string, FlowCountRecoveryRecord>();
  const imageSubmissionQueues = new Map<string, ImageSubmissionQueueRecord>();
  const referenceAssignments = new Map<string, ReferenceAssignmentRecord>();
  const referenceCaptureOperations = new Map<
    string,
    ReferenceCaptureOperationRecord
  >();
  const preparedVideoBatches = new Map<string, PreparedVideoBatchRecord>();
  const pinnedReferenceMedia = new Map<string, ReferenceAssignmentRecord>();
  const flowVideoAttachmentOperations = new Map<string, FlowVideoAttachmentOperation>();
  const flowVideoQueues = new Map<string, FlowVideoQueueRecord>();
  const vidsVideoAttachmentOperations = new Map<string, VidsVideoAttachmentOperation>();
  const vidsVideoGenerationOperations = new Map<string, VidsVideoGenerationOperation>();
  const vidsVideoQueues = new Map<string, VidsVideoQueueRecord>();
  const flowClipImports = new Map<string, FlowClipImportRecord>();
  let transactionTail = Promise.resolve();

  const table = <T extends object>(
    values: Map<string, T>,
    key: (item: T) => string,
  ) => ({
    put: async (item: T) => {
      values.set(key(item), item);
      return key(item);
    },
    get: async (id: string) => values.get(id),
    toArray: async () => [...values.values()],
    bulkPut: async (items: T[]) => {
      for (const item of items) values.set(key(item), item);
      return items.length;
    },
    bulkDelete: async (keys: string[]) => {
      for (const value of keys) values.delete(value);
    },
    add: async (item: T) => {
      const id = key(item);
      if (values.has(id))
        throw new DOMException("Duplicate key", "ConstraintError");
      if (
        "activeKey" in item &&
        item.activeKey !== undefined &&
        [...values.values()].some(
          (existing) =>
            "activeKey" in existing && existing.activeKey === item.activeKey,
        )
      ) {
        throw new DOMException("Duplicate active key", "ConstraintError");
      }
      if (
        "confirmationKey" in item &&
        [...values.values()].some(
          (existing) =>
            "confirmationKey" in existing &&
            existing.confirmationKey === item.confirmationKey,
        )
      ) {
        throw new DOMException("Duplicate confirmation key", "ConstraintError");
      }
      values.set(id, item);
      return id;
    },
  });

  return {
    promptDrafts: table(drafts, (item) => item.id!),
    selectedTargets: table(targets, (item) => item.provider!),
    workflows: table(workflows, (item) => item.id!),
    batches: table(batches, (item) => item.id!),
    promptItems: table(promptItems, (item) => item.id!),
    flowImageAttempts: table(flowImageAttempts, (item) => item.attemptId),
    flowImagePromptSnapshots: table(
      flowImagePromptSnapshots,
      (item) => item.snapshotId,
    ),
    flowCountRecoveries: table(flowCountRecoveries, (item) => item.recoveryId),
    imageSubmissionQueues: table(imageSubmissionQueues, (item) => item.queueId),
    referenceAssignments: table(
      referenceAssignments,
      (item) => item.assignmentId,
    ),
    referenceCaptureOperations: table(
      referenceCaptureOperations,
      (item) => item.captureOperationId,
    ),
    preparedVideoBatches: table(
      preparedVideoBatches,
      (item) => item.id,
    ),
    pinnedReferenceMedia: table(
      pinnedReferenceMedia,
      (item) => item.referenceId,
    ),
    flowVideoAttachmentOperations: table(flowVideoAttachmentOperations, (item) => item.id),
    flowVideoQueues: table(flowVideoQueues, (item) => item.queueId),
    vidsVideoAttachmentOperations: table(vidsVideoAttachmentOperations, (item) => item.id),
    vidsVideoGenerationOperations: table(vidsVideoGenerationOperations, (item) => item.id),
    vidsVideoQueues: table(vidsVideoQueues, (item) => item.queueId),
    flowClipImports: table(flowClipImports, (item) => item.id),
    transaction: async (_tableNames, operation) => {
      let release!: () => void;
      const previous = transactionTail;
      transactionTail = new Promise<void>((resolve) => {
        release = resolve;
      });
      await previous;
      const snapshots = [
        drafts,
        targets,
        workflows,
        batches,
        promptItems,
        flowImageAttempts,
        flowImagePromptSnapshots,
        flowCountRecoveries,
        imageSubmissionQueues,
        referenceAssignments,
        referenceCaptureOperations,
        preparedVideoBatches,
        pinnedReferenceMedia,
        flowVideoAttachmentOperations,
        flowVideoQueues,
        vidsVideoAttachmentOperations,
        vidsVideoGenerationOperations,
        vidsVideoQueues,
        flowClipImports,
      ].map((values) => new Map(values));
      try {
        return await operation();
      } catch (error) {
        [
          drafts,
          targets,
          workflows,
          batches,
          promptItems,
          flowImageAttempts,
          flowImagePromptSnapshots,
          flowCountRecoveries,
          imageSubmissionQueues,
          referenceAssignments,
          referenceCaptureOperations,
          preparedVideoBatches,
          pinnedReferenceMedia,
          flowVideoAttachmentOperations,
          flowVideoQueues,
          vidsVideoAttachmentOperations,
          vidsVideoGenerationOperations,
          vidsVideoQueues,
          flowClipImports,
        ].forEach((values, index) => {
          values.clear();
          for (const [key, value] of snapshots[index]!) {
            values.set(key, value);
          }
        });
        throw error;
      } finally {
        release();
      }
    },
  };
}
