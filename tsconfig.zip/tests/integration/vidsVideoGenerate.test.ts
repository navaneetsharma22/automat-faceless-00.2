import { describe, expect, it, vi } from "vitest";
import { BUILD_ID, PROTOCOL_VERSION } from "../../src/shared/buildInfo";
import { CONNECTOR_PROTOCOL_VERSION } from "../../src/platforms/shared/contracts";
import { createVidsVideoGenerateHandler } from "../../src/background/handlers/vidsVideo";
import { enterVidsPromptInPage, activateVidsGenerateInPage } from "../../src/platforms/vids/video";
import { sha256Hex } from "../../src/domain/batches/hashPrompt";
import { sha256Bytes } from "../../src/domain/media/references";
import { createMemoryRepositoryDatabase } from "../unit/repositoryTestSupport";
import { ExtensionRepositories } from "../../src/storage/repositories";
import { createConnectionMessageListener } from "../../src/background/handlers/connections";
import { makeRequest } from "../../src/shared/messages";
import { ChromePreferenceRepository } from "../../src/storage/repositories";
import type { VidsVideoQueueRecord } from "../../src/domain/jobs/vidsVideoQueue";

const preparedBatchId = "prepared:vids-workspace:volcano";
const itemId = "video-item-1";
const referenceId = "11111111-1111-4111-8111-111111111111";
const documentId = "vids-doc-1";
const canonicalTarget = `https://docs.google.com/videos/d/${documentId}/edit`;
const prompt = JSON.stringify({ shot_id: "1", prompt_type: "video", direction: "A volcano plume rises slowly over a distant ridge", detail: ["first line", "second line\nwith explicit newline"] }, null, 2);
const png = Uint8Array.from(atob("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4z8DwHwAFgAI/ScL4WQAAAABJRU5ErkJggg=="), (value) => value.charCodeAt(0));

async function setup(options: {
  entryReason?: string;
  generateDisabled?: boolean;
  generateCount?: number;
  changeTargetBeforeIntent?: boolean;
  activationThrows?: boolean;
  activationResult?: { ok: boolean; reason?: string; activationAttempted: boolean; activationCount: 0 | 1 };
  injectedDocumentId?: string;
  wrongPromptHash?: boolean;
  referenceMismatch?: boolean;
  changePromptBeforeIntent?: boolean;
} = {}) {
  const database = createMemoryRepositoryDatabase();
  const repositories = new ExtensionRepositories(database, () => 1000);
  const referenceSha256 = await sha256Bytes(png);
  const promptHash = await sha256Hex(prompt);
  const sourceHash = await sha256Hex(prompt);
  const reference = {
    assignmentId: "workspace:image:1", referenceId, captureOperationId: "22222222-2222-4222-8222-222222222222",
    workspaceId: "workspace", batchId: "image-batch", batchSourceHash: "a".repeat(64), shotId: "1", promptHash: "b".repeat(64),
    selectionVersion: "33333333-3333-4333-8333-333333333333", assignmentVersion: 1, flowProjectId: "flow-project",
    tabId: 44, canonicalTarget: "https://flow.google.com/project/flow-project", documentId: "flow-document",
    observedSourceSha256: "c".repeat(64), providerAssetId: "asset-1", bytes: new Blob([png as BlobPart], { type: "image/png" }),
    mimeType: "image/png" as const, byteSize: png.length, sha256: referenceSha256, width: 1, height: 1, capturedAt: 1,
    acquisitionProvenance: "verified_flow_document_same_origin_fetch" as const, qualityProvenance: "observed_resource_original_bytes_no_upscale" as const,
  };
  const prepared = {
    id: preparedBatchId, requestId: "44444444-4444-4444-8444-444444444444", workspaceId: "workspace", preparedAt: 1,
    videoBatchId: "video-batch", videoSourceHash: sourceHash, videoSourceText: prompt, imageSourceBatchId: "image-batch", imageSourceBatchHash: "a".repeat(64),
    destination: "Vids" as const,
    target: { provider: "Vids" as const, tabId: 90, canonicalTarget, projectId: documentId, documentId, verification: "verified" as const, verifiedAt: 1 },
    manualSettingsDeclaration: { confirmationId: "confirmed-once", confirmedAt: 1, destination: "Vids" as const, declaredDurationSeconds: 8, tabId: 90, canonicalTarget, projectId: documentId, documentId },
    status: "prepared" as const, itemCount: 1,
    items: [{ itemId, order: 0, shotId: "1", canonicalShotId: "1", rawJsonBody: prompt, contentHash: options.wrongPromptHash ? "e".repeat(64) : promptHash,
      sourceSpan: { start: 0, end: prompt.length }, reference: { referenceId, assignmentVersion: 1, sha256: referenceSha256, mimeType: "image/png", byteSize: png.length, width: 1, height: 1, capturedAt: 1 } }],
    createdAt: 1, updatedAt: 1,
  };
  const target = {
    provider: "Vids" as const, tabId: 90, canonicalTarget, verification: "verified" as const, connectionState: "verified" as const, updatedAt: 1,
    verificationBinding: { provider: "Vids" as const, tabId: 90, canonicalTarget, projectId: documentId, frameId: 0 as const, documentId, documentToken: "token", extensionBuildId: BUILD_ID, extensionProtocolVersion: PROTOCOL_VERSION, connectorBuildId: BUILD_ID, connectorProtocolVersion: CONNECTOR_PROTOCOL_VERSION, capability: "read-only-connection-v1" as const, verifiedAt: 1 },
  };
  const attachmentId = `vids:${await sha256Hex(`${preparedBatchId}\u0000${itemId}`)}`;
  const attachment = {
    id: attachmentId, preparedBatchId, workspaceId: "workspace", itemId, shotId: "1", referenceId,
    assignmentVersion: 1, referenceSha256, mimeType: "image/png" as const, byteSize: png.length, width: 1, height: 1,
    tabId: 90, canonicalTarget, documentId, status: "attached" as const, createdAt: 2, updatedAt: 3,
    uploadEvidence: { mechanism: "verified_document_file_input" as const, exactBytesSha256: referenceSha256, byteSize: png.length,
      mimeType: "image/png" as const, fileInputCount: 1 as const, inputChangeDispatched: true as const, previewLoaded: true as const,
      previewWidth: 1, previewHeight: 1, removalControlPresent: true as const, uploadOperationId: "55555555-5555-4555-8555-555555555555", uploadedAt: 3 },
  };
  await database.referenceAssignments.put(reference);
  await database.preparedVideoBatches.put(prepared);
  await database.selectedTargets.put(target);
  await database.vidsVideoAttachmentOperations.put(attachment);
  const calls: Array<{ func: (...args: never[]) => unknown; args?: unknown[]; target: { tabId: number; documentIds: string[] } }> = [];
  let attemptNumber = 0;
  const scripting = { executeScript: vi.fn(async (input: { func: (...args: never[]) => unknown; args?: unknown[]; target: { tabId: number; documentIds: string[] } }) => {
    calls.push(input);
    if (input.func === enterVidsPromptInPage) {
      if (options.changeTargetBeforeIntent && calls.length === 2) await database.selectedTargets.put({ ...target, verificationBinding: { ...target.verificationBinding, documentId: "replaced-doc" } });
      const entryCount = calls.filter((call) => call.func === enterVidsPromptInPage).length;
      return [{ documentId: options.injectedDocumentId ?? documentId, result: {
        href: canonicalTarget, ok: !options.entryReason, ...(options.entryReason ? { reason: options.entryReason } : {}),
        promptState: "empty", expectedSha256: promptHash, actualSha256: options.changePromptBeforeIntent && entryCount === 2 ? "f".repeat(64) : promptHash, immediateMatch: !(options.changePromptBeforeIntent && entryCount === 2), settledMatch: !(options.changePromptBeforeIntent && entryCount === 2), stableReads: 3,
        referenceSha256: options.referenceMismatch ? "d".repeat(64) : referenceSha256, referenceProofSource: "selected_file_sha256", referenceByteSize: png.length, generateCount: options.generateCount ?? 1, generateDisabled: options.generateDisabled ?? false,
      } }];
    }
    const activationCall = calls.filter((call) => call.func === activateVidsGenerateInPage).length;
    if (options.activationThrows) throw new Error("lost_injected_reply");
    const result = options.activationResult && activationCall === 1
      ? options.activationResult
      : { ok: true, activationAttempted: true, activationCount: 1, referenceProofSource: "selected_file_sha256" };
    return [{ documentId, result: { href: canonicalTarget, ...result } }];
  }) };
  const handler = createVidsVideoGenerateHandler({
    repositories, scripting, getTab: async (tabId) => ({ id: tabId, url: canonicalTarget }), revalidate: async () => undefined,
    now: () => 5000, createAttemptId: () => attemptNumber++ === 0 ? "66666666-6666-4666-8666-666666666666" : "77777777-7777-4777-8777-777777777777",
    queueCanContinue: async (batchId, activeItemId, activePromptHash, activeReferenceId, activeReferenceSha256) => {
      const queue = await repositories.getVidsVideoQueue(`vids-video:${batchId}`);
      const active = queue?.items.find((value) => value.itemId === activeItemId);
      return queue?.preparedBatchId === batchId && queue.state === "checking_generate" && active?.state === "sending" && active.promptHash === activePromptHash && active.referenceId === activeReferenceId && active.referenceSha256 === activeReferenceSha256;
    },
  });
  return { database, repositories, prepared, handler, calls, scripting, promptHash, referenceSha256, target, attachment };
}

describe("P10.2 Google Vids exact prompt and one-shot generation", () => {
  it("validates the exact prepared pair, checks target/reference, records intent, then dispatches once", async () => {
    const fixture = await setup();
    const result = await fixture.handler.generateOnce(preparedBatchId, itemId);
    expect(result.status, JSON.stringify(result)).toBe("dispatched");
    expect(fixture.calls).toHaveLength(3); // two full prompt/reference preflights, one activation
    expect(fixture.calls.map((call) => call.target.documentIds)).toEqual([[documentId], [documentId], [documentId]]);
    const operation = await fixture.repositories.getVidsVideoGenerationOperation((result.operation as { id: string }).id);
    expect(operation).toMatchObject({ status: "dispatched", promptHash: fixture.promptHash, referenceSha256: fixture.referenceSha256, preIntentReferenceProofSource: "selected_file_sha256", activationReferenceProofSource: "selected_file_sha256", documentId, canonicalShotId: "1", activationAttempted: true, activationCount: 1, promptReadback: { expectedSha256: fixture.promptHash, actualSha256: fixture.promptHash, serialization: "contenteditable_blocks_v1", immediateMatch: true, settledMatch: true, stableReads: 3 } });
    expect(await fixture.database.flowVideoAttachmentOperations.toArray()).toEqual([]);
    expect(await fixture.database.flowVideoQueues.toArray()).toEqual([]);
    expect(await fixture.database.vidsVideoAttachmentOperations.toArray()).toHaveLength(1);
    expect(await fixture.database.vidsVideoGenerationOperations.toArray()).toHaveLength(1);
  });

  it("requires the persisted queue to own this exact sending Shot before intent or Generate", async () => {
    const fixture = await setup();
    const paused = await fixture.handler.generateOnce(preparedBatchId, itemId, true);
    expect(paused).toMatchObject({ status: "blocked", stage: "queue_ownership", reason: "vids_queue_paused_before_generation_intent" });
    expect(fixture.calls).toHaveLength(0);
    expect(await fixture.database.vidsVideoGenerationOperations.toArray()).toEqual([]);
    const item = fixture.prepared.items[0]!;
    const queue: VidsVideoQueueRecord = { queueId: `vids-video:${preparedBatchId}`, preparedBatchId, state: "checking_generate", items: [{ itemId, order: 0, shotId: item.canonicalShotId, referenceId: item.reference.referenceId, referenceSha256: item.reference.sha256, promptHash: item.contentHash, state: "sending" }], revision: 1, createdAt: 1, updatedAt: 1, lastDispatchAt: null, cooldownDeadlineAt: null, readinessDeadlineAt: null, readinessStartedAt: null, nextActionAt: null, runId: "queue-run" };
    await fixture.repositories.createVidsVideoQueue(queue);
    const dispatched = await fixture.handler.generateOnce(preparedBatchId, itemId, true);
    expect(dispatched.status).toBe("dispatched");
    expect(fixture.calls.filter((call) => call.func === activateVidsGenerateInPage)).toHaveLength(1);
  });

  it.each([
    ["prepared pair or hash mismatch", { wrongPromptHash: true }, "prepared_item_pairing_or_hash_mismatch"],
    ["conflicting text", { entryReason: "prompt_editor_contains_conflicting_text" }, "prompt_editor_contains_conflicting_text"],
    ["missing reference identity proof", { entryReason: "reference_file_selection_missing" }, "reference_file_selection_missing"],
    ["disabled Generate", { generateDisabled: true }, "generate_disabled"],
    ["ambiguous Generate control", { generateCount: 2 }, "vids_generate_control_ambiguous"],
    ["wrong injected document", { injectedDocumentId: "replacement-document" }, "vids_document_changed"],
    ["target changes after prompt preflight", { changeTargetBeforeIntent: true }, "vids_target_changed_before_intent"],
    ["wrong uploaded image", { referenceMismatch: true }, "vids_reference_identity_mismatch"],
    ["prompt changes before intent", { changePromptBeforeIntent: true }, "vids_exact_prompt_readback_failed"],
  ])("blocks %s before intent and activation", async (_name, options, reason) => {
    const fixture = await setup(options);
    const result = await fixture.handler.generateOnce(preparedBatchId, itemId);
    expect(result.status).toBe("blocked");
    expect(result.reason).toBe(reason);
    expect(await fixture.database.vidsVideoGenerationOperations.toArray()).toEqual([]);
    expect(fixture.calls.some((call) => call.func === activateVidsGenerateInPage)).toBe(false);
  });

  it("does not repeat Generate after a successful receipt or an activation reply is lost", async () => {
    for (const options of [{}, { activationThrows: true }]) {
      const fixture = await setup(options);
      const first = await fixture.handler.generateOnce(preparedBatchId, itemId);
      const calls = fixture.calls.length;
      const second = await fixture.handler.generateOnce(preparedBatchId, itemId);
      expect(fixture.calls).toHaveLength(calls);
      expect(second.status).toBe(options.activationThrows ? "uncertain" : "already_dispatched");
      expect(first.status).toBe(options.activationThrows ? "uncertain" : "dispatched");
    }
  });

  it("persists a proof failure after intent as blocked with zero activation, and never retries it implicitly", async () => {
    const fixture = await setup({ activationResult: { ok: false, reason: "reference_file_selection_missing", activationAttempted: false, activationCount: 0 } });
    const first = await fixture.handler.generateOnce(preparedBatchId, itemId);
    expect(first).toMatchObject({ status: "blocked", stage: "reference_proof", reason: "reference_file_selection_missing" });
    const saved = await fixture.repositories.getVidsVideoGenerationOperation((first.operation as { id: string }).id);
    expect(saved).toMatchObject({ status: "blocked", failureStage: "reference_proof", activationAttempted: false, activationCount: 0, reason: "reference_file_selection_missing" });
    const calls = fixture.calls.length;
    const second = await fixture.handler.generateOnce(preparedBatchId, itemId);
    expect(second.status).toBe("blocked");
    expect(fixture.calls).toHaveLength(calls);
    expect(fixture.calls.filter((call) => call.func === activateVidsGenerateInPage)).toHaveLength(1);
  });

  it("reconciles the exact ai_sidebar_missing pre-click snapshot without activation and preserves it on the same operation", async () => {
    const fixture = await setup({ activationResult: { ok: false, reason: "ai_sidebar_missing", activationAttempted: false, activationCount: 0 } });
    const first = await fixture.handler.generateOnce(preparedBatchId, itemId);
    expect(first).toMatchObject({ status: "blocked", stage: "generate_preflight", reason: "ai_sidebar_missing" });
    const original = first.operation as NonNullable<typeof first.operation>;
    expect(original).toMatchObject({ status: "blocked", reason: "ai_sidebar_missing", activationAttempted: false, activationCount: 0 });
    const beforeRecoveryCalls = fixture.calls.length;

    const recovered = await fixture.handler.recoverPreActivationFailure(original);
    expect(recovered).toMatchObject({ status: "retry_ready", operation: {
      id: original.id, status: "retry_ready", reason: "ai_sidebar_missing", activationAttempted: false, activationCount: 0,
      preActivationRecovery: { producer: "ai_sidebar_missing_before_generate_click", priorAttemptId: original.attemptId, priorStatus: "blocked", priorFailureStage: "generate_preflight", priorReason: "ai_sidebar_missing", priorUpdatedAt: original.updatedAt },
    } });
    expect(fixture.calls).toHaveLength(beforeRecoveryCalls);
    expect(fixture.calls.filter((call) => call.func === activateVidsGenerateInPage)).toHaveLength(1);

    const submitted = await fixture.handler.generateOnce(preparedBatchId, itemId);
    expect(submitted.status).toBe("dispatched");
    expect(submitted.operation).toMatchObject({ id: original.id, status: "dispatched", attemptId: "77777777-7777-4777-8777-777777777777", preActivationRecovery: { priorAttemptId: original.attemptId, priorReason: "ai_sidebar_missing", priorUpdatedAt: original.updatedAt } });
    expect(fixture.calls.filter((call) => call.func === activateVidsGenerateInPage)).toHaveLength(2);
  });

  it("rejects changed snapshots and uncertain/attempted activation from exact pre-click recovery", async () => {
    const changedFixture = await setup({ activationResult: { ok: false, reason: "ai_sidebar_missing", activationAttempted: false, activationCount: 0 } });
    const blocked = await changedFixture.handler.generateOnce(preparedBatchId, itemId);
    const changed = { ...(blocked.operation as NonNullable<typeof blocked.operation>), updatedAt: (blocked.operation as NonNullable<typeof blocked.operation>).updatedAt + 1 };
    const rejectedChanged = await changedFixture.handler.recoverPreActivationFailure(changed);
    expect(rejectedChanged).toMatchObject({ status: "blocked", reason: "generation_operation_changed" });
    expect(changedFixture.calls.filter((call) => call.func === activateVidsGenerateInPage)).toHaveLength(1);

    const uncertainFixture = await setup({ activationThrows: true });
    const uncertain = await uncertainFixture.handler.generateOnce(preparedBatchId, itemId);
    const rejectedUncertain = await uncertainFixture.handler.recoverPreActivationFailure(uncertain.operation);
    expect(uncertain.status).toBe("uncertain");
    expect(rejectedUncertain).toMatchObject({ status: "blocked", reason: "generation_failure_not_proven_pre_activation" });
    expect(uncertainFixture.calls.filter((call) => call.func === activateVidsGenerateInPage)).toHaveLength(1);
  });

  it("atomically prevents two concurrent requests from activating Generate twice", async () => {
    const fixture = await setup();
    const [first, second] = await Promise.all([
      fixture.handler.generateOnce(preparedBatchId, itemId),
      fixture.handler.generateOnce(preparedBatchId, itemId),
    ]);
    expect([first.status, second.status].filter((status) => status === "dispatched")).toHaveLength(1);
    expect(fixture.calls.filter((call) => call.func === activateVidsGenerateInPage)).toHaveLength(1);
    expect(await fixture.database.vidsVideoGenerationOperations.toArray()).toHaveLength(1);
  });

  it("routes generation only through Vids handlers and leaves Flow queue and operations untouched", async () => {
    const fixture = await setup();
    const vidsGenerate = vi.fn(async () => ({ status: "dispatched" }));
    const vidsGet = vi.fn(async () => ({ status: "not_started" }));
    const vidsRecover = vi.fn(async () => ({ status: "retry_ready" }));
    const flowGenerate = vi.fn(async () => ({ status: "dispatched" }));
    const preferences = new ChromePreferenceRepository({ get: async () => ({}), set: async () => undefined });
    const listener = createConnectionMessageListener("vids-generate-isolation", {
      repositories: fixture.repositories, preferences,
      vidsVideoGenerate: { generateOnce: vidsGenerate, get: vidsGet, recoverPreActivationFailure: vidsRecover },
      flowVideoGenerateOnce: flowGenerate,
      vidsVideoAttachment: { attach: vi.fn(), get: vi.fn() },
    });
    const sender = { id: "vids-generate-isolation", url: "chrome-extension://vids-generate-isolation/index.html" };
    const send = (type: "vids.video.generateOnce" | "vids.video.getGenerationStatus") => new Promise<unknown>((resolve) => {
      const request = makeRequest(type, { preparedBatchId, itemId }, `request-${type}`);
      listener(JSON.parse(JSON.stringify(request)), sender, resolve);
    });
    await send("vids.video.getGenerationStatus");
    await send("vids.video.generateOnce");
    const expected = {
      id: `vids-generation:${await sha256Hex(`${preparedBatchId}\u0000${itemId}`)}`, preparedBatchId, workspaceId: "workspace", itemId, canonicalShotId: "1",
      promptHash: fixture.promptHash, referenceId, referenceSha256: fixture.referenceSha256, tabId: 90, canonicalTarget, documentId,
      attemptId: "66666666-6666-4666-8666-666666666666", status: "blocked", failureStage: "generate_preflight", reason: "ai_sidebar_missing",
      preIntentReferenceProofSource: "preview_blob_sha256",
      promptReadback: { serialization: "contenteditable_blocks_v1", expectedSha256: fixture.promptHash, actualSha256: fixture.promptHash, immediateMatch: true, settledMatch: true, stableReads: 3, verifiedAt: 3 },
      activationAttempted: false, activationCount: 0, createdAt: 1, updatedAt: 4,
    };
    const recoveryRequest = makeRequest("vids.video.recoverPreActivationFailure", { expected }, "request-recovery");
    const recoveryResponse = new Promise<unknown>((resolve) => listener(JSON.parse(JSON.stringify(recoveryRequest)), sender, resolve));
    await recoveryResponse;
    expect(vidsGet).toHaveBeenCalledWith(preparedBatchId, itemId);
    expect(vidsGenerate).toHaveBeenCalledWith(preparedBatchId, itemId);
    expect(vidsRecover).toHaveBeenCalledWith(expected);
    expect(flowGenerate).not.toHaveBeenCalled();
    expect(await fixture.database.flowVideoQueues.toArray()).toEqual([]);
    expect(await fixture.database.flowVideoAttachmentOperations.toArray()).toEqual([]);
  });
});
