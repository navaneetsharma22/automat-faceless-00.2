import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { INPUT_POLICY } from "../../src/domain/batches/inputPolicy";
import { importPromptBatch } from "../../src/domain/batches/importBatch";
import { ImageImportPanel } from "../../src/app/features/image-batch/ImportPanel";
import { VideoImportPanel } from "../../src/app/features/video-batch/ImportPanel";
import { ImportPreviewSession } from "../../src/app/features/shared/importPreviewSession";
import {
  ImportFileError,
  readJsonSourceFile,
} from "../../src/app/features/shared/importFile";
import { ToastHost } from "../../src/app/components/ToastHost";
import { createFoundationClient } from "../../src/shared/messageClient";
import type { FoundationClient } from "../../src/shared/messageClient";
import {
  promptSizeFixtures,
  representativeCases,
} from "../fixtures/prompts/promptFixtures";

function makeScheduledSession(kind: "image" | "video") {
  let scheduled: (() => void) | undefined;
  const session = new ImportPreviewSession(
    kind,
    importPromptBatch,
    (callback) => {
      scheduled = callback;
      return 1 as ReturnType<typeof setTimeout>;
    },
    () => 12,
  );
  return {
    session,
    run: () => {
      const callback = scheduled;
      if (!callback) throw new Error("No validation callback was scheduled");
      callback();
    },
  };
}

function renderImportPanel(
  kind: "image" | "video",
  session: ImportPreviewSession,
  persistenceClient?: FoundationClient,
) {
  const props = {
    session,
    legacyFlowSetup: createElement("p", null, "Manual Flow setup"),
    wrapLines: false,
    setWrapLines: () => undefined,
    editorExpanded: false,
    setEditorExpanded: () => undefined,
    workspaceId: "default",
    persistenceClient:
      persistenceClient ??
      createFoundationClient({
        sendMessage: async () => ({}),
      }),
  };
  const panel =
    kind === "image"
      ? createElement(ImageImportPanel, props)
      : createElement(VideoImportPanel, props);
  return renderToStaticMarkup(createElement(ToastHost, null, panel));
}

describe("P03.3 import preview integration", () => {
  it("keeps image and video drafts independent and renders separate import panels", () => {
    const image = new ImportPreviewSession("image");
    const video = new ImportPreviewSession("video");
    const imageSource = '{\r\n  "shot_id":"01", "image":"source"\r\n}';
    const videoSource = '{\n  "shot_id":"02", "video":"source"\n}';
    image.setSource(imageSource);
    video.setSource(videoSource);

    expect(image.getSnapshot().source).toBe(imageSource);
    expect(video.getSnapshot().source).toBe(videoSource);
    image.setSource('{"shot_id":"3"}');
    expect(video.getSnapshot().source).toBe(videoSource);

    const imageMarkup = renderImportPanel("image", image);
    const videoMarkup = renderImportPanel("video", video);
    expect(imageMarkup).toContain("Image prompt source");
    expect(videoMarkup).toContain("Video prompt source");
    expect(imageMarkup).toContain("&quot;shot_id&quot;:&quot;3&quot;");
    expect(videoMarkup).toContain("&quot;shot_id&quot;:&quot;02&quot;");

    expect(imageMarkup).toContain("New batch");
    expect(videoMarkup).not.toContain("New batch");
    expect(imageMarkup).not.toContain("Load synthetic example");
    expect(imageMarkup).not.toContain("Start image batch");
  });

  it("previews arbitrary command-like video JSON verbatim without provider actions", () => {
    const { session, run } = makeScheduledSession("video");
    const body =
      '{\r\n  "director_notes": {"camera_path": [[1.25, 2.5], [3.75, 4.0]]},\n' +
      '  "duration": 8, "unusedField": "\u0928\u092E\u0938\u094D\u0924\u0947 \u{1F3AC}",\r\n' +
      '  "instruction": "Generate once; download; Prompt 42: {\\"nested\\":true}"\n}';
    const requests: string[] = [];
    const client = createFoundationClient({
      sendMessage: async (request) => {
        requests.push(request.type);
        return {};
      },
    });

    session.setSource(body);
    session.validate();
    run();
    const snapshot = session.getSnapshot();
    expect(snapshot.status).toBe("success");
    expect(snapshot.result?.items).toHaveLength(1);
    expect(snapshot.result?.items[0]!.rawBody).toBe(body);
    expect(snapshot.result?.items[0]!.shotId).toBeUndefined();

    const markup = renderImportPanel("video", session, client);
    expect(markup).toContain("1 prompt");
    expect(markup).toContain("No shot ID");
    expect(markup).toContain("Show raw body");
    expect(markup).toContain("Save validated batch");
    expect(markup).not.toContain("Generate once in Flow");
    expect(markup).not.toContain("Check Flow readiness");
    expect(requests).toEqual([]);
  });

  it("clears editable draft, validation preview and error when cleared", () => {
    const { session, run } = makeScheduledSession("image");
    session.setSource('{"shot_id":"01","prompt":"test"}');
    session.validate();
    run();
    expect(session.getSnapshot().status).toBe("success");
    expect(session.getSnapshot().result?.items.length).toBe(1);

    const prevRevision = session.getSnapshot().revision;
    session.clear();
    const snapshot = session.getSnapshot();
    expect(snapshot.source).toBe("");
    expect(snapshot.revision).toBe(prevRevision + 1);
    expect(snapshot.status).toBe("idle");
    expect(snapshot.result).toBeUndefined();
    expect(snapshot.resultRevision).toBeUndefined();
    expect(snapshot.error).toBeUndefined();
  });

  it("shows only current complete result counts and IDs with provider-safe wording", () => {
    const { session, run } = makeScheduledSession("image");
    session.setSource(representativeCases.numberedTwoBodies.source);
    const validationId = session.validate();
    expect(session.getSnapshot().status).toBe("pending");
    expect(session.getSnapshot().validationId).toBe(validationId);
    run();

    const snapshot = session.getSnapshot();
    expect(snapshot.status).toBe("success");
    expect(snapshot.result?.items.map((item) => item.shotId)).toEqual([
      "1",
      "2",
    ]);
    const markup = renderImportPanel("image", session);
    expect(markup).toContain("2 prompts detected");
    expect(markup).toContain("Shot ID 1");
    expect(markup).toContain("Shot ID 2");
    expect(markup).toContain("Nothing has been sent to a provider");
    expect(markup).toContain("Show raw body");
    expect(markup).toContain("New batch");
    expect(markup).toContain("Load saved batch");
    expect(markup).toContain("Export saved source");
    expect(markup).toMatch(/<button[^>]*>Save validated batch<\/button>/);
    expect(markup).not.toContain("<pre");
    expect(markup.indexOf("Validate &amp; Preview")).toBeLessThan(
      markup.indexOf("Save validated batch"),
    );
    expect(markup.indexOf("Save validated batch")).toBeLessThan(
      markup.indexOf("Legacy count-mode and one-shot tools"),
    );
    expect(markup).toContain("Technical details");
    expect(markup).toContain("UTF-8 JSON. Maximum");
  });

  it("retains the previous successful preview as stale after edits or failure", () => {
    const { session, run } = makeScheduledSession("video");
    const initial = '{"shot_id":"8","scene":"valid"}';
    session.setSource(initial);
    session.validate();
    run();
    expect(session.getSnapshot().status).toBe("success");

    session.setSource('{"shot_id":"9","scene":');
    expect(session.getSnapshot().status).toBe("idle");
    expect(session.getSnapshot().result?.items[0]?.rawBody).toBe(initial);
    session.validate();
    run();
    const failed = session.getSnapshot();
    expect(failed.status).toBe("error");
    expect(failed.error?.code).toBe("incomplete_json");
    expect(failed.result?.items[0]?.rawBody).toBe(initial);
    expect(failed.resultRevision).not.toBe(failed.revision);
    const markup = renderImportPanel("video", session);
    expect(markup).toContain("PREVIOUS RESULT");
    expect(markup).toContain("does not describe the current draft");
    expect(markup).toContain("Line 1, column");
    expect(markup).toContain("Save validated batch");
    expect(markup).toMatch(/<button[^>]*disabled=""[^>]*>Save validated batch/);
  });

  it("ignores a scheduled validation after a newer draft revision", () => {
    const { session, run } = makeScheduledSession("image");
    session.setSource('{"shot_id":"1"}');
    session.validate();
    session.setSource('{"shot_id":"2"}');
    run();
    expect(session.getSnapshot().source).toBe('{"shot_id":"2"}');
    expect(session.getSnapshot().status).toBe("idle");
    expect(session.getSnapshot().result).toBeUndefined();
  });

  it("rejects oversized files before reading and decodes only UTF-8 with a leading BOM", async () => {
    let readCount = 0;
    const tooLarge = {
      size: INPUT_POLICY.maxBatchUtf8Bytes + 1,
      arrayBuffer: async () => {
        readCount += 1;
        return new ArrayBuffer(0);
      },
    };
    await expect(readJsonSourceFile(tooLarge)).rejects.toMatchObject<
      Partial<ImportFileError>
    >({ code: "file_too_large" });
    expect(readCount).toBe(0);

    const original = '{\r\n  "shot_id":"01",\r\n  "scene":"BOM file"\r\n}';
    const encoded = new TextEncoder().encode(`\uFEFF${original}`);
    const file = {
      size: encoded.byteLength,
      arrayBuffer: async () =>
        encoded.buffer.slice(
          encoded.byteOffset,
          encoded.byteOffset + encoded.byteLength,
        ),
    };
    expect(await readJsonSourceFile(file)).toBe(original);

    const invalidBytes = new Uint8Array([0xff, 0xfe, 0xfd]);
    await expect(
      readJsonSourceFile({
        size: invalidBytes.byteLength,
        arrayBuffer: async () => invalidBytes.buffer,
      }),
    ).rejects.toMatchObject({ code: "invalid_utf8" });
  });

  it("measures validation time for all existing large image and video fixtures", () => {
    const timings: string[] = [];
    for (const fixture of promptSizeFixtures) {
      let scheduled: (() => void) | undefined;
      const session = new ImportPreviewSession(
        fixture.kind,
        importPromptBatch,
        (callback) => {
          scheduled = callback;
          return 1 as ReturnType<typeof setTimeout>;
        },
      );
      session.setSource(fixture.rawBody);
      const samples: number[] = [];
      for (let repeat = 0; repeat < 5; repeat += 1) {
        scheduled = undefined;
        session.validate();
        if (!scheduled) throw new Error("No validation callback was scheduled");
        scheduled();
        const snapshot = session.getSnapshot();
        expect(snapshot.status, fixture.name).toBe("success");
        expect(snapshot.result?.items[0]?.rawBody).toBe(fixture.rawBody);
        expect(snapshot.elapsedMs).toBeGreaterThanOrEqual(0);
        samples.push(snapshot.elapsedMs!);
      }
      const ordered = [...samples].sort((a, b) => a - b);
      const median = ordered[Math.floor(ordered.length / 2)]!;
      const maximum = ordered[ordered.length - 1]!;
      timings.push(
        `${fixture.name}:${median.toFixed(1)}ms median/${maximum.toFixed(1)}ms max`,
      );
    }
    console.info(`P03.3 synthetic validation timings: ${timings.join(", ")}`);
  });
});
