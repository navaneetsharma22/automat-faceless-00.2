# P11.2 single-clip Flow download

Implemented on 5 November 2026 from the user-uploaded source archive.

Build `automat-faceless-0.1.0-mw39351k` contains a dashboard-initiated **Download 1080p** action and distinct **Flow Downloads** and **Vids Downloads** tabs. The Flow action is available on imported rows, including clips with the same title. It requires the intended row's exact detail route in the currently verified Flow tab. The existing Open this Flow clip link and project verification remain the navigation path for selecting another clip.

## Download behavior

A dashboard click requests the optional downloads permission and validates the imported row, connected project, exact clip route and verified document. The page adapter requires one visible navigation thumbnail with `aria-current="true"` and one full asset UUID in its image URL on an observed Flow media host. It opens the native Download media menu, resolves its unique visible `aria-controls` menu and enabled 1080p Upscaled item, and checks that the item's center is unobstructed.

The worker arms exact page/Chrome download tracking, stores a dispatch intent, rechecks the same route and asset, and sends one native mouse press/release pair to the quality option. Flow handles an upscale or an existing upscaled output through its native behavior. The extension continues monitoring for up to 20 minutes.

The browser completion receipt requires an eligible selected-main-frame event and an exact in-memory URL equality with one Chrome download ID. For dashboard attempts, a mismatching filename media token or frame is ignored as an unrelated candidate. The filename token is a candidate filter, never proof of output provenance. At the accepted page event the worker revalidates the exact route, document and selected asset again. Multiple exact page/download candidates remain ambiguous.

A normal page preparation failure leaves a stopped receipt with zero quality input. Failure after input may have been attempted retains an uncertain receipt. Concurrent starts and automatic replay after an uncertain result or worker restart are rejected. A later explicit Download again action can authorize a new attempt after review. Stop monitoring leaves any provider job and Chrome download running.

## Live DOM evidence used

| Detail clip | Active navigation thumbnail asset |
| --- | --- |
| `c2989a6e-7cae-4cbf-84f2-51a44ddfd1fa` | `d8d91f05-e14d-4e15-964f-104981510af6` |
| `bbc2bc82-eccc-4cbe-b3bd-2c8ee2fbd7fa` | `5a796d9e-5c1a-414a-a961-ed77e35c78a3` |

Both mappings were directly observed by navigating the live page's two same-title thumbnail buttons and inspecting the selected `aria-current` state. The target's rendered asset inventory also contained a Fetch resource at the `flow-content.google/video/<asset UUID>_upsampled` path. This demonstrates a route-to-selected-thumbnail mapping and an observed output-resource candidate. It does not establish the output response bytes' provenance into the downloaded blob.

## Evidence boundaries

The UI reports browser completion with its exact Chrome ID separately from clip-to-output association and decoded file resolution. Clip association remains Unverified. Chrome's file-exists metadata only checks the saved browser file. Actual saved-media resolution requires independent inspection. User-supplied Windows Properties verified 1920×1080 at 24 fps for prior download 2792, not for a new download from this build.

The action uses Flow's native suggested filename and Chrome's current download folder/settings. The current implementation tracks one active attempt and exposes the current attempt's receipt. Whole-project import, batch downloading, custom folder selection and durable per-row download history are future scope. Vids download preparation remains pending in its separate tab.

## Validation

- 10 focused Vitest files / 95 tests passed, covering new page preparation, actual same-title UUID fixtures, selected-asset changes, disabled/obscured or unbound quality options, exact Chrome-ID completion, unrelated same-frame MP4s, route changes while waiting, uncertain dispatch, worker restart and separate provider panels, along with relevant existing message/diagnostic tests.
- Typecheck and ESLint passed after final source changes.
- Production build and manifest/shared-build-ID validation passed with four JavaScript bundles.
- The connector build emitted the existing inlineDynamicImports/codeSplitting warning.
- Diff whitespace validation against the uploaded archive passed.
- A live download using the newly packaged extension is NOT_RUN. The connected browser blocks inspection/control of extension-protocol pages, and the local Playwright Chromium executable is absent. Existing live Flow DOM observations informed selectors, while automated behavior was exercised through DOM and worker fixtures.

## Packaging and source omissions

The uploaded archive omitted `tsconfig.json`, `vite.config.ts`, `AGENTS.md`, root README and `PROJECT_STATUS.md`. The two build configurations were restored from the previously supplied P10.3 snapshot and validated with the uploaded package versions. Dependencies and the lockfile remain unchanged. The prior supplied AGENTS instructions were read for scope. This note and the P11 phase card carry the implementation status because the current root status file was absent. Preserve local root documentation when merging the update.

The ZIP includes source, tests and ready-to-load `dist/`. Merge source changes into the existing project and replace its existing `dist/` with the supplied one. Reload the existing unpacked extension from the same directory to preserve its extension ID and stored imported clips.

## First live acceptance

Load the packaged build and confirm its build ID. Select and verify the Flow tab on the intended imported row's exact detail route. In Downloads → Flow Downloads, click that row's Download 1080p once. Let native Flow preparation and Chrome download finish. Review the exact download ID and completed/interrupted/ambiguous status. Inspect the saved file separately. Review an uncertain result before an explicit second attempt.

## P11.2 JSON-safe injection and bounded failure reporting correction - 5 November 2026

Source review found explicit `undefined` values in both automatic `scripting.executeScript` calls: initial page preparation and the `Page.downloadWillBegin` identity readback. Both now pass `null`; `prepareFlowClipDownloadInPage` accepts `expectedAssetId: string | null = null` and retains its route, selected-asset, and menu checks.

The attempt records a bounded failure stage, fixed failure code, and whether native quality input was attempted. The worker durably records `inputAttempted: true` before the first native input call. Before-input failures close an armed receipt as stopped/preparing and report preparation failure unless a known route, connection, document, or menu error applies. After-input failures close as interrupted/uncertain, retain the attempt, and block automatic replay. Identity-readback injection failure is separately retained as an interrupted post-input receipt. Only fixed stage/code values are exposed; raw Chrome exception text, URLs, and tokens are discarded.

The integration `executeScript` boundary now rejects any `undefined` argument and checks JSON serialization. Regressions assert initial preparation and later identity-readback arguments, zero quality input after injection rejection, uncertain native-input failure with no replay, and specific handler mapping for known connection, document, and menu failures. Focused Vitest: **5 files / 55 tests PASS**. Typecheck, ESLint, production/package build-ID validation, and `git diff --check`: **PASS**. The connector build emits the existing `inlineDynamicImports`/code-splitting warning. Build **`automat-faceless-0.1.0-mw3aodlh`**, four JavaScript bundles. Browser checks are **NOT_RUN**; no Flow/Vids page or provider action was used. Flow Downloads and Vids Downloads remain separate. Clip-to-output and output-to-blob provenance remain **Unverified**.

The next live check is a read-only build/install confirmation followed by inspecting the sanitized failure stage and attempted flag for a naturally occurring preparation or identity-readback failure. Do not trigger a quality selection, upscale, or download to exercise this fix.

## Flow project Videos gallery import - 5 November 2026

Build `automat-faceless-0.1.0-mw3eowgo` adds a separate **Import project videos** action to Flow Downloads and retains **Import open clip**. Before scanning, the worker validates the selected verified Flow tab and project; the page adapter requires one visible project root and one uniquely selected Videos control. It reads loaded cards and scrolls in bounded increments, with limits of 40 scroll steps and 200 cards. Progress is held in bounded worker memory and reports discovered/imported/already-present/unresolved counts, cancellation, and scan completeness. A complete scan requires a non-busy, stable bottom position in two reads. Reaching the cap or losing stable coverage/navigation/connection reports incomplete. No row is created for an unresolved card.

The adapter recognizes cards only through the scoped `flow-*tile/result/gallery/media`, `data-result`, `data-result-card`, listitem, and gridcell patterns. It accepts a card asset only when exactly one UUID is present in an HTTPS image pathname from `flow-content.google` or `storage.googleapis.com`. Titles are labels only. A route is accepted from an exact `/edit/<UUID>` link within the same card, with project match. If absent, the card is re-located by asset UUID and scoped image fingerprint; exactly one allowed native Open/View/Play control is activated, and the resulting `/edit/` route and selected navigation-thumbnail asset must match. The importer then returns to the captured Videos URL and revalidates the selected project/document. The asset UUID is never transformed into a clip UUID. Stored fields include verified project and clip UUIDs, the clean detail route, bounded title, safe thumbnail dimensions/fingerprint, gallery asset UUID and the evidence kind. Signed image URLs, queries, tokens, and response contents are not stored. Existing route-only rows remain compatible; a detail-only reimport preserves Gallery mapping fields. The existing single-clip download action continues to require the exact route-verified row.

Offline evidence: **5 Vitest files / 38 tests PASS**, covering same-title distinct mappings, stable row keys/reimport, lazy scrolling, cancel and cap outcomes, missing/ambiguous identity, selected Videos gating, project/route ambiguity, selected-detail-asset mismatch rejection, and existing download diagnostic behavior. Typecheck, ESLint, production/package build-ID validation, and `git diff --check`: **PASS**. The four packaged JS bundles share build ID `automat-faceless-0.1.0-mw3eowgo`; connector packaging emits the existing ignored `inlineDynamicImports` warning. Flow Downloads and Vids Downloads are separate. No Flow row was selected, no upscale/download was triggered, and no provider storage was changed.

Live Gallery inspection/import: **NOT_RUN**; the current CUA browser inventory had no app or browser tabs. The precise DOM assumption still needing live verification is the Videos-tab selected-state ARIA, card-owner selector family, and the same-card image/link/native-control relationship. Fixture coverage is not evidence that the current live Flow gallery uses those selectors. The next check is one manual import in the loaded `mw3eowgo` extension on the intended verified project. Review scan completeness and counts, compare two same-title clips by UUID, and reimport once to confirm no duplicate rows. Do not click Download 1080p. P11.1's clip-to-output and output-to-blob provenance remains unrelated and **Unverified**.

## Gallery preflight reason and terminal-state correction - 5 November 2026

For the supplied `mw3eowgo` error, the initial worker preflight was the source of the generic result: a blocked page result and an invalid inspection response both threw `flow_project_video_import_gallery_unavailable`. The page adapter's fixed early reasons included missing/ambiguous Flow project root, project mismatch, and inability to establish exactly one selected Videos control. That run did not retain which branch fired, so its specific prerequisite cannot be determined retroactively. The UI also left the previous progress object unchanged when the start request rejected, allowing a stale Scanning/Scan in progress display to persist.

The worker now returns a fixed `failureReason` on a terminal Failed preflight response. The `failureReason` is bounded to known Gallery/page preflight codes; it contains no DOM text, URL, identifier value, or exception message. Start errors refresh progress when possible. Errors during scanning finalize as Failed with retained counts; cancellation finalizes as Cancelled; a reached bound or unproven coverage finalizes as Incomplete. The first card snapshot is merged inside the scan's guarded `try/finally`, and every terminal path drops the running lock. A regression verifies the failure code, zero counts, terminal status, and immediate fresh import without reloading.

Focused checks: **5 files / 39 tests PASS**; typecheck, ESLint, production package build-ID validation, and `git diff --check`: **PASS**. Build `automat-faceless-0.1.0-mw3iqu6q`, four JS bundles. The screenshot supplies visual evidence of the project route, selected-looking Videos item, and cards only. Browser lookup returned “No browser is available,” so no live DOM or import verification occurred. Selectors were not altered speculatively, and Gallery import is not live-verified.

Exact next check: load `mw3iqu6q` and make one Gallery import attempt, then report the single fixed Preflight failure reason. For `project_missing`/`project_ambiguous`, only the visible project/gallery container's tag, role, class, and match count are needed. For `videos_section_not_selected`, only the visible Videos control's tag, role, text/label, class, `aria-current`/`aria-selected`/`aria-pressed`, and nearest parent tag/role/class are needed. Omit href/src values, UUIDs, query strings, and tokens. Do not select quality or download.
