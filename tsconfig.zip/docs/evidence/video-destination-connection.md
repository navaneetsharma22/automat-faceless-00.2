﻿# P08.3 destination connection-state refresh evidence

## Proven source path

`connections.getSelection` is handled by the worker as the persisted `SelectedTargetRecord | null`. `FoundationClient` validates the response envelope, request ID, protocol version, and build ID, then returns `response.data` to the UI. The sidebar's connection panel listens for current-build/current-protocol connection-state events and rereads that worker record. The Videos destination panel previously read it on initial mount and provider changes only; it had no connection-state subscription. This explains how the sidebar could show the post-reconnect verified record while Videos retained its earlier unverified snapshot.

The Videos view now shares one worker-backed adapter for its initial/provider read and lifecycle-event refresh. Per-request revisions reject late results from an earlier provider or older refresh. The destination view validates provider and parsed canonical route/project, verified lifecycle state, selected tab and top-frame document binding, extension/connector build and protocol, capability, and verification timestamp before enabling confirmation. It does not manufacture a verified state. Repository preparation validation was not changed and remains the final authorization check.

## Automated verification

Focused tests: `tests/unit/selectedTargetConnectionStore.test.ts` verifies a current verified initial record, event-driven reconnect refresh, provider-switch races, older same-provider response rejection, stale build/protocol event rejection, and stale/missing document or build/protocol binding refusal. `tests/unit/destinationPresentation.test.tsx` and `tests/integration/videoBatchPreparation.test.ts` cover destination presentation and worker/repository preparation invariants.

Synthetic test results for this follow-up: 3 files, 25 tests passed. Typecheck, lint, format, diff check, and build results are recorded in `PROJECT_STATUS.md` after they run. No installed-extension or live provider verification was performed; reconnect UI behavior in Chrome remains unverified.
