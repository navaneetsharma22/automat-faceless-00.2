# P08.2 stable Shot-ID pairing and video review evidence — 1 November 2026

P08.2 implements pure, deterministic Shot-ID pairing and video-pair review in the Videos workspace. The pairing validator joins imported video items to verified saved reference assignments by `(workspaceId, selectedImageSourceBatchId, canonicalShotId)`. Pairing never matches by gallery index, array order, filename, or image subject.

## User decisions enforced
1. Video JSON structure/content is user-defined and stays unchanged (lossless preservation of raw body, exact source span, and content hash).
2. Pair only imported video Shot IDs (e.g. 3 video Shots + 10 saved image references produce exactly 3 intended pairs; the other 7 references remain untouched in References and do not invalidate batch pairing).
3. Reference changes happen on the References page. No picker or "Change reference" workflow is embedded inside Videos.
4. Provider duration is chosen manually for the whole batch. No interpretation, comparison, warning, or modification of JSON duration fields.
5. P08.2 is review only. No provider execution, Generate, upload, download, or live actions.

## Pure pairing validator
- Pure function `validateAndPairVideoShots` in `src/domain/batches/pairShots.ts`.
- Canonicalizes decimal Shot IDs using existing rules (stripping leading zeroes, `"01"` -> `"1"`).
- Bounded structured error reasons:
  - `missing_video_shot_id`: Video prompt lacks an explicit Shot ID.
  - `duplicate_video_shot_id`: Video batch contains duplicate canonical Shot IDs (e.g., `"1"` and `"01"`).
  - `missing_saved_reference`: No saved reference assignment exists for this Shot ID.
  - `duplicate_conflicting_reference`: Multiple conflicting assignments exist for the same Shot ID.
  - `wrong_workspace_binding`: Reference assignment belongs to a different workspace.
  - `wrong_source_binding`: Reference assignment belongs to a different image source batch.
  - `invalid_media_metadata`: Media metadata is corrupt, out of bounds, or MIME type is invalid.
  - `stale_assignment`: Assignment source hash does not match the selected image batch source hash.
- Unused saved references in the selected image source are returned as informational nonblocking records (`unusedReferences`).
- Whole batch review is valid (`batchValid: true`) if and only if `totalVideoShots > 0` and `invalidPairCount === 0`. If any intended pair is invalid, the batch cannot be marked valid.

## Pairing review UI
- Integrated in `src/app/features/video-batch/PairingTable.tsx` within the Videos workspace.
- Requires explicit user selection/confirmation of the persisted image reference source (`selectedImageSourceId`), displaying its distinct label, shot count, and source hash.
- Summary bar displays Video Batch identity, Imported Shot count, Image Source identity, Matched Pairs, Invalid Pairs, Unused References, and Overall Status.
- Table rows display imported video items in their original execution order:
  - Order `#`
  - Canonical Shot ID badge (with declared ID if different)
  - Saved reference thumbnail loaded through the existing local media path (`flow.reference.getSavedReference`), with dimensions, MIME type, byte size, and revocable Blob object URLs.
  - Pair status badge (Valid Pair or Invalid Pair with user-readable error reason).
  - Expandable, scrollable raw video JSON disclosure (`<details><summary>...</summary><pre>...</pre></details>`). Full large JSON bodies are not rendered expanded by default.
- Informational section for unused image references.
- Clear instruction and button to navigate to the References workspace for choosing/replacing references.
- Video draft editing or invalidation immediately marks `videoSourceReady: false` and prompts the user to save/validate before pairing is reviewed. Stale pairing is never presented as describing an edited draft.

## Verification
- Unit suite `tests/unit/pairShots.test.ts`: **13/13 PASS**.
- Integration suite `tests/integration/videoPairing.test.ts`: **5/5 PASS** using real production `ExtensionRepositories` and Dexie database.
- Presentation suite `tests/unit/pairingTablePresentation.test.tsx`: **5/5 PASS** using React DOM / jsdom.
- Full Vitest test suite: **40 files / 454 tests PASS**.
- `npm run typecheck`: **PASS** (zero errors).
- `npm run lint`: **PASS** (zero errors or warnings).
- `git diff --check`: **PASS** (clean diff).
- Production build `npm run build`: **PASS**, package ID **`automat-faceless-0.1.0-mvxir9bo`** in `dist/` (4 JavaScript bundles).

## P08.3 exclusive destination, manual settings confirmation, and durable preparation snapshot — 1 November 2026

P08.3 is **OFFLINE_VERIFIED**. Implements local preparation and persistence of reviewed video batches with exactly one destination (Flow or Vids) and manual settings confirmation. This is strictly local preparation; no execution queue, alarms, upload, prompt injection, or Generate actions are created or invoked.

### User decisions enforced
1. Video JSON structure/content is preserved losslessly (exact raw JSON string, exact source span, and content hash preserved without rewriting or re-serialization).
2. Pair only imported video Shot IDs (e.g. Shots 34 and 35; unused image references 1..33, 36.. remain untouched in storage and nonblocking).
3. Reference replacements occur in References only, never inside Videos.
4. User manually chooses provider settings and declares one whole-batch duration (e.g. 6 or 8 seconds). The duration is recorded as user-declared tracking metadata only. It is never compared to JSON duration numbers, used to calculate offsets, or used to manipulate provider controls.
5. Prepared snapshots are immutable and durable; their reference media bytes are pinned in `pinnedReferenceMedia` so subsequent reference changes in P07 leave the prepared snapshot and its thumbnail/byte readbacks completely intact.

### Component & architecture integration
- `Destination` (`src/app/features/video-batch/Destination.tsx`):
  - Exclusive radio selection between Flow and Vids (no third destination, combined routing, or fallback).
  - Displays selected provider's actual connected target from `selectedTargets`, requiring `verification === "verified"` and `connectionState === "verified"`.
  - Manual batch duration input (whole integer seconds between 1 and 3600), explicitly documented as user-declared tracking metadata.
  - `SettingsConfirmation` with provider-specific wording: *"I manually selected and checked the settings in Flow/Vids for this batch."*
  - Automatic confirmation reset on: destination change, target change, declared duration change, video draft/source change, selected image source change, or reference assignment version change.
- `prepareVideoBatch` repository operation (`src/storage/repositories.ts`):
  - Independent authoritative reload of video batch, image batch, verified target binding, and reference assignments.
  - Reuses pure `validateAndPairVideoShots`. Rejects invalid pairings, stale source hashes, changed target bindings, unverified connections, or mismatched confirmation bindings.
  - Image byte and hash verification performed outside the transaction.
  - Atomic commit in Dexie transaction: rechecks concurrency, pins media dependencies to `pinnedReferenceMedia`, and persists the complete `PreparedVideoBatchRecord` with distinct `status: "prepared"`.
  - Idempotent: duplicate requests with the same `requestId` return the existing snapshot without duplicating records.
  - Fallback in `getReferenceById` checks `pinnedReferenceMedia` if an assignment was replaced in P07, guaranteeing reference byte availability.
- `PreparedBatchReview` (`src/app/features/video-batch/PreparedBatchReview.tsx`):
  - Prominent banner: *"Prepared — not submitted to Flow/Vids."*
  - Explicit honest disclaimer: *"Provider Execution Unavailable: This video batch is prepared and persisted locally. No provider requests, scheduler alarms, prompt insertions, or generate actions were executed. Provider execution is not implemented in this phase (P08.3)."*
  - Metadata grid showing Prepared Batch ID, Destination, Target, Declared Duration (`{duration}s User-declared whole-batch metadata`), and paired shot count.
  - Item cards displaying canonical Shot ID, saved reference thumbnail loaded via existing local media path (`flow.reference.getSavedReference`), and expandable raw video JSON prompt.
  - Retained across page reload from `preparedVideoBatches`.

### Acceptance criteria status (AC14–AC17)
- **AC14 (Lossless JSON import & exact preservation)**: **PASSED (OFFLINE_VERIFIED)**. Multiline JSON, decimal coordinates, and prompt content hashes preserved verbatim across import and snapshot.
- **AC15 (Stable Shot-ID pairing & review)**: **PASSED (OFFLINE_VERIFIED)**. Explicit canonical Shot IDs joined to saved reference assignments. User-observed review of Shot 34 -> forest and Shot 35 -> jaguar (2 matched, 0 invalid, Review Valid) recorded as visual review evidence.
- **AC16 (Exclusive destination & manual confirmation)**: **PASSED (OFFLINE_VERIFIED)**. Exactly one destination (Flow or Vids) selected; verified connection required; provider-specific confirmation wording *"for this batch"*; confirmation resets on any draft, target, duration, or source change.
- **AC17 (Durable prepared snapshot & pinned media retention)**: **PASSED (OFFLINE_VERIFIED)**. Snapshot persisted atomically with status `"prepared"`. Media pinned in `pinnedReferenceMedia`; subsequent reference replacement in P07 leaves the snapshot and its reference bytes intact. Zero provider calls, alarms, or queues.

### Verification checks
- `tests/integration/videoBatchPreparation.test.ts`: **13/13 PASS**.
- `tests/unit/destinationPresentation.test.tsx`: **7/7 PASS**.
- `tests/integration/videoPairing.test.ts`: **5/5 PASS**.
- `tests/unit/pairShots.test.ts`: **13/13 PASS**.
- `tests/unit/pairingTablePresentation.test.tsx`: **5/5 PASS**.
- Full test suite: **42 test files / 474 tests PASS**.
- Typecheck: **PASS** (`tsc --noEmit`).
- ESLint: **PASS** (`eslint .`).
- Diff check: **PASS** (`git diff --check`).
- Production build: **PASS**, package ID **`automat-faceless-0.1.0-mvxkmklh`**, output folder `dist/` (4 JavaScript bundles).

### Live gate & stopping point
- Phase 08 is **COMPLETE for offline preparation scope**. Live provider execution (P09/P10) remains **NOT_RUN** and **NOT_STARTED**.
